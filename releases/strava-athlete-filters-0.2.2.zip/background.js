// Background script for the extension
// In Firefox this runs as background.scripts, in Chrome as service_worker
// Note: The source manifest.json uses scripts for Firefox development.
// At build time, build.sh generates browser-specific manifests:
// - Firefox: background.scripts
// - Chrome: background.service_worker

// In Chrome MV3 the background is a service worker; we must explicitly import
// shared modules here. In Firefox, manifest.json background.scripts loads them
// in order before this file runs, so we skip the importScripts call.
if (typeof ServiceWorkerGlobalScope !== 'undefined' &&
    self instanceof ServiceWorkerGlobalScope) {
  importScripts('browser-polyfill.js', 'snapshotManager.js', 'diffEngine.js', 'scanner.js');
}

// Debug mode (set to true for development)
const DEBUG = false;
const log = DEBUG ? console.log.bind(console) : () => {};
const error = console.error.bind(console);

// For Chrome compatibility, check if browser is undefined and create alias
if (typeof browser === 'undefined' && typeof chrome !== 'undefined') {
  globalThis.browser = chrome;
}

log('[feed-groups] Background script loaded');

// Initialize extension on install
browser.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    log('[feed-groups] Extension installed');

    // Initialize storage keys if they don't exist
    const result = await browser.storage.local.get(['groups', 'selectedAthlete']);
    const updates = {};

    if (typeof result.groups === 'undefined') {
      updates.groups = {};
    }

    if (typeof result.selectedAthlete === 'undefined') {
      updates.selectedAthlete = null;
    }

    if (Object.keys(updates).length > 0) {
      await browser.storage.local.set(updates);
    }
  } else if (details.reason === 'update') {
    log('[feed-groups] Extension updated from', details.previousVersion);
    const manifest = browser.runtime.getManifest();
    await browser.storage.local.set({
      whatsNew: { version: manifest.version, previousVersion: details.previousVersion }
    });
  }
});

// ── Follow Tracker: message handler ──────────────────────────────────────────

let ftScanInProgress = false;

// Tab-based scan coordination: maps `${scanId}_${type}_${page}` → resolve fn
const pendingTabResolvers = new Map();

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ftStartScan') {
    handleFollowScan(sendResponse, message.listsToScan || 'both');
    return true;
  }

  if (message.action === 'ftScanPageData') {
    // Data reported back from the persistent scan tab (networkInterceptor.js)
    const { scanId, page, type } = message;
    const key = `${scanId}_${type}_${page}`;
    const resolver = pendingTabResolvers.get(key);
    if (resolver) {
      // Tab lifecycle is managed by handleFollowScan — do not close it here
      resolver({ athletes: message.athletes || {}, totalPages: message.totalPages });
    }
    return false;
  }

  if (message.action === 'ftNetworkCapture') {
    handleNetworkCapture(message).catch(e =>
      error('[follow-tracker] Network capture error:', e)
    );
    return false;
  }

  if (message.action === 'ftGetStatus') {
    ftGetScanStatus().then(sendResponse).catch(() => sendResponse({ status: 'idle' }));
    return true;
  }
});

// Navigate an existing persistent scan tab to a Strava follows page and wait
// for networkInterceptor.js to report the scraped data back.
// Returns { athletes: {id: name}, totalPages: number }
function navigateScanTabAndWait(tabId, athleteId, type, page, scanId) {
  return new Promise((resolve, reject) => {
    const key = `${scanId}_${type}_${page}`;

    // 45-second timeout per page — cleared when the page resolves or rejects
    const timeoutId = setTimeout(() => {
      if (!pendingTabResolvers.has(key)) return;
      pendingTabResolvers.delete(key);
      reject(new Error(`Scan timed out waiting for ${type} page ${page}. Please try again.`));
    }, 45000);

    // Wrap resolve so the timeout is always cleared on success
    pendingTabResolvers.set(key, (value) => {
      clearTimeout(timeoutId);
      pendingTabResolvers.delete(key);
      resolve(value);
    });

    const url = `https://www.strava.com/athletes/${athleteId}/follows` +
      `?type=${type}&page=${page}&ft_scan_id=${encodeURIComponent(scanId)}&ft_scan_page=${page}`;

    browser.tabs.update(tabId, { url }).catch(err => {
      clearTimeout(timeoutId);
      pendingTabResolvers.delete(key);
      reject(new Error(`Could not navigate scan tab: ${err.message}`));
    });
  });
}

// Fetch all pages of one follow type by navigating a single persistent scan tab.
async function fetchFollowsViaTab(athleteId, type, scanId, tabId, onProgress) {
  const allAthletes = {};
  const { maxPages } = await ftGetScanSettings();

  // Page 1 also tells us the total page count
  const { athletes: pg1, totalPages } = await navigateScanTabAndWait(tabId, athleteId, type, 1, scanId);
  Object.assign(allAthletes, pg1);
  if (onProgress) onProgress(Object.keys(allAthletes).length, 1);

  const limit = Math.min(totalPages, maxPages);
  for (let p = 2; p <= limit; p++) {
    const { athletes } = await navigateScanTabAndWait(tabId, athleteId, type, p, scanId);
    Object.assign(allAthletes, athletes);
    if (onProgress) onProgress(Object.keys(allAthletes).length, p);
  }

  return allAthletes;
}

async function handleFollowScan(sendResponse, listsToScan = 'both') {
  if (ftScanInProgress) {
    sendResponse({ success: false, error: 'A scan is already in progress.' });
    return;
  }

  // Normalize to a known value to prevent unexpected behaviour
  if (!['both', 'followers', 'following'].includes(listsToScan)) listsToScan = 'both';

  ftScanInProgress = true;
  const scanId = Date.now().toString(36);

  let needFollowing = listsToScan === 'both' || listsToScan === 'following';
  let needFollowers = listsToScan === 'both' || listsToScan === 'followers';
  let totalSteps = (needFollowing && needFollowers) ? 3 : 2;

  try {
    const stored = await browser.storage.local.get(['loggedInAthleteId', 'followTracker']);
    let athleteId = stored.loggedInAthleteId || await getAthleteIdFromActiveTab();

    if (!athleteId) {
      await ftSetScanStatus({ status: 'error', error: 'Could not determine your athlete ID. Please open Strava in a tab and try again.' });
      sendResponse({ success: false, error: 'Could not determine your athlete ID.' });
      return;
    }

    await browser.storage.local.set({ loggedInAthleteId: athleteId });

    // For a partial scan, reuse the unchanged list from the existing snapshot
    const existingSnapshot = stored.followTracker?.latestSnapshot;

    // Upgrade partial scan to full when the list we'd reuse is missing from the snapshot
    if (!needFollowing && !existingSnapshot?.following) { needFollowing = true; totalSteps = 3; }
    if (!needFollowers && !existingSnapshot?.followers) { needFollowers = true; totalSteps = 3; }

    let following, followers;

    // Open a single persistent tab for all page fetches — navigated in-place
    // rather than opening/closing a tab per page, eliminating tab flashing.
    let scanTabId = null;
    if (needFollowing || needFollowers) {
      const scanTab = await browser.tabs.create({ url: 'about:blank', active: false });
      scanTabId = scanTab.id;
    }

    try {
      if (needFollowing) {
        await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps, message: 'Fetching following list…' });
        following = await fetchFollowsViaTab(athleteId, 'following', scanId, scanTabId, async (count, pg) => {
          await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps, message: `Fetching following… ${count} found (page ${pg})` });
        });
      } else {
        following = existingSnapshot?.following || {};
      }

      if (needFollowers) {
        const step = needFollowing ? 2 : 1;
        await ftSetScanStatus({ status: 'scanning', step, totalSteps, message: 'Fetching followers list…' });
        followers = await fetchFollowsViaTab(athleteId, 'followers', scanId, scanTabId, async (count, pg) => {
          await ftSetScanStatus({ status: 'scanning', step, totalSteps, message: `Fetching followers… ${count} found (page ${pg})` });
        });
      } else {
        followers = existingSnapshot?.followers || {};
      }
    } finally {
      if (scanTabId !== null) {
        browser.tabs.remove(scanTabId).catch(() => {});
      }
    }

    await ftSetScanStatus({ status: 'scanning', step: totalSteps, totalSteps, message: 'Saving results…' });

    const snapshot = { date: Math.floor(Date.now() / 1000), followers, following };
    const snapshotData = await ftGetData();
    const events = ftComputeDiff(snapshotData.latestSnapshot, snapshot);
    await ftSaveSnapshot(snapshot, events);

    // Record the full-scan timestamp only when both lists were freshly fetched
    if (needFollowing && needFollowers) {
      await browser.storage.local.set({ ftLastFullScanAt: Date.now() });
    }

    const result = {
      followerCount: Object.keys(followers).length,
      followingCount: Object.keys(following).length,
      newEvents: events.length,
      isFirstScan: !snapshotData.latestSnapshot,
      listsScanned: listsToScan,
    };

    await ftSetScanStatus({ status: 'complete', completedAt: Math.floor(Date.now() / 1000), ...result });
    sendResponse({ success: true, ...result });
  } catch (e) {
    error('[follow-tracker] Scan failed:', e);
    const msg = e.message || 'Scan failed. Please try again.';
    await ftSetScanStatus({ status: 'error', error: msg });
    sendResponse({ success: false, error: msg });
  } finally {
    ftScanInProgress = false;
  }
}

// Query the active browser tab for the logged-in athlete ID via content script message
async function getAthleteIdFromActiveTab() {
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0]) return null;
    const response = await browser.tabs.sendMessage(tabs[0].id, { action: 'getAthleteId' });
    return response?.athleteId || null;
  } catch (_) {
    return null;
  }
}

// Handle passively intercepted follow data from networkInterceptor.js
async function handleNetworkCapture(message) {
  // Build a partial snapshot update — we accumulate pages into a pending object
  // stored under 'ftNetworkPending' until the page is fully loaded.
  const result = await browser.storage.local.get(['ftNetworkPending']);
  const pending = result.ftNetworkPending || { followers: {}, following: {} };

  const type = message.type; // 'followers' or 'following'
  if (type === 'followers' || type === 'following') {
    Object.assign(pending[type], message.athletes);
  }

  await browser.storage.local.set({ ftNetworkPending: pending });
  log(`[follow-tracker] Network capture: ${Object.keys(message.athletes).length} ${type}`);
}



