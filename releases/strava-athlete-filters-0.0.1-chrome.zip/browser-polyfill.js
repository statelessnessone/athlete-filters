/**
 * Browser API Compatibility Layer
 * Provides a unified API that works in both Firefox and Chrome
 * 
 * Firefox uses the 'browser' namespace (promises-based)
 * Chrome uses the 'chrome' namespace (callback-based, but newer versions support promises)
 * 
 * This polyfill ensures the 'browser' namespace is available in both browsers.
 * Requires Chrome 109+ or Firefox 109+ for proper promise support.
 * 
 * NOTE: This is a simple alias approach that works for modern Chrome 109+ which has
 * promise support on most APIs. For older Chrome versions that only have callbacks,
 * a more complex wrapper would be needed to promisify the callback-based APIs.
 * Since we target Chrome 109+ (per manifest.json), this simple approach is sufficient.
 */

(function() {
  'use strict';
  
  // Check if we're in Firefox (has native browser namespace) or Chrome
  if (typeof browser === 'undefined') {
    // We're in Chrome - create browser namespace as alias to chrome
    // Modern Chrome supports promises on most APIs, so we can use chrome directly
    if (typeof chrome !== 'undefined') {
      // Use self for service worker context, window for content script context
      const target = typeof window !== 'undefined' ? window : self;
      target.browser = chrome;
    } else {
      console.error('Browser extension API not available');
    }
  }
})();
