// Content script that runs on Strava dashboard
// 
// Performance Monitoring:
// - All filtering operations are timed with performance.now()
// - Storage operations (load/save) are timed and logged
// - Real-time progress indicator shows "X/Y" during filtering
// - Console logs include timing data with ✓, ⚡, and 📦 symbols:
//   ✓ = Completed filter operations
//   ⚡ = Feed update processing
//   📦 = Storage load/save operations
// - Check browser console for detailed performance metrics
console.log('[feed-groups] Content script loaded');

// Debug storage immediately on load
(async function debugStorageOnLoad() {
  try {
    const allData = await browser.storage.local.get(null);
    const groups = allData.groups || {};
    const groupCount = Object.keys(groups).length;
    const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
    console.log(`🔍 Storage Debug: ${groupCount} groups, ${totalAthletes} athletes loaded`);
    if (groupCount > 0) {
      console.log('   Groups:', Object.keys(groups));
    } else {
      console.warn('   ⚠️ No groups found in storage! Data may have been lost on reload.');
    }
  } catch (error) {
    console.error('   ❌ Failed to load storage:', error);
  }
})();

let currentFilter = null;
let selectedAthletes = []; // Batch selection mode
let lastSelectedGroupId = null; // Remember last group selection
let selectedAthletesPage = 1; // Current page for selected athletes pagination
const ATHLETES_PER_PAGE = 10; // Number of athletes to show per page
let isFiltering = false; // Prevent re-entrant filter operations

// Initialize the extension
function init() {
  console.log('[feed-groups] 🚀 init() called, pathname:', window.location.pathname);
  addAthleteSelectionHandlers();
  observeFeedChanges();
  createGroupManagementUI();
  // Removed: addProfilePageHandler() - was showing button on user's own profile
  addActivityPageHandlers();
  addTopFilterDropdown();
  
  addGroupLabelsToFollowingPages();
}

// Add click handlers to athlete names in the feed
function addAthleteSelectionHandlers() {
  // Find all athlete links ONLY within the feed entries
  // Scope to feed container to avoid adding buttons to sidebar, nav, etc.
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  const athleteLinks = [];
  
  let processedCount = 0;
  const MAX_LINKS_TO_PROCESS = 200; // Safety limit to prevent runaway processing
  
  feedEntries.forEach(entry => {
    const links = entry.querySelectorAll('a[href*="/athletes/"]');
    links.forEach(link => {
      // Skip avatar links - only add to athlete name links
      if (link.hasAttribute('data-testid') && 
          (link.getAttribute('data-testid').includes('avatar') || 
           link.getAttribute('data-testid').includes('owner-avatar'))) {
        return;
      }
      
      // Skip if link contains an image or svg (likely an avatar)
      if (link.querySelector('img, svg')) {
        return;
      }
      
      if (processedCount < MAX_LINKS_TO_PROCESS) {
        athleteLinks.push(link);
        processedCount++;
      }
    });
  });
  
  if (processedCount >= MAX_LINKS_TO_PROCESS) {
    console.warn(`[feed-groups] ⚠️ Hit link processing limit (${MAX_LINKS_TO_PROCESS})`);
  }
  
  athleteLinks.forEach(link => {
    // Skip if already processed to prevent duplicate event listeners
    if (link.getAttribute('data-strava-groups-processed')) return;
    
    link.setAttribute('data-strava-groups-processed', 'true');
    
    // Get athlete name before adding indicator
    const athleteName = link.textContent.trim();
    const athleteId = extractAthleteId(link.href);
    
    // Store original name as data attribute for robustness
    if (!link.getAttribute('data-athlete-name')) {
      link.setAttribute('data-athlete-name', athleteName);
    }
    
    // Add visual indicator
    const indicator = document.createElement('span');
    indicator.className = 'strava-groups-indicator';
    indicator.textContent = '+';
    indicator.title = 'Click to add to group';
    indicator.setAttribute('role', 'button');
    indicator.setAttribute('tabindex', '0');
    indicator.setAttribute('aria-label', `Add ${athleteName} to group`);
    
    // Store timeout ID on the element itself to avoid closure memory leaks
    indicator.dataset.feedbackTimeout = '';
    
    // Add click handler
    const handleSelect = async (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      const storedName = link.getAttribute('data-athlete-name');
      if (athleteId && storedName) {
        await selectAthlete({ id: athleteId, name: storedName });
        
        // Clear any existing timeout
        const existingTimeout = indicator.dataset.feedbackTimeout;
        if (existingTimeout) {
          clearTimeout(Number(existingTimeout));
        }
        
        // Visual feedback
        const originalText = indicator.textContent;
        indicator.textContent = '✓';
        const timeout = setTimeout(() => {
          indicator.textContent = originalText;
          delete indicator.dataset.feedbackTimeout;
        }, 1000);
        indicator.dataset.feedbackTimeout = String(timeout);
      }
    };
    
    indicator.addEventListener('click', handleSelect);
    
    // Keyboard accessibility - handle Enter and Space keys
    indicator.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleSelect(e);
      }
    });
    
    // Append indicator to the link
    link.appendChild(indicator);
  });
}

// Extract athlete ID from URL
function extractAthleteId(url) {
  const match = url.match(/\/athletes\/(\d+)/);
  return match ? match[1] : null;
}

// Save selected athlete to storage
async function selectAthlete(athlete) {
  // Add to batch selection
  const existing = selectedAthletes.find(a => a.id === athlete.id);
  if (!existing) {
    selectedAthletes.push(athlete);
    console.log('[feed-groups] Added to selection:', athlete, 'Total selected:', selectedAthletes.length);
    
    // Jump to last page to show newly added athlete
    const totalPages = Math.ceil(selectedAthletes.length / ATHLETES_PER_PAGE);
    selectedAthletesPage = totalPages;
  }
  
  // Also save to storage for backward compatibility
  await browser.storage.local.set({ selectedAthlete: athlete });
  
  // Update UI to show batch count
  updateSelectedAthleteUI();
  
  // Open the side panel automatically
  openGroupManagementPanel();
  
  // Show notification
  const pageInfo = selectedAthletes.length > ATHLETES_PER_PAGE 
    ? ` (page ${selectedAthletesPage})`
    : '';
  showNotification(`Selected: ${sanitizeText(athlete.name)} (${selectedAthletes.length} total${pageInfo})`);
}

// Sanitize text for display - removes control characters
function sanitizeText(text) {
  const str = String(text);
  // Remove non-printable ASCII control characters except common whitespace
  return str.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
}

// Show temporary notification
function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'strava-groups-notification';
  notification.textContent = message; // Message is already sanitized by caller
  
  document.body.appendChild(notification);
  
  // Cleanup function
  const cleanup = () => {
    if (notification.isConnected) {
      notification.remove();
    }
    window.removeEventListener('beforeunload', cleanup);
  };
  
  // Store timeout for cleanup
  const timeoutId = setTimeout(() => {
    cleanup();
  }, 2000);
  
  // Also cleanup on page unload (clear timeout to prevent errors)
  window.addEventListener('beforeunload', () => {
    clearTimeout(timeoutId);
    cleanup();
  }, { once: true });
}

// Show custom confirmation dialog (replacement for browser confirm())
function showConfirmDialog(message) {
  return new Promise((resolve) => {
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'strava-groups-confirm-overlay';
    
    // Create dialog
    const dialog = document.createElement('div');
    dialog.className = 'strava-groups-confirm-dialog';
    
    // Create message
    const messageEl = document.createElement('div');
    messageEl.className = 'strava-groups-confirm-message';
    messageEl.textContent = message;
    
    // Create buttons container
    const buttons = document.createElement('div');
    buttons.className = 'strava-groups-confirm-buttons';
    
    // Create Cancel button
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'strava-groups-confirm-btn strava-groups-confirm-cancel';
    cancelBtn.textContent = 'Cancel';
    
    // Create Confirm button
    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'strava-groups-confirm-btn strava-groups-confirm-ok';
    confirmBtn.textContent = 'Confirm';
    
    // Cleanup function
    const cleanup = () => {
      if (overlay.isConnected) {
        overlay.remove();
      }
    };
    
    // Handle Cancel
    cancelBtn.addEventListener('click', () => {
      cleanup();
      resolve(false);
    });
    
    // Handle Confirm
    confirmBtn.addEventListener('click', () => {
      cleanup();
      resolve(true);
    });
    
    // Handle Escape key
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        cleanup();
        document.removeEventListener('keydown', handleEscape);
        resolve(false);
      }
    };
    document.addEventListener('keydown', handleEscape);
    
    // Assemble dialog
    buttons.appendChild(cancelBtn);
    buttons.appendChild(confirmBtn);
    dialog.appendChild(messageEl);
    dialog.appendChild(buttons);
    overlay.appendChild(dialog);
    
    // Add to page
    document.body.appendChild(overlay);
    
    // Focus confirm button
    confirmBtn.focus();
  });
}

// Debounce helper - maintains its own timer in closure
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Observe DOM changes to handle dynamically loaded content
// Note: Observer persists for the lifetime of the page. Strava is an SPA,
// so the observer will continue working during in-app navigation.
function observeFeedChanges() {
  let mutationCount = 0;
  let lastResetTime = Date.now();
  const MAX_MUTATIONS_PER_SECOND = 10; // Safety limit
  
  // Debounced handler to reduce processing frequency
  const debouncedHandler = debounce(() => {
    // Safety check: reset counter every second
    const now = Date.now();
    if (now - lastResetTime > 1000) {
      mutationCount = 0;
      lastResetTime = now;
    }
    
    // Prevent excessive processing
    if (mutationCount >= MAX_MUTATIONS_PER_SECOND) {
      console.warn('[feed-groups] ⚠️ Mutation rate limit hit, skipping update');
      return;
    }
    mutationCount++;
    
    const startTime = performance.now();
    
    addAthleteSelectionHandlers();
    if (currentFilter) {
      applyCurrentFilter();
    }
    
    const duration = (performance.now() - startTime).toFixed(2);
    console.log(`[feed-groups] ⚡ Feed update processed in ${duration}ms (${mutationCount}/${MAX_MUTATIONS_PER_SECOND})`);
  }, 300);
  
  const observer = new MutationObserver((mutations) => {
    // Filter out mutations that are just our progress indicator updating
    const hasRelevantChanges = mutations.some(mutation => {
      // Ignore changes to our progress indicator
      if (mutation.target.id === 'strava-groups-filter-progress') {
        return false;
      }
      // Ignore changes inside our extension UI elements
      if (mutation.target.closest && (
        mutation.target.closest('#strava-groups-filter-progress') ||
        mutation.target.closest('#strava-groups-top-filter') ||
        mutation.target.closest('.strava-groups-side-panel')
      )) {
        return false;
      }
      
      return mutation.addedNodes.length > 0 || mutation.removedNodes.length > 0;
    });
    
    if (hasRelevantChanges) {
      debouncedHandler();
    }
  });
  
  // Try to observe a more specific container if possible
  // Note: Using specific selectors to avoid matching unintended elements
  const feedContainer = document.querySelector('#dashboard-feed, main[class*="feed"], [data-testid="feed"], .feature-feed');
  const targetElement = feedContainer || document.body;
  
  if (!feedContainer) {
    console.warn('[feed-groups] ⚠️ Feed container not found, observing document.body (may impact performance)');
  } else {
    console.log('[feed-groups] ✓ Observing feed container:', targetElement.className || targetElement.id);
  }
  
  observer.observe(targetElement, {
    childList: true,
    subtree: true,
    // Don't observe attributes or character data to reduce callbacks
    attributes: false,
    characterData: false
  });
  
  // Store observer reference for potential cleanup
  window._stravaGroupsObserver = observer;
}

// Apply filter to feed
async function applyFilter(groupId) {
  console.log('[feed-groups] applyFilter called with groupId:', groupId);
  
  if (!groupId) {
    clearCurrentFilter();
    return;
  }
  
  // Handle virtual "Ungrouped" filter
  if (groupId === '__ungrouped__') {
    await applyUngroupedFilter();
    return;
  }
  
  // Handle virtual "No Kudos" filter
  if (groupId === '__nokudos__') {
    await applyNoKudosFilter();
    return;
  }
  
  // Always fetch fresh data from storage to get the latest athlete list
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  const group = groups[groupId];
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  console.log(`📦 Storage loaded in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  if (!group) {
    console.error('Group not found:', groupId);
    showNotification('Error: Group not found');
    return;
  }
  
  console.log('[feed-groups] Filtering by group:', group.name, 'Athletes:', group.athletes);
  
  // Store the groupId instead of the group object to always fetch fresh data
  currentFilter = {
    id: groupId,
    name: group.name,
    athletes: group.athletes
  };
  
  applyCurrentFilter();
  
  showNotification(`Filtering by: ${sanitizeText(group.name)}`);
}

// Apply filter for athletes not in any group
async function applyUngroupedFilter() {
  const startTime = performance.now();
  
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  console.log(`📦 Storage loaded in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  // Collect all athlete IDs that are in groups
  const groupedAthleteIds = new Set();
  for (const group of Object.values(groups)) {
    if (group.athletes) {
      group.athletes.forEach(athlete => groupedAthleteIds.add(athlete.id));
    }
  }
  
  console.log('[feed-groups] Athletes in groups:', Array.from(groupedAthleteIds));
  
  // Find all athletes in the feed
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  const ungroupedAthletes = [];
  
  feedEntries.forEach(entry => {
    const athleteLink = entry.querySelector('a[href*="/athletes/"]:not([href*="/training"]):not([href*="/calendar"])');
    if (athleteLink) {
      const athleteId = extractAthleteId(athleteLink.href);
      if (athleteId && !groupedAthleteIds.has(athleteId)) {
        const athleteName = athleteLink.getAttribute('data-athlete-name') || athleteLink.textContent.trim();
        ungroupedAthletes.push({ id: athleteId, name: athleteName });
      }
    }
  });
  
  const scanTime = (performance.now() - startTime).toFixed(2);
  console.log(`[feed-groups] ✓ Ungrouped scan completed in ${scanTime}ms: ${ungroupedAthletes.length} athletes found`);
  
  // Set current filter to ungrouped athletes
  currentFilter = {
    id: '__ungrouped__',
    name: 'Ungrouped',
    athletes: ungroupedAthletes
  };
  
  applyCurrentFilter();
  showNotification(`Filtering by: Ungrouped (${ungroupedAthletes.length} athletes)`);
}

// Apply filter for activities without kudos
async function applyNoKudosFilter() {
  const startTime = performance.now();
  console.log('[feed-groups] Applying No Kudos filter');
  
  // Find all feed entries
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  const noKudosActivities = [];
  
  feedEntries.forEach(entry => {
    // Check if the activity has been given kudos by looking for the kudos button state
    // Strava uses a filled SVG path when kudos have been given
    const kudosButton = entry.querySelector('button[data-testid="kudos_button"], button.kudo-btn, button[class*="kudos"], button[class*="Kudo"]');
    
    if (kudosButton) {
      // Check for filled kudos icon - Strava uses a filled path when kudos are given
      const filledPath = kudosButton.querySelector('path[d*="M14.625 10.96V9.5"]');
      const emptyPath = kudosButton.querySelector('path[d*="M13.5 9.062"]'); // Outline/empty version
      
      // Also check other indicators
      const hasKudos = filledPath || 
                       kudosButton.classList.contains('active') ||
                       kudosButton.classList.contains('given') ||
                       kudosButton.classList.contains('filled') ||
                       kudosButton.getAttribute('aria-pressed') === 'true' ||
                       kudosButton.querySelector('.icon-kudo.active') ||
                       kudosButton.querySelector('[class*="filled"]') ||
                       kudosButton.querySelector('svg[class*="active"]') ||
                       kudosButton.querySelector('svg[class*="filled"]');
      
      if (!hasKudos) {
        // Get athlete info from this entry
        const athleteLink = entry.querySelector('a[href*="/athletes/"]:not([href*="/training"]):not([href*="/calendar"])');
        if (athleteLink) {
          const athleteId = extractAthleteId(athleteLink.href);
          const athleteName = athleteLink.getAttribute('data-athlete-name') || athleteLink.textContent.trim();
          
          // Check if we already have this athlete (avoid duplicates)
          if (athleteId && !noKudosActivities.find(a => a.id === athleteId)) {
            noKudosActivities.push({ id: athleteId, name: athleteName });
          }
        }
      }
    }
  });
  
  const scanTime = (performance.now() - startTime).toFixed(2);
  console.log(`[feed-groups] ✓ No Kudos scan completed in ${scanTime}ms: ${noKudosActivities.length} activities found`);
  
  // Set current filter to no kudos activities
  currentFilter = {
    id: '__nokudos__',
    name: 'No Kudos',
    athletes: noKudosActivities
  };
  
  applyCurrentFilter();
  showNotification(`Filtering by: No Kudos (${noKudosActivities.length} activities)`);
}

// Apply the current filter to the feed
// Note: Feed entry selectors are based on Strava's current DOM structure (as of Jan 2026)
// The main feed entry container is div[data-testid="web-feed-entry"] which contains
// both the athlete header and the activity details.
function applyCurrentFilter() {
  if (!currentFilter) return;
  
  // Prevent re-entrant calls while filtering is in progress
  if (isFiltering) {
    console.log('[feed-groups] ⏭️ Skipping filter - already in progress');
    return;
  }
  
  isFiltering = true;
  
  // Start performance tracking
  const startTime = performance.now();
  
  // For "No Kudos" filter, we need to rescan each time because kudos status can change
  // and new activities are loaded dynamically
  if (currentFilter.id === '__nokudos__') {
    applyNoKudosFilterDirect();
    isFiltering = false;
    return;
  }
  
  const athleteIds = currentFilter.athletes.map(a => a.id);
  console.log('Applying filter for athlete IDs:', athleteIds);
  
  // Find all feed entries - Strava uses data-testid="web-feed-entry" for each feed item
  let feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  
  // Fallback: if Strava changed the structure, use the old selectors
  if (feedEntries.length === 0) {
    console.log('No web-feed-entry found, trying fallback selectors');
    feedEntries = document.querySelectorAll('[class*="feed-entry"], [class*="Activity"], div[data-testid*="activity"]');
  }
  
  console.log(`[feed-groups] Found ${feedEntries.length} feed entries to filter`);
  
  const totalEntries = feedEntries.length;
  let hiddenCount = 0;
  let shownCount = 0;
  let processedCount = 0;
  
  // Show initial progress
  updateFilterProgress(0, totalEntries);
  
  feedEntries.forEach((entry, index) => {
    // Look for athlete links within this entry
    // Filter out links that are for training/calendar (not actual athlete profile links)
    const athleteLinks = entry.querySelectorAll('a[href*="/athletes/"]:not([href*="/training"]):not([href*="/calendar"])');
    let shouldShow = false;
    
    athleteLinks.forEach(link => {
      const athleteId = extractAthleteId(link.href);
      if (athleteId && athleteIds.includes(athleteId)) {
        shouldShow = true;
      }
    });
    
    // Hide or show the entry
    if (shouldShow) {
      entry.style.display = '';
      shownCount++;
    } else {
      entry.style.display = 'none';
      hiddenCount++;
    }
    
    processedCount++;
    
    // Update progress every 5 items to avoid too many DOM updates
    if (processedCount % 5 === 0 || processedCount === totalEntries) {
      updateFilterProgress(processedCount, totalEntries);
    }
  });
  
  // Calculate and log performance
  const endTime = performance.now();
  const duration = (endTime - startTime).toFixed(2);
  
  console.log(`[feed-groups] ✓ Filter applied in ${duration}ms: ${shownCount} shown, ${hiddenCount} hidden`);
  
  // Show final count without "processing" indicator
  updateFilterProgress(totalEntries, totalEntries, shownCount, true);
  
  // Reset filtering flag
  isFiltering = false;
  
  // Clear progress after 3 seconds
  setTimeout(() => clearFilterProgress(), 3000);
}

// Update filter progress indicator
function updateFilterProgress(processed, total, shownCount = null, isFinal = false) {
  const progressEl = document.getElementById('strava-groups-filter-progress');
  if (!progressEl) return;
  
  if (isFinal && shownCount !== null) {
    // Show final result
    progressEl.textContent = `✓ ${shownCount} shown`;
    progressEl.style.color = '#4CAF50';
  } else {
    // Show progress
    progressEl.textContent = `Filtering... ${processed}/${total}`;
    progressEl.style.color = '#FC4C02';
  }
}

// Clear filter progress indicator
function clearFilterProgress() {
  const progressEl = document.getElementById('strava-groups-filter-progress');
  if (progressEl) {
    progressEl.textContent = '';
  }
}

// Apply "No Kudos" filter directly by scanning kudos status in real-time
// This is called from applyCurrentFilter() when filter is __nokudos__
function applyNoKudosFilterDirect() {
  const startTime = performance.now();
  console.log('Applying No Kudos filter (direct scan)');
  
  // Find all feed entries
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  console.log(`Found ${feedEntries.length} feed entries to scan for kudos status`);
  
  let hiddenCount = 0;
  let shownCount = 0;
  let processedCount = 0;
  const totalEntries = feedEntries.length;
  
  // Show initial progress
  updateFilterProgress(0, totalEntries);
  
  feedEntries.forEach((entry, index) => {
    // Check if the activity has been given kudos by looking for the kudos button state
    const kudosButton = entry.querySelector('button[data-testid="kudos_button"], button.kudo-btn, button[class*="kudos"], button[class*="Kudo"]');
    
    let hasKudos = false;
    if (kudosButton) {
      // Check for filled kudos icon - Strava uses a filled path when kudos are given
      const filledPath = kudosButton.querySelector('path[d*="M14.625 10.96V9.5"]');
      
      // Also check other indicators
      hasKudos = filledPath || 
                 kudosButton.classList.contains('active') ||
                 kudosButton.classList.contains('given') ||
                 kudosButton.classList.contains('filled') ||
                 kudosButton.getAttribute('aria-pressed') === 'true' ||
                 kudosButton.querySelector('.icon-kudo.active') ||
                 kudosButton.querySelector('[class*="filled"]') ||
                 kudosButton.querySelector('svg[class*="active"]') ||
                 kudosButton.querySelector('svg[class*="filled"]');
    }
    
    // Show only activities WITHOUT kudos
    if (!hasKudos && kudosButton) {
      entry.style.display = '';
      shownCount++;
    } else {
      entry.style.display = 'none';
      hiddenCount++;
    }
    
    processedCount++;
    
    // Update progress every 5 items to avoid too many DOM updates
    if (processedCount % 5 === 0 || processedCount === totalEntries) {
      updateFilterProgress(processedCount, totalEntries);
    }
  });
  
  const duration = (performance.now() - startTime).toFixed(2);
  console.log(`[feed-groups] ✓ No Kudos filter applied in ${duration}ms: ${shownCount} shown, ${hiddenCount} hidden`);
  
  // Show final count
  updateFilterProgress(totalEntries, totalEntries, shownCount, true);
  
  // Clear progress after 3 seconds
  setTimeout(() => clearFilterProgress(), 3000);
}

// Clear filter
function clearCurrentFilter() {
  currentFilter = null;
  
  console.log('Clearing filter');
  
  // Show all feed entries - use the same selector as applyCurrentFilter()
  let feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  
  // Fallback for older Strava structure
  if (feedEntries.length === 0) {
    console.log('Using fallback selectors to clear filter');
    feedEntries = document.querySelectorAll('[class*="feed-entry"], [class*="Activity"], div[data-testid*="activity"]');
  }
  
  console.log(`[feed-groups] Clearing filter on ${feedEntries.length} elements`);
  
  feedEntries.forEach(entry => {
    entry.style.display = '';
  });
  
  showNotification('Filter cleared');
}

// Listen for messages from popup
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[feed-groups] Received message:', message);
  
  if (message.action === 'applyFilter') {
    applyFilter(message.groupId);
  } else if (message.action === 'clearFilter') {
    clearCurrentFilter();
  }
  
  return true;
});

// Listen for storage changes and re-apply filter if groups are updated
browser.storage.onChanged.addListener(async (changes, area) => {
  if (area === 'local' && changes.groups && currentFilter) {
    console.log('[feed-groups] Groups updated in storage, re-applying filter');
    // Re-fetch the current filter group with updated athlete list
    await applyFilter(currentFilter.id);
  }
  
  // Update the UI if groups changed
  if (area === 'local' && changes.groups) {
    updateGroupManagementUI();
  }
  
  // Update selected athlete display
  if (area === 'local' && changes.selectedAthlete) {
    updateSelectedAthleteUI();
  }
});

// Add handler for athlete profile pages
function addProfilePageHandler() {
  // Check if we're on an athlete profile page
  const urlMatch = window.location.pathname.match(/\/athletes\/(\d+)/);
  if (!urlMatch) return;
  
  const athleteId = urlMatch[1];
  
  // Find the athlete's name on the profile page
  // Strava typically shows it in the header
  const findAthleteName = () => {
    // Try different selectors for athlete name
    const nameSelectors = [
      '.athlete-name',
      'h1.text-title1',
      '[data-testid="athlete-name"]',
      'h1'
    ];
    
    for (const selector of nameSelectors) {
      const nameElement = document.querySelector(selector);
      if (nameElement && nameElement.textContent.trim()) {
        return nameElement.textContent.trim();
      }
    }
    return 'Unknown Athlete';
  };
  
  // Add a button to select this athlete
  const addSelectButton = () => {
    // Don't add if already added
    if (document.getElementById('strava-groups-profile-select')) return;
    
    const athleteName = findAthleteName();
    
    // Create select button
    const selectButton = document.createElement('button');
    selectButton.id = 'strava-groups-profile-select';
    selectButton.className = 'strava-groups-profile-select-btn';
    selectButton.innerHTML = '<span style="color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; padding: 0 4px; margin-right: 4px;">+</span>Add to Group';
    selectButton.title = 'Select this athlete to add to a group';
    
    selectButton.addEventListener('click', async () => {
      await selectAthlete({ id: athleteId, name: athleteName });
      selectButton.innerHTML = '✓ Selected';
      setTimeout(() => {
        selectButton.innerHTML = '<span style="color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; padding: 0 4px; margin-right: 4px;">+</span>Add to Group';
      }, 2000);
    });
    
    // Try to find a good location to insert the button
    // Look for the athlete actions area or header
    const insertLocations = [
      '.athlete-profile-header .actions',
      '.page-header .actions',
      'header .actions',
      '.athlete-profile-header',
      '.page-header',
      'header'
    ];
    
    for (const selector of insertLocations) {
      const container = document.querySelector(selector);
      if (container) {
        container.appendChild(selectButton);
        console.log('Added profile select button to:', selector);
        return;
      }
    }
    
    // Fallback: add to body with fixed positioning
    selectButton.style.position = 'fixed';
    selectButton.style.top = '80px';
    selectButton.style.right = '20px';
    selectButton.style.zIndex = '9998';
    document.body.appendChild(selectButton);
    console.log('Added profile select button to body (fallback)');
  };
  
  // Add button when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addSelectButton);
  } else {
    addSelectButton();
  }
  
  // Re-add button if DOM changes (for SPA navigation)
  setTimeout(addSelectButton, 1000);
}

// Add handlers for activity pages to select athletes who participated
function addActivityPageHandlers() {
  // Check if we're on an activity page
  const urlMatch = window.location.pathname.match(/\/activities\/(\d+)/);
  if (!urlMatch) return;
  
  // Add selection indicators to athletes who did this activity with you
  const addActivityAthleteHandlers = () => {
    // Find athlete links in the activity (e.g., in kudos, comments, or participants)
    const athleteLinks = document.querySelectorAll('a[href*="/athletes/"]:not([data-strava-groups-processed])');
    
    athleteLinks.forEach(link => {
      const athleteId = extractAthleteId(link.href);
      if (!athleteId) return;
      
      // Skip if it's a training/calendar link
      if (link.href.includes('/training') || link.href.includes('/calendar')) return;
      
      // Skip avatar links - only add to athlete name links
      if (link.hasAttribute('data-testid') && 
          (link.getAttribute('data-testid').includes('avatar') || 
           link.getAttribute('data-testid').includes('owner-avatar'))) {
        return;
      }
      
      // Skip if link contains an image or svg (likely an avatar)
      if (link.querySelector('img, svg')) {
        return;
      }
      
      // Skip if already processed
      if (link.getAttribute('data-strava-groups-processed')) return;
      
      link.setAttribute('data-strava-groups-processed', 'true');
      
      const athleteName = link.textContent.trim();
      
      // Store original name
      if (!link.getAttribute('data-athlete-name')) {
        link.setAttribute('data-athlete-name', athleteName);
      }
      
      // Add indicator
      const indicator = document.createElement('span');
      indicator.className = 'strava-groups-indicator';
      indicator.textContent = '+';
      indicator.title = 'Click to add to group';
      indicator.setAttribute('role', 'button');
      indicator.setAttribute('tabindex', '0');
      indicator.setAttribute('aria-label', `Add ${athleteName} to group`);
      
      // Store timeout ID on the element itself to avoid closure memory leaks
      indicator.dataset.feedbackTimeout = '';
      
      const handleSelect = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const storedName = link.getAttribute('data-athlete-name');
        if (athleteId && storedName) {
          await selectAthlete({ id: athleteId, name: storedName });
          
          const existingTimeout = indicator.dataset.feedbackTimeout;
          if (existingTimeout) {
            clearTimeout(Number(existingTimeout));
          }
          
          const originalText = indicator.textContent;
          indicator.textContent = '✓';
          const timeout = setTimeout(() => {
            indicator.textContent = originalText;
            delete indicator.dataset.feedbackTimeout;
          }, 1000);
          indicator.dataset.feedbackTimeout = String(timeout);
        }
      };
      
      indicator.addEventListener('click', handleSelect);
      indicator.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleSelect(e);
        }
      });
      
      link.appendChild(indicator);
    });
  };
  
  // Add handlers when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addActivityAthleteHandlers);
  } else {
    addActivityAthleteHandlers();
  }
  
  // Observe for dynamically loaded content (comments, kudos)
  const observer = new MutationObserver(debounce(addActivityAthleteHandlers, 300));
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// Open the group management panel
function openGroupManagementPanel() {
  const panel = document.getElementById('strava-groups-panel');
  if (panel && !panel.classList.contains('open')) {
    panel.classList.add('open');
  }
}

// Create the group management UI on the page
function createGroupManagementUI() {
  // Create simple floating button in top-right corner
  const floatingButton = document.createElement('button');
  floatingButton.id = 'strava-groups-floating-btn';
  floatingButton.className = 'strava-groups-floating-btn';
  floatingButton.innerHTML = '👥';
  floatingButton.title = 'Manage Athlete Filters';
  floatingButton.setAttribute('aria-label', 'Open group management panel');
  
  // Add button directly to body
  document.body.appendChild(floatingButton);
  
  // Create side panel
  const panel = document.createElement('div');
  panel.id = 'strava-groups-panel';
  panel.className = 'strava-groups-panel';
  panel.innerHTML = `
    <div class="strava-groups-panel-header">
      <h2>Athlete Filters</h2>
      <button class="strava-groups-close-btn" aria-label="Close panel">✕</button>
    </div>
    
    <!-- Tab Navigation -->
    <div class="strava-groups-tabs">
      <button class="strava-groups-tab active" data-tab="selected">Selected Athletes</button>
      <button class="strava-groups-tab" data-tab="groups">Groups</button>
      <button class="strava-groups-tab" data-tab="backup">Backup</button>
      <button class="strava-groups-tab" data-tab="about">About</button>
    </div>
    
    <div class="strava-groups-panel-content">
      <!-- Selected Athletes Tab -->
      <div class="strava-groups-tab-content active" data-tab-content="selected">
        <div class="strava-groups-section">
          <div class="strava-groups-section-header">
            <h3>Selected Athletes (<span id="strava-groups-selected-count">0</span>)</h3>
            <button id="strava-groups-clear-selection" class="strava-groups-text-btn" style="display: none;">Clear All</button>
          </div>
          <div id="strava-groups-selected-athlete" class="strava-groups-selected-info">
            <p>Click the <span style="display: inline-flex; align-items: center; justify-content: center; color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; width: 18px; height: 18px; font-size: 14px; line-height: 1;">+</span> icon next to athlete names to select them</p>
          </div>
        </div>
        
        <div class="strava-groups-section" id="strava-groups-add-section" style="display: none;">
          <h3>Add Selected to Group</h3>
          <div class="strava-groups-input-group">
            <select id="strava-groups-select"></select>
            <button id="strava-groups-add-btn">Add</button>
          </div>
        </div>
        
        <div class="strava-groups-section">
          <h3>Create New Group</h3>
          <div class="strava-groups-input-group">
            <input type="text" id="strava-groups-new-group-name" placeholder="Group name..." maxlength="50">
            <button id="strava-groups-create-btn">Create</button>
          </div>
        </div>
      </div>
      
      <!-- Groups Management Tab -->
      <div class="strava-groups-tab-content" data-tab-content="groups">
        <div class="strava-groups-section">
          <h3>Your Groups</h3>
          <div id="strava-groups-list"></div>
        </div>
      </div>
      
      <!-- Backup & Restore Tab -->
      <div class="strava-groups-tab-content" data-tab-content="backup">
        <div class="strava-groups-section">
          <h3>Backup & Restore</h3>
          <div class="strava-groups-import-export">
            <button id="strava-groups-export-btn" class="strava-groups-action-btn">📥 Export Data</button>
            <button id="strava-groups-import-btn" class="strava-groups-action-btn">📤 Import Data</button>
            <input type="file" id="strava-groups-import-file" accept=".json" style="display: none;">
          </div>
          <p class="strava-groups-help-text">Export to backup your groups and settings. Import to restore from a backup file.</p>
        </div>
      </div>
      
      <!-- About Tab -->
      <div class="strava-groups-tab-content" data-tab-content="about">
        <div class="strava-groups-section">
          <h3>About Athlete Filters</h3>
          <p class="strava-groups-about-text">This extension helps you organize and filter your Strava feed by creating athlete groups.</p>
          
          <h4>Features</h4>
          <ul class="strava-groups-feature-list">
            <li>Create custom groups of athletes</li>
            <li>Filter your feed by group</li>
            <li>View ungrouped athletes</li>
            <li>Filter activities without kudos</li>
            <li>Export and import your data</li>
          </ul>
          
          <h4>Privacy</h4>
          <p class="strava-groups-about-text">All data is stored locally in your browser. No information is sent to external servers. Your groups and athlete data never leave your device.</p>
          
          <h4>Data Storage</h4>
          <p class="strava-groups-about-text">Groups and athlete selections are stored using browser local storage. Use the Backup tab to export your data for safekeeping.</p>
        </div>
      </div>
    </div>
  `;
  
  // Add panel to page (button is inserted next to upload button in insertButton function)
  document.body.appendChild(panel);
  
  // Event listeners - stop propagation to prevent triggering Strava's upload menu
  floatingButton.addEventListener('click', (e) => {
    e.stopPropagation();
    e.preventDefault();
    panel.classList.toggle('open');
  });
  
  floatingButton.addEventListener('mouseenter', (e) => {
    e.stopPropagation();
  });
  
  floatingButton.addEventListener('mouseover', (e) => {
    e.stopPropagation();
  });
  
  floatingButton.addEventListener('mousedown', (e) => {
    e.stopPropagation();
  });
  
  panel.querySelector('.strava-groups-close-btn').addEventListener('click', () => {
    panel.classList.remove('open');
  });
  
  // Tab switching functionality
  const tabs = panel.querySelectorAll('.strava-groups-tab');
  const tabContents = panel.querySelectorAll('.strava-groups-tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.dataset.tab;
      
      // Remove active class from all tabs and contents
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(tc => tc.classList.remove('active'));
      
      // Add active class to clicked tab and corresponding content
      tab.classList.add('active');
      const targetContent = panel.querySelector(`[data-tab-content="${targetTab}"]`);
      if (targetContent) {
        targetContent.classList.add('active');
      }
    });
  });
  
  // Close on escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panel.classList.contains('open')) {
      panel.classList.remove('open');
    }
  });
  
  // Button event listeners
  document.getElementById('strava-groups-create-btn').addEventListener('click', createGroupFromUI);
  document.getElementById('strava-groups-add-btn').addEventListener('click', addAthletesToGroupFromUI);
  document.getElementById('strava-groups-clear-selection').addEventListener('click', clearSelectedAthletes);
  document.getElementById('strava-groups-export-btn').addEventListener('click', exportData);
  document.getElementById('strava-groups-import-btn').addEventListener('click', () => {
    const fileInput = document.getElementById('strava-groups-import-file');
    if (fileInput) {
      fileInput.click();
    } else {
  console.error('[feed-groups] ❌ File input not found!');
    }
  });
  document.getElementById('strava-groups-import-file').addEventListener('change', importData);
  
  // Enter key support for inputs
  document.getElementById('strava-groups-new-group-name').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      createGroupFromUI();
    }
  });
  
  // Remember last selected group
  document.getElementById('strava-groups-select').addEventListener('change', (e) => {
    lastSelectedGroupId = e.target.value;
  });
  
  // Initialize UI
  updateGroupManagementUI();
  updateSelectedAthleteUI();
}

// Update the groups list in the UI
async function updateGroupManagementUI() {
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  console.log(`[feed-groups] 📦 Storage loaded (UI update) in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  const groupsList = document.getElementById('strava-groups-list');
  const groupSelect = document.getElementById('strava-groups-select');
  
  if (!groupsList) return; // UI not created yet
  
  // Update groups list
  if (Object.keys(groups).length === 0) {
    groupsList.innerHTML = '<p class="strava-groups-empty">No groups yet</p>';
  } else {
    groupsList.innerHTML = '';
    
    // Sort groups alphabetically by name
    const sortedGroups = Object.entries(groups).sort((a, b) => 
      a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
    );
    
    for (const [groupId, group] of sortedGroups) {
      const groupDiv = document.createElement('div');
      groupDiv.className = 'strava-groups-group-item';
      
      const athleteCount = group.athletes ? group.athletes.length : 0;
      
      groupDiv.innerHTML = `
        <div class="strava-groups-group-header" data-group-id="${groupId}">
          <span class="strava-groups-group-name" data-group-id="${groupId}">${sanitizeText(group.name)}</span>
          <span class="strava-groups-group-count">${athleteCount} athlete${athleteCount !== 1 ? 's' : ''}</span>
          <button class="strava-groups-edit-btn" data-group-id="${groupId}" title="Edit group name">✏️</button>
          <button class="strava-groups-delete-btn" data-group-id="${groupId}" title="Delete group">🗑️</button>
        </div>
        <div class="strava-groups-athletes-list" style="display: none;"></div>
      `;
      
      // Toggle athletes list
      groupDiv.querySelector('.strava-groups-group-header').addEventListener('click', (e) => {
        if (e.target.classList.contains('strava-groups-delete-btn') || 
            e.target.classList.contains('strava-groups-edit-btn') ||
            e.target.tagName === 'INPUT') return;
        toggleAthletesListUI(groupDiv, group);
      });
      
      // Edit button
      groupDiv.querySelector('.strava-groups-edit-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        editGroupNameInline(groupId, group.name, e.target);
      });
      
      // Delete button
      groupDiv.querySelector('.strava-groups-delete-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        deleteGroupFromUI(groupId, group.name);
      });
      
      groupsList.appendChild(groupDiv);
    }
  }
  
  // Update select
  groupSelect.innerHTML = '<option value="">Select a group...</option>';
  
  // Sort groups alphabetically by name
  const sortedGroupsSelect = Object.entries(groups).sort((a, b) => 
    a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
  );
  
  for (const [groupId, group] of sortedGroupsSelect) {
    const option = document.createElement('option');
    option.value = groupId;
    option.textContent = group.name;
    groupSelect.appendChild(option);
  }
  
  // Restore last selected group
  if (lastSelectedGroupId && groups[lastSelectedGroupId]) {
    groupSelect.value = lastSelectedGroupId;
  }
  
  // Update top filter dropdown if it exists
  updateTopFilterDropdown();
}

// Update selected athlete display
async function updateSelectedAthleteUI() {
  const athleteDiv = document.getElementById('strava-groups-selected-athlete');
  const addSection = document.getElementById('strava-groups-add-section');
  const countSpan = document.getElementById('strava-groups-selected-count');
  const clearBtn = document.getElementById('strava-groups-clear-selection');
  
  if (!athleteDiv) return; // UI not created yet
  
  // Load groups to check membership
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  // Update count
  if (countSpan) {
    countSpan.textContent = selectedAthletes.length;
  }
  
  if (selectedAthletes.length > 0) {
    // Calculate pagination
    const totalPages = Math.ceil(selectedAthletes.length / ATHLETES_PER_PAGE);
    const startIndex = (selectedAthletesPage - 1) * ATHLETES_PER_PAGE;
    const endIndex = Math.min(startIndex + ATHLETES_PER_PAGE, selectedAthletes.length);
    const athletesToShow = selectedAthletes.slice(startIndex, endIndex);
    
    // Show list of selected athletes with pagination
    athleteDiv.innerHTML = '<div class="strava-groups-selected-list"></div>';
    const listDiv = athleteDiv.querySelector('.strava-groups-selected-list');
    
    athletesToShow.forEach((athlete, displayIndex) => {
      const actualIndex = startIndex + displayIndex;
      const athleteCard = document.createElement('div');
      athleteCard.className = 'strava-groups-athlete-card';
      
      // Find which groups this athlete belongs to
      const athleteGroups = [];
      for (const [groupId, group] of Object.entries(groups)) {
        if (group.athletes && group.athletes.some(a => String(a.id) === String(athlete.id))) {
          athleteGroups.push(group.name);
        }
      }
      
      // Sort groups alphabetically
      athleteGroups.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
      
      // Build the groups display HTML
      let groupsHTML = '';
      if (athleteGroups.length > 0) {
        const groupTags = athleteGroups.map(name => 
          `<span class="strava-groups-member-tag">${sanitizeText(name)}</span>`
        ).join('');
        groupsHTML = `
          <div class="strava-groups-member-of">
            <span class="strava-groups-member-label">Groups:</span>
            <div class="strava-groups-member-list">${groupTags}</div>
          </div>
        `;
      }
      
      athleteCard.innerHTML = `
        <div>
          <strong>${sanitizeText(athlete.name)}</strong>
          <span class="strava-groups-athlete-id">ID: ${athlete.id}</span>
          ${groupsHTML}
        </div>
        <button class="strava-groups-remove-selection-btn" data-index="${actualIndex}" title="Remove from selection">✕</button>
      `;
      
      athleteCard.querySelector('.strava-groups-remove-selection-btn').addEventListener('click', () => {
        selectedAthletes.splice(actualIndex, 1);
        // Reset to page 1 if current page would be empty
        if (selectedAthletes.length > 0 && startIndex >= selectedAthletes.length) {
          selectedAthletesPage = Math.max(1, selectedAthletesPage - 1);
        }
        updateSelectedAthleteUI();
      });
      
      listDiv.appendChild(athleteCard);
    });
    
    // Add pagination controls if needed
    if (totalPages > 1) {
      const paginationDiv = document.createElement('div');
      paginationDiv.className = 'strava-groups-pagination';
      
      const prevBtn = document.createElement('button');
      prevBtn.className = 'strava-groups-pagination-btn';
      prevBtn.textContent = '‹ Previous';
      prevBtn.disabled = selectedAthletesPage === 1;
      prevBtn.addEventListener('click', () => {
        selectedAthletesPage = Math.max(1, selectedAthletesPage - 1);
        updateSelectedAthleteUI();
      });
      
      const pageInfo = document.createElement('span');
      pageInfo.className = 'strava-groups-pagination-info';
      pageInfo.textContent = `Page ${selectedAthletesPage} of ${totalPages} (${startIndex + 1}-${endIndex} of ${selectedAthletes.length})`;
      
      const nextBtn = document.createElement('button');
      nextBtn.className = 'strava-groups-pagination-btn';
      nextBtn.textContent = 'Next ›';
      nextBtn.disabled = selectedAthletesPage === totalPages;
      nextBtn.addEventListener('click', () => {
        selectedAthletesPage = Math.min(totalPages, selectedAthletesPage + 1);
        updateSelectedAthleteUI();
      });
      
      paginationDiv.appendChild(prevBtn);
      paginationDiv.appendChild(pageInfo);
      paginationDiv.appendChild(nextBtn);
      athleteDiv.appendChild(paginationDiv);
    }
    
    addSection.style.display = 'block';
    if (clearBtn) clearBtn.style.display = 'inline-block';
  } else {
    athleteDiv.innerHTML = '<p>Click the <span style="display: inline-flex; align-items: center; justify-content: center; color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; width: 18px; height: 18px; font-size: 14px; line-height: 1;">+</span> icon next to athlete names to select them</p>';
    addSection.style.display = 'none';
    if (clearBtn) clearBtn.style.display = 'none';
    selectedAthletesPage = 1; // Reset page when cleared
  }
}

// Clear selected athletes
function clearSelectedAthletes() {
  selectedAthletes = [];
  updateSelectedAthleteUI();
  showNotification('Selection cleared');
}

// Toggle athletes list in a group
function toggleAthletesListUI(groupDiv, group) {
  const athletesList = groupDiv.querySelector('.strava-groups-athletes-list');
  
  if (athletesList.style.display === 'none') {
    if (!group.athletes || group.athletes.length === 0) {
      athletesList.innerHTML = '<p class="strava-groups-empty">No athletes in this group</p>';
    } else {
      athletesList.innerHTML = '';
      
      // Sort athletes alphabetically by name
      const sortedAthletes = [...group.athletes].sort((a, b) => 
        a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
      );
      
      sortedAthletes.forEach(athlete => {
        const athleteDiv = document.createElement('div');
        athleteDiv.className = 'strava-groups-athlete-item';
        athleteDiv.innerHTML = `
          <span>${sanitizeText(athlete.name)}</span>
          <button class="strava-groups-remove-btn" data-group-id="${group.id}" data-athlete-id="${athlete.id}" title="Remove from group">✕</button>
        `;
        
        athleteDiv.querySelector('.strava-groups-remove-btn').addEventListener('click', (e) => {
          e.stopPropagation();
          removeAthleteFromGroupUI(group.id, athlete.id);
        });
        
        athletesList.appendChild(athleteDiv);
      });
    }
    athletesList.style.display = 'block';
  } else {
    athletesList.style.display = 'none';
  }
}

// Create group from UI
async function createGroupFromUI() {
  const nameInput = document.getElementById('strava-groups-new-group-name');
  const name = nameInput.value.trim();
  
  if (!name) {
    showNotification('Please enter a group name');
    return;
  }
  
  if (name.length > 50) {
    showNotification('Group name must be 50 characters or less');
    return;
  }
  
  const sanitizedName = name.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  if (sanitizedName !== name) {
    showNotification('Group name contains invalid characters');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  const groupId = 'group_' + Date.now() + '_' + Math.random().toString(36).slice(2, 11);
  
  groups[groupId] = {
    id: groupId,
    name: sanitizedName,
    athletes: []
  };
  
  await browser.storage.local.set({ groups });
  
  nameInput.value = '';
  showNotification(`Group "${sanitizedName}" created`);
}

// Add athlete to group from UI
async function addAthletesToGroupFromUI() {
  if (selectedAthletes.length === 0) {
    showNotification('No athletes selected');
    return;
  }
  
  const groupSelect = document.getElementById('strava-groups-select');
  const groupId = groupSelect.value;
  
  if (!groupId) {
    showNotification('Please select a group');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (!groups[groupId]) {
    showNotification('Group not found');
    return;
  }
  
  let addedCount = 0;
  let skippedCount = 0;
  
  selectedAthletes.forEach(athlete => {
    if (!groups[groupId].athletes.some(a => a.id === athlete.id)) {
      groups[groupId].athletes.push(athlete);
      addedCount++;
    } else {
      skippedCount++;
    }
  });
  
  await browser.storage.local.set({ groups });
  
  // Clear selection after adding
  selectedAthletes = [];
  updateSelectedAthleteUI();
  
  const message = addedCount > 0 
    ? `Added ${addedCount} athlete${addedCount !== 1 ? 's' : ''} to ${groups[groupId].name}${skippedCount > 0 ? ` (${skippedCount} already in group)` : ''}`
    : `All selected athletes already in ${groups[groupId].name}`;
  
  showNotification(message);
  
  // Keep the group selected for next batch
  lastSelectedGroupId = groupId;
}

// Edit group name inline
async function editGroupNameInline(groupId, currentName, editButton) {
  // Find the group name span
  const nameSpan = document.querySelector(`.strava-groups-group-name[data-group-id="${groupId}"]`);
  if (!nameSpan) return;
  
  // Create input element
  const input = document.createElement('input');
  input.type = 'text';
  input.value = currentName;
  input.className = 'strava-groups-edit-input';
  input.style.width = '150px';
  input.style.fontSize = '14px';
  input.style.padding = '2px 6px';
  input.style.border = '1px solid #FC4C02';
  input.style.borderRadius = '3px';
  input.style.outline = 'none';
  
  // Function to save changes
  const saveEdit = async () => {
    const newName = input.value.trim();
    
    if (!newName) {
      showNotification('Group name cannot be empty');
      input.focus();
      return;
    }
    
    if (newName === currentName) {
      // No change, just restore
      nameSpan.textContent = currentName;
      nameSpan.style.display = '';
      editButton.style.display = '';
      input.remove();
      return;
    }
    
    // Save to storage
    const result = await browser.storage.local.get(['groups']);
    const groups = result.groups || {};
    
    if (groups[groupId]) {
      groups[groupId].name = newName;
      await browser.storage.local.set({ groups });
      
      // Update UI
      nameSpan.textContent = sanitizeText(newName);
      nameSpan.style.display = '';
      editButton.style.display = '';
      input.remove();
      
      // Update dropdown
      updateTopFilterDropdown();
      
      showNotification(`Renamed to "${sanitizeText(newName)}"`);
    }
  };
  
  // Function to cancel edit
  const cancelEdit = () => {
    nameSpan.style.display = '';
    editButton.style.display = '';
    input.remove();
  };
  
  // Handle enter key to save
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveEdit();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      cancelEdit();
    }
  });
  
  // Handle blur to save
  input.addEventListener('blur', saveEdit);
  
  // Replace span with input
  nameSpan.style.display = 'none';
  editButton.style.display = 'none';
  nameSpan.parentNode.insertBefore(input, nameSpan);
  input.focus();
  input.select();
}

// Delete group from UI
async function deleteGroupFromUI(groupId, groupName) {
  const confirmed = await showConfirmDialog(`Delete group "${groupName}"?`);
  if (!confirmed) {
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  delete groups[groupId];
  
  await browser.storage.local.set({ groups });
  
  showNotification('Group deleted');
}

// Remove athlete from group
async function removeAthleteFromGroupUI(groupId, athleteId) {
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (groups[groupId]) {
    groups[groupId].athletes = groups[groupId].athletes.filter(a => a.id !== athleteId);
    await browser.storage.local.set({ groups });
    showNotification('Athlete removed from group');
  }
}

// Apply filter from UI
function applyFilterFromUI() {
  const filterSelect = document.getElementById('strava-groups-filter-select');
  const groupId = filterSelect.value;
  
  if (groupId) {
    applyFilter(groupId);
  } else {
    clearCurrentFilter();
  }
}

// Add filter dropdown to the top of the page (next to Strava's filters)
function addTopFilterDropdown() {
  // Only add on dashboard or feed pages
  if (!window.location.pathname.match(/\/(dashboard|athlete\/training)/)) {
    return;
  }
  
  // Check if already added
  if (document.getElementById('strava-groups-top-filter')) {
    return;
  }
  
  // Function to try inserting the dropdown
  const tryInsertDropdown = () => {
    // Look for the feed filter form using stable selectors
    // Find form containing input#feedFilter
    // Note: :has() requires Firefox 121+, so we use fallback for Firefox 109-120
    const feedInput = document.querySelector('input#feedFilter');
    let form = feedInput?.closest('form');
    
    if (!form) {
      console.log('[feed-groups] Feed filter form not found yet (looking for input#feedFilter)');
      return false;
    }
    
    // Look for feed-header - try multiple locations
    let feedHeader = form.querySelector('.feed-header');
    if (!feedHeader) {
      // Try finding it as a sibling after the form
      feedHeader = form.nextElementSibling;
      if (feedHeader && !feedHeader.classList.contains('feed-header')) {
        feedHeader = null;
      }
    }
    if (!feedHeader) {
      // Try finding it in parent element
      feedHeader = form.parentElement?.querySelector('.feed-header');
    }
    
    // If still not found, create it inside the form (inline with Strava filter)
    // Complex insertion logic needed because Chrome and Firefox have different DOM structures
    // - Firefox: .feed-header exists as sibling
    // - Chrome: No .feed-header, need to insert into form and expand width
    let insertionPoint;
    if (feedHeader) {
      insertionPoint = feedHeader;
      console.log('[feed-groups] ✓ Found existing .feed-header');
    } else {
      // Expand the form to accommodate both dropdowns side-by-side
      // Without this, Strava's dropdown gets compressed
      form.style.maxWidth = 'none';
      form.style.justifyContent = 'flex-start';
      form.style.gap = '16px';
      
      // Create a div inside the form to hold our dropdown inline with Strava filter
      const wrapper = document.createElement('div');
      wrapper.style.cssText = 'display: inline-flex; align-items: center; flex-shrink: 0;';
      
      // Insert it at the end of the form (next to Strava filter)
      form.appendChild(wrapper);
      insertionPoint = wrapper;
      console.log('[feed-groups] ✓ Created inline wrapper inside form');
    }
    
    // Create our filter dropdown wrapper
    const filterWrapper = document.createElement('div');
    filterWrapper.id = 'strava-groups-top-filter';
    filterWrapper.className = 'strava-groups-top-filter';
    filterWrapper.style.cssText = 'display: inline-flex; align-items: center; gap: 8px;';
    
    const label = document.createElement('label');
    label.textContent = 'Group: ';
    label.style.marginRight = '8px';
    label.style.fontSize = '14px';
    label.style.color = '#666';
    
    const filterSelect = document.createElement('select');
    filterSelect.id = 'strava-groups-top-filter-select';
    filterSelect.className = 'strava-groups-top-filter-select';
    filterSelect.innerHTML = '<option value="">All Athletes</option>';
    
    filterSelect.addEventListener('change', async (e) => {
      const groupId = e.target.value;
      if (groupId) {
        await applyFilter(groupId);
      } else {
        clearCurrentFilter();
      }
      // Remove focus from dropdown so keyboard navigation (Home/End) works on page
      e.target.blur();
    });
    
    filterWrapper.appendChild(label);
    filterWrapper.appendChild(filterSelect);
    
    // Add progress indicator
    const progressIndicator = document.createElement('span');
    progressIndicator.id = 'strava-groups-filter-progress';
    progressIndicator.className = 'strava-groups-filter-progress';
    progressIndicator.style.marginLeft = '12px';
    progressIndicator.style.fontSize = '13px';
    progressIndicator.style.fontWeight = '500';
    filterWrapper.appendChild(progressIndicator);
    
    // Insert into the insertion point (feedHeader)
    // Try to append as first child or just append
    if (insertionPoint.firstChild) {
      insertionPoint.insertBefore(filterWrapper, insertionPoint.firstChild);
      console.log('✓ Inserted dropdown as first child');
    } else {
      insertionPoint.appendChild(filterWrapper);
      console.log('✓ Appended dropdown to container');
    }
    
    // Initialize with groups
    updateTopFilterDropdown();
    
    return true;
  };
  
  // Try immediately
  if (tryInsertDropdown()) {
    return;
  }
  
  // If not found, wait for it to appear
  console.log('[feed-groups] Waiting for form.uRdSO2YS and .feed-header to appear...');
  const observer = new MutationObserver((mutations, obs) => {
    if (tryInsertDropdown()) {
      obs.disconnect();
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Timeout after 10 seconds
  setTimeout(() => {
    observer.disconnect();
    if (!document.getElementById('strava-groups-top-filter')) {
      console.log('[feed-groups] ✗ Timeout: Could not add top filter dropdown after 10 seconds');
    }
  }, 10000);
}


// Update the top filter dropdown with current groups
async function updateTopFilterDropdown() {
  const filterSelect = document.getElementById('strava-groups-top-filter-select');
  if (!filterSelect) return;
  
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  console.log(`[feed-groups] 📦 Storage loaded (dropdown update) in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  // Store current value
  const currentValue = filterSelect.value;
  
  // Rebuild options
  filterSelect.innerHTML = '<option value="">All Athletes</option>';
  
  // Add virtual filters
  const ungroupedOption = document.createElement('option');
  ungroupedOption.value = '__ungrouped__';
  ungroupedOption.textContent = '🔍 Ungrouped Athletes';
  filterSelect.appendChild(ungroupedOption);
  
  const noKudosOption = document.createElement('option');
  noKudosOption.value = '__nokudos__';
  noKudosOption.textContent = '🤔 No Kudos';
  filterSelect.appendChild(noKudosOption);
  
  // Add separator if there are groups
  if (Object.keys(groups).length > 0) {
    const separator = document.createElement('option');
    separator.disabled = true;
    separator.textContent = '──────────';
    filterSelect.appendChild(separator);
  }
  
  // Sort groups alphabetically by name
  const sortedGroups = Object.entries(groups).sort((a, b) => 
    a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
  );
  
  for (const [groupId, group] of sortedGroups) {
    const option = document.createElement('option');
    option.value = groupId;
    option.textContent = group.name;
    filterSelect.appendChild(option);
  }
  
  // Restore selection
  if (currentValue && (currentValue === '__ungrouped__' || currentValue === '__nokudos__' || groups[currentValue])) {
    filterSelect.value = currentValue;
  } else if (currentFilter && currentFilter.id) {
    filterSelect.value = currentFilter.id;
  }
}

// Export all data to JSON file
async function exportData() {
  try {
    const storageStartTime = performance.now();
    const data = await browser.storage.local.get(null);
    const storageTime = (performance.now() - storageStartTime).toFixed(2);
    
    const dataSize = JSON.stringify(data).length;
    console.log(`[feed-groups] 📦 Storage exported in ${storageTime}ms: ${dataSize} bytes`);
    
    // Create export object with metadata
    const exportObj = {
      version: '1.0',
      exportDate: new Date().toISOString(),
      data: data
    };
    
    // Convert to JSON
    const jsonStr = JSON.stringify(exportObj, null, 2);
    
    // Create blob and download
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `strava-athlete-filters-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('✓ Data exported successfully');
    console.log('[feed-groups] Exported data:', exportObj);
  } catch (error) {
    console.error('[feed-groups] Export failed:', error);
    showNotification('✗ Export failed: ' + error.message);
  }
}

// Import data from JSON file
async function importData(event) {
  console.log('[feed-groups] 📤 importData function called', event);
  const file = event.target.files[0];
  console.log('[feed-groups] 📤 Selected file:', file);
  if (!file) {
    console.warn('[feed-groups] ⚠️ No file selected');
    return;
  }
  
  try {
    const text = await file.text();
    const importObj = JSON.parse(text);
    
    // Validate format
    if (!importObj.version || !importObj.data) {
      throw new Error('Invalid file format');
    }
    
    // Confirm before importing
    const groupCount = importObj.data.groups ? Object.keys(importObj.data.groups).length : 0;
    const totalAthletes = importObj.data.groups 
      ? Object.values(importObj.data.groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0)
      : 0;
    const message = `Import ${groupCount} groups (${totalAthletes} athletes) from ${importObj.exportDate || 'backup'}?\n\nThis will replace your current data.`;
    
    const confirmed = await showConfirmDialog(message);
    if (!confirmed) {
      event.target.value = ''; // Reset file input
      return;
    }
    
    // Import data with timing
    const importStartTime = performance.now();
    await browser.storage.local.clear();
    await browser.storage.local.set(importObj.data);
    const importTime = (performance.now() - importStartTime).toFixed(2);
    
    console.log(`[feed-groups] 📦 Storage imported in ${importTime}ms: ${groupCount} groups, ${totalAthletes} athletes`);
    
    // Refresh UI
    await updateGroupManagementUI();
    clearCurrentFilter();
    
    showNotification(`✓ Imported ${groupCount} groups successfully`);
    console.log('[feed-groups] Imported data:', importObj);
  } catch (error) {
    console.error('[feed-groups] Import failed:', error);
    showNotification('✗ Import failed: ' + error.message);
  } finally {
    event.target.value = ''; // Reset file input
  }
}

// Add group labels to following/followers pages
async function addGroupLabelsToFollowingPages() {
  console.log('🏷️ Checking if on following/followers page:', window.location.pathname);
  
  // Check if we're on a following/followers page
  const isFollowingPage = window.location.pathname.match(/\/athletes\/\d+\/follows/);
  
  if (!isFollowingPage) {
    console.log('❌ Not on following/followers page, skipping labels');
    return;
  }
  
  console.log('[feed-groups] ✅ On following/followers page, adding group labels');
  
  // Load groups from storage
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  console.log(`[feed-groups] 📦 Loaded ${Object.keys(groups).length} groups for labeling`);
  
  // Create athlete ID to groups mapping
  const athleteToGroups = {};
  for (const group of Object.values(groups)) {
    if (group.athletes) {
      for (const athlete of group.athletes) {
        if (!athleteToGroups[athlete.id]) {
          athleteToGroups[athlete.id] = [];
        }
        athleteToGroups[athlete.id].push(group.name);
      }
    }
  }
  
  console.log(`[feed-groups] 👥 ${Object.keys(athleteToGroups).length} athletes have group memberships`);
  
  // Keep reference to observer for disconnecting/reconnecting
  let observer = null;
  let processing = false;
  
  // Get the tab content element early so it's available in the closure
  const tabContent = document.querySelector('.tab-content');
  
  // Function to add labels to athlete entries
  const addLabelsToAthletes = () => {
    // Prevent re-entrant calls
    if (processing) {
      console.log('[feed-groups] ⏸️ Already processing, skipping...');
      return;
    }
    
    processing = true;
    
    // Disconnect observer while we make changes to prevent infinite loop
    if (observer) {
      observer.disconnect();
    }
    // Find athlete list items using the data-athlete-id attribute
    const athleteItems = document.querySelectorAll('ul.list-athletes li[data-athlete-id]');
    
    console.log(`[feed-groups] 🔍 Found ${athleteItems.length} athlete items in list`);
    
    let labeledCount = 0;
    
    athleteItems.forEach(item => {
      const athleteId = item.getAttribute('data-athlete-id');
      
      if (!athleteId) return;
      
      // Skip if already processed
      if (item.hasAttribute('data-strava-groups-processed')) return;
      
      // Find the text-callout div that contains the athlete name
      const nameContainer = item.querySelector('.text-callout');
      
      if (!nameContainer) return;
      
      // Mark as processed to prevent re-processing
      item.setAttribute('data-strava-groups-processed', 'true');
      
      // Get athlete name from the anchor tag inside text-callout
      const athleteLink = nameContainer.querySelector('a');
      const athleteName = athleteLink ? athleteLink.textContent.trim() : 'Unknown Athlete';
      
      // Create add button
      const addButton = document.createElement('button');
      addButton.className = 'strava-groups-add-btn';
      addButton.innerHTML = '<span style="color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; padding: 0 3px; font-size: 11px;">+</span>';
      addButton.title = 'Add to group';
      addButton.style.cssText = `
        background: none;
        border: none;
        cursor: pointer;
        padding: 0;
        margin-left: 6px;
        vertical-align: middle;
        display: inline-block;
      `;
      
      addButton.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await selectAthlete({ id: athleteId, name: athleteName });
        addButton.innerHTML = '<span style="color: #FC4C02; font-weight: bold;">✓</span>';
        setTimeout(() => {
          addButton.innerHTML = '<span style="color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; padding: 0 3px; font-size: 11px;">+</span>';
        }, 2000);
      });
      
      nameContainer.appendChild(addButton);
      
      // Add group labels if athlete belongs to any groups
      const groupNames = athleteToGroups[athleteId];
      
      if (groupNames) {
        // Sort groups alphabetically
        const sortedGroups = [...groupNames].sort((a, b) => 
          a.localeCompare(b, undefined, { sensitivity: 'base' })
        );
        
        // Create individual group badges and append inline to the name container
        sortedGroups.forEach((groupName) => {
          const badge = document.createElement('span');
          badge.className = 'strava-groups-badge';
          badge.textContent = groupName;
          badge.style.cssText = `
            display: inline-block;
            background: #fc5200;
            color: white;
            padding: 1px 5px;
            border-radius: 2px;
            margin-left: 6px;
            font-size: 10px;
            font-weight: 500;
            line-height: 1.2;
            vertical-align: middle;
          `;
          nameContainer.appendChild(badge);
        });
      }
      
      labeledCount++;
    });
    
    if (labeledCount > 0) {
      console.log(`[feed-groups] ✨ Added buttons and labels to ${labeledCount} athletes`);
    }
    
    // Reconnect observer after processing
    processing = false;
    if (observer && tabContent) {
      observer.observe(tabContent, {
        childList: true,
        subtree: true
      });
    }
  };
  
  // Add labels initially (with a delay to ensure DOM is ready)
  setTimeout(() => {
    addLabelsToAthletes();
  }, 500);
  
  // Observe for dynamic content loading (pagination)
  let observerTimeout;
  observer = new MutationObserver(() => {
    // Debounce: only run after mutations stop for 200ms
    clearTimeout(observerTimeout);
    observerTimeout = setTimeout(() => {
      addLabelsToAthletes();
    }, 200);
  });
  
  // Start observing
  if (tabContent) {
    console.log('👀 Observing .tab-content for changes');
    observer.observe(tabContent, {
      childList: true,
      subtree: true
    });
  } else {
    console.log('⚠️ .tab-content not found, labels may not update on pagination');
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
