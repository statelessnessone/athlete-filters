// Content script that runs on Strava dashboard
// 
// Performance Monitoring:
// - All filtering operations are timed with performance.now()
// - Storage operations (load/save) are timed and logged
// - Real-time progress indicator shows "X/Y" during filtering
// - Console logs include timing data with ✓, ⚡, and 📦 symbols:
//   ✓ = Completed filter operations
//   ⚡ = Feed update processing
//   📦 = Storage load/save operations
// - Check browser console for detailed performance metrics

// Debug mode (set to true for development)
const DEBUG = false;
const log = DEBUG ? console.log.bind(console) : () => {};
const warn = DEBUG ? console.warn.bind(console) : () => {};
const error = console.error.bind(console); // Always log errors

// Constants
const ATHLETES_PER_PAGE = 10;
const MAX_LINKS_TO_PROCESS = 200;
const MAX_MUTATIONS_PER_SECOND = 10;
const MUTATION_DEBOUNCE_MS = 300;
const FEED_SELECTOR = '[data-testid="web-feed-entry"]';
const ATHLETE_PROFILE_PATH_PATTERN = /^\/athletes\/[^/]+/;

// Event listener cleanup tracking
const eventListeners = new Map();

// Utility: Add tracked event listener
function addTrackedListener(element, event, handler, options) {
  element.addEventListener(event, handler, options);
  const key = `${element.tagName}-${event}-${Date.now()}`;
  eventListeners.set(key, { element, event, handler, options });
  return key;
}

// Utility: Remove tracked event listener
function removeTrackedListener(key) {
  const listener = eventListeners.get(key);
  if (listener) {
    listener.element.removeEventListener(listener.event, listener.handler, listener.options);
    eventListeners.delete(key);
  }
}

// Utility: Remove all tracked listeners
function cleanupAllListeners() {
  eventListeners.forEach((listener) => {
    listener.element.removeEventListener(listener.event, listener.handler, listener.options);
  });
  eventListeners.clear();
}

// Utility: Alphabetical sort comparator
function alphabeticalSort(a, b) {
  return a.localeCompare(b);
}

// Utility: Sort athletes by name
function sortAthletesByName(athletes) {
  return [...athletes].sort((a, b) => alphabeticalSort(a.name, b.name));
}

// Utility: Safe async wrapper
async function safeAsync(fn, context = 'operation') {
  try {
    return await fn();
  } catch (err) {
    error(`[feed-groups] Error in ${context}:`, err);
    return null;
  }
}

log('[feed-groups] Content script loaded');

// Debug storage immediately on load + seed the membership cache
(async function debugStorageOnLoad() {
  await safeAsync(async () => {
    const allData = await browser.storage.local.get(null);
    const groups = allData.groups || {};
    const groupCount = Object.keys(groups).length;
    const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
    log(`🔍 Storage Debug: ${groupCount} groups, ${totalAthletes} athletes loaded`);
    if (groupCount > 0) {
      log('   Groups:', Object.keys(groups));
    } else {
      warn('   ⚠️ No groups found in storage! Data may have been lost on reload.');
    }
    buildAthleteMembershipsCache(groups);
    refreshMembershipIndicators();
  }, 'debugStorageOnLoad');
})();

let currentFilter = null;
let selectedAthletes = []; // Batch selection mode
let lastSelectedGroupId = null; // Remember last group selection
let selectedAthletesPage = 1; // Current page for selected athletes pagination
let isFiltering = false; // Prevent re-entrant filter operations
let ftRescanBannerDismissedThisSession = false; // Suppress rescan banner once dismissed per session
let ftChangedLists = { followers: true, following: true }; // Which lists triggered the rescan banner

// ---------------------------------------------------------------------------
// Membership indicator helpers (issue #40)
// Map<athleteId, groupName[]> — kept in sync with storage via onChanged
// ---------------------------------------------------------------------------
const athleteMembershipsCache = new Map();

function buildAthleteMembershipsCache(groups) {
  athleteMembershipsCache.clear();
  Object.values(groups || {}).forEach(group => {
    (group.athletes || []).forEach(athlete => {
      const id = String(athlete.id);
      if (!athleteMembershipsCache.has(id)) athleteMembershipsCache.set(id, []);
      athleteMembershipsCache.get(id).push(group.name);
    });
  });
}

// Apply (or refresh) the visual membership state on a single indicator span.
// Inserts/removes sibling badge pills in the link's parent element.
function applyIndicatorMembershipState(indicator, link, athleteId, athleteName) {
  const id = String(athleteId);
  const memberships = athleteMembershipsCache.get(id) || [];

  // Remove any existing badges for this athlete adjacent to this link
  const parent = link.parentElement;
  if (parent) {
    parent.querySelectorAll(`[data-strava-groups-badge-for="${id}"]`).forEach(b => b.remove());
  }

  if (memberships.length > 0) {
    indicator.classList.add('strava-groups-indicator--listed');
    indicator.textContent = '\u2713'; // ✓
    indicator.title = `In: ${memberships.join(', ')} \u2014 click to manage`;
    indicator.setAttribute('aria-label', `${athleteName} is in: ${memberships.join(', ')} \u2014 click to manage`);
    // Insert sorted badges as siblings after the <a> tag
    const badges = [...memberships]
      .sort((a, b) => a.localeCompare(b))
      .map(groupName => {
        const badge = document.createElement('span');
        badge.className = 'strava-groups-membership-badge';
        badge.dataset.stravaGroupsBadgeFor = id;
        badge.textContent = groupName;
        return badge;
      });
    link.after(...badges);
  } else {
    indicator.classList.remove('strava-groups-indicator--listed');
    indicator.textContent = '+';
    indicator.title = 'Click to add to group';
    indicator.setAttribute('aria-label', `Add ${athleteName} to group`);
  }
}

// Refresh the membership state of every injected indicator on the page
function refreshMembershipIndicators() {
  document.querySelectorAll('[data-strava-groups-indicator-for]').forEach(indicator => {
    const athleteId = indicator.dataset.stravaGroupsIndicatorFor;
    const link = indicator.closest('a');
    if (!link) return;
    const athleteName = link.getAttribute('data-athlete-name') || '';
    applyIndicatorMembershipState(indicator, link, athleteId, athleteName);
  });
}

// Initialize the extension
async function init() {
  await safeAsync(async () => {
    log('[feed-groups] 🚀 init() called, pathname:', window.location.pathname);
    
    // Restore selection from storage
    const stored = await browser.storage.local.get(['selectedAthletes', 'currentFilterId']);
    if (stored.selectedAthletes?.length > 0) {
      selectedAthletes = stored.selectedAthletes;
      log('[feed-groups] Restored', selectedAthletes.length, 'selected athletes from storage');
    }
    
    addAthleteSelectionHandlers();
    observeFeedChanges();
    await createGroupManagementUI();
    // Removed: addProfilePageHandler() - was showing button on user's own profile
    addActivityPageHandlers();
    await addTopFilterDropdown();
    
    // Restore active filter after dropdown is ready
    if (stored.currentFilterId) {
      log('[feed-groups] Restoring filter:', stored.currentFilterId);
      const filterSelect = document.getElementById('strava-groups-top-filter-select');
      if (filterSelect) {
        filterSelect.value = stored.currentFilterId;
      }
      await applyFilter(stored.currentFilterId);
    }
    
    await addGroupLabelsToFollowingPages();

    // Store logged-in athlete ID for use by the Follow Tracker background scanner
    await storeLoggedInAthleteId();

    // Check for discrepancy between live follower/following counts and last scan
    setTimeout(() => ftCheckCountDiscrepancy(), 1500);
    ftObserveStatsForSpaNav();
  }, 'init');

  // Called outside safeAsync so a failure elsewhere in init() cannot prevent it running
  addSegmentLeaderboardHandlers();
}

// Detect and persist the logged-in athlete ID so the background scanner can read it
async function storeLoggedInAthleteId() {
  const id = getLoggedInAthleteId();
  if (id) {
    await browser.storage.local.set({ loggedInAthleteId: id });
    log('[feed-groups] Stored logged-in athlete ID:', id);
  }
}

// Add click handlers to athlete names in the feed
async function addAthleteSelectionHandlers() {
  await safeAsync(async () => {
  // Find all athlete links ONLY within the feed entries
  // Scope to feed container to avoid adding buttons to sidebar, nav, etc.
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  const athleteLinks = [];
  
  let processedCount = 0;
  const MAX_LINKS_TO_PROCESS = 200; // Safety limit to prevent runaway processing
  
  feedEntries.forEach(entry => {
    const links = entry.querySelectorAll('a[href*="/athletes/"]');
    links.forEach(link => {
      // Skip avatar links - only add to athlete name links
      if (link.hasAttribute('data-testid') && 
          (link.getAttribute('data-testid').includes('avatar') || 
           link.getAttribute('data-testid').includes('owner-avatar'))) {
        return;
      }
      
      // Skip if link contains an image or svg (likely an avatar)
      if (link.querySelector('img, svg')) {
        return;
      }
      
      if (processedCount < MAX_LINKS_TO_PROCESS) {
        athleteLinks.push(link);
        processedCount++;
      }
    });
  });
  
  if (processedCount >= MAX_LINKS_TO_PROCESS) {
    warn(`[feed-groups] ⚠️ Hit link processing limit (${MAX_LINKS_TO_PROCESS})`);
  }
  
  athleteLinks.forEach(link => {
    // Skip if already processed to prevent duplicate event listeners
    if (link.getAttribute('data-strava-groups-processed')) return;
    
    link.setAttribute('data-strava-groups-processed', 'true');
    
    // Get athlete name before adding indicator
    const athleteName = link.textContent.trim();
    const athleteId = extractAthleteId(link.href);
    
    // Store original name as data attribute for robustness
    if (!link.getAttribute('data-athlete-name')) {
      link.setAttribute('data-athlete-name', athleteName);
    }
    
    // Add visual indicator
    const indicator = document.createElement('span');
    indicator.className = 'strava-groups-indicator';
    indicator.textContent = '+';
    indicator.title = 'Click to add to group';
    indicator.setAttribute('role', 'button');
    indicator.setAttribute('tabindex', '0');
    indicator.setAttribute('aria-label', `Add ${athleteName} to group`);
    indicator.dataset.stravaGroupsIndicatorFor = String(athleteId);
    
    // Store timeout ID on the element itself to avoid closure memory leaks
    indicator.dataset.feedbackTimeout = '';
    
    // Add click handler
    const handleSelect = async (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      const storedName = link.getAttribute('data-athlete-name');
      if (athleteId && storedName) {
        await selectAthlete({ id: athleteId, name: storedName });
        
        // Clear any existing timeout
        const existingTimeout = indicator.dataset.feedbackTimeout;
        if (existingTimeout) {
          clearTimeout(Number(existingTimeout));
        }
        
        // Visual feedback — restore correct membership state after 1 s
        indicator.textContent = '✓';
        const timeout = setTimeout(() => {
          applyIndicatorMembershipState(indicator, link, athleteId, storedName);
          delete indicator.dataset.feedbackTimeout;
        }, 1000);
        indicator.dataset.feedbackTimeout = String(timeout);
      }
    };
    
    indicator.addEventListener('click', handleSelect);
    
    // Keyboard accessibility - handle Enter and Space keys
    indicator.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleSelect(e);
      }
    });
    
    // Append indicator to the link and apply current membership state
    link.appendChild(indicator);
    applyIndicatorMembershipState(indicator, link, athleteId, athleteName);
  });
  }, 'addAthleteSelectionHandlers');
}

// Extract athlete ID from URL
function extractAthleteId(url) {
  const match = url.match(/\/athletes\/(\d+)/);
  return match ? match[1] : null;
}

// Save selected athlete to storage
async function selectAthlete(athlete) {
  // Add to batch selection
  const existing = selectedAthletes.find(a => a.id === athlete.id);
  if (!existing) {
    selectedAthletes.push(athlete);
    log('[feed-groups] Added to selection:', athlete, 'Total selected:', selectedAthletes.length);
    
    // Jump to last page to show newly added athlete
    const totalPages = Math.ceil(selectedAthletes.length / ATHLETES_PER_PAGE);
    selectedAthletesPage = totalPages;
  }
  
  // Persist full selection and last-selected athlete to storage
  await browser.storage.local.set({ selectedAthlete: athlete, selectedAthletes });
  
  // Update UI to show batch count
  updateSelectedAthleteUI();
  
  // Open the side panel automatically
  openGroupManagementPanel();
  
  // Show notification
  const pageInfo = selectedAthletes.length > ATHLETES_PER_PAGE 
    ? ` (page ${selectedAthletesPage})`
    : '';
  showNotification(`Selected: ${sanitizeText(athlete.name)} (${selectedAthletes.length} total${pageInfo})`);
}

// Sanitize text for display - removes control characters
function sanitizeText(text) {
  const str = String(text);
  // Remove non-printable ASCII control characters except common whitespace
  return str.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
}

// Show temporary notification
function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'strava-groups-notification';
  notification.textContent = message; // Message is already sanitized by caller
  
  document.body.appendChild(notification);
  
  // Cleanup function
  const cleanup = () => {
    if (notification.isConnected) {
      notification.remove();
    }
    window.removeEventListener('beforeunload', cleanup);
  };
  
  // Store timeout for cleanup
  const timeoutId = setTimeout(() => {
    cleanup();
  }, 2000);
  
  // Also cleanup on page unload (clear timeout to prevent errors)
  window.addEventListener('beforeunload', () => {
    clearTimeout(timeoutId);
    cleanup();
  }, { once: true });
}

// Show custom confirmation dialog (replacement for browser confirm())
function showConfirmDialog(message) {
  return new Promise((resolve) => {
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'strava-groups-confirm-overlay';
    
    // Create dialog
    const dialog = document.createElement('div');
    dialog.className = 'strava-groups-confirm-dialog';
    
    // Create message
    const messageEl = document.createElement('div');
    messageEl.className = 'strava-groups-confirm-message';
    messageEl.textContent = message;
    
    // Create buttons container
    const buttons = document.createElement('div');
    buttons.className = 'strava-groups-confirm-buttons';
    
    // Create Cancel button
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'strava-groups-confirm-btn strava-groups-confirm-cancel';
    cancelBtn.textContent = 'Cancel';
    
    // Create Confirm button
    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'strava-groups-confirm-btn strava-groups-confirm-ok';
    confirmBtn.textContent = 'Confirm';
    
    // Cleanup function
    const cleanup = () => {
      if (overlay.isConnected) {
        overlay.remove();
      }
    };
    
    // Handle Cancel
    cancelBtn.addEventListener('click', () => {
      cleanup();
      resolve(false);
    });
    
    // Handle Confirm
    confirmBtn.addEventListener('click', () => {
      cleanup();
      resolve(true);
    });
    
    // Handle Escape key
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        cleanup();
        document.removeEventListener('keydown', handleEscape);
        resolve(false);
      }
    };
    document.addEventListener('keydown', handleEscape);
    
    // Assemble dialog
    buttons.appendChild(cancelBtn);
    buttons.appendChild(confirmBtn);
    dialog.appendChild(messageEl);
    dialog.appendChild(buttons);
    overlay.appendChild(dialog);
    
    // Add to page
    document.body.appendChild(overlay);
    
    // Focus confirm button
    confirmBtn.focus();
  });
}

// Debounce helper - maintains its own timer in closure
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Observe DOM changes to handle dynamically loaded content
// Note: Observer persists for the lifetime of the page. Strava is an SPA,
// so the observer will continue working during in-app navigation.
function observeFeedChanges() {
  let mutationCount = 0;
  let lastResetTime = Date.now();
  const MAX_MUTATIONS_PER_SECOND = 10; // Safety limit
  
  // Debounced handler to reduce processing frequency
  const debouncedHandler = debounce(() => {
    // Safety check: reset counter every second
    const now = Date.now();
    if (now - lastResetTime > 1000) {
      mutationCount = 0;
      lastResetTime = now;
    }
    
    // Prevent excessive processing
    if (mutationCount >= MAX_MUTATIONS_PER_SECOND) {
      warn('[feed-groups] ⚠️ Mutation rate limit hit, skipping update');
      return;
    }
    mutationCount++;
    
    const startTime = performance.now();
    
    addAthleteSelectionHandlers();
    if (currentFilter) {
      applyCurrentFilter();
    }
    
    const duration = (performance.now() - startTime).toFixed(2);
    log(`[feed-groups] ⚡ Feed update processed in ${duration}ms (${mutationCount}/${MAX_MUTATIONS_PER_SECOND})`);
  }, 300);
  
  const observer = new MutationObserver((mutations) => {
    // Filter out mutations that are just our extension UI (progress/status elements) updating
    const hasRelevantChanges = mutations.some(mutation => {
      // Ignore direct changes to our progress and status indicators
      if (mutation.target.id === 'strava-groups-filter-progress' ||
          mutation.target.id === 'strava-groups-kudos-progress' ||
          mutation.target.id === 'strava-groups-status-area') {
        return false;
      }
      // Ignore changes inside our extension UI elements
      if (mutation.target.closest && (
        mutation.target.closest('#strava-groups-status-area') ||
        mutation.target.closest('#strava-groups-top-filter') ||
        mutation.target.closest('.strava-groups-side-panel')
      )) {
        return false;
      }
      
      return mutation.addedNodes.length > 0 || mutation.removedNodes.length > 0;
    });
    
    if (hasRelevantChanges) {
      debouncedHandler();
    }
  });
  
  // Try to observe a more specific container if possible
  // Note: Using specific selectors to avoid matching unintended elements
  const feedContainer = document.querySelector('#dashboard-feed, main[class*="feed"], [data-testid="feed"], .feature-feed');
  const targetElement = feedContainer || document.body;

  if (!feedContainer) {
    // Only warn on pages that are expected to have a feed
    const isFeedPage = /^\/(dashboard|athletes\/\d+\/training\/log)?$/.test(window.location.pathname);
    if (isFeedPage) {
      warn('[feed-groups] ⚠️ Feed container not found, observing document.body (may impact performance)');
    } else {
      log('[feed-groups] ℹ️ No feed container on this page type, observing document.body');
    }
  } else {
    log('[feed-groups] ✓ Observing feed container:', targetElement.className || targetElement.id);
  }
  
  observer.observe(targetElement, {
    childList: true,
    subtree: true,
    // Don't observe attributes or character data to reduce callbacks
    attributes: false,
    characterData: false
  });
  
  // Store observer reference for potential cleanup
  window._stravaGroupsObserver = observer;
}

// Apply filter to feed
async function applyFilter(groupId) {
  log('[feed-groups] applyFilter called with groupId:', groupId);
  
  // Persist filter selection to survive page reloads
  if (groupId) {
    await browser.storage.local.set({ currentFilterId: groupId });
  }
  
  if (!groupId) {
    clearCurrentFilter();
    return;
  }

  // On athlete profile pages, preserve the filter state in storage but don't
  // apply filtering or show any UI feedback — filter resumes on return to dashboard.
  if (ATHLETE_PROFILE_PATH_PATTERN.test(window.location.pathname)) {
    log('[feed-groups] Restoring filter state only (no UI) on athlete profile page');
    return;
  }
  
  // Handle virtual "Ungrouped" filter
  if (groupId === '__ungrouped__') {
    await applyUngroupedFilter();
    return;
  }
  
  // Handle virtual "No Kudos" filter
  if (groupId === '__nokudos__') {
    await applyNoKudosFilter();
    return;
  }
  
  // Always fetch fresh data from storage to get the latest athlete list
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  const group = groups[groupId];
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  log(`📦 Storage loaded in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  if (!group) {
    console.error('Group not found:', groupId);
    showNotification('Error: Group not found');
    return;
  }
  
  log('[feed-groups] Filtering by group:', group.name, 'Athletes:', group.athletes);
  
  // Store the groupId instead of the group object to always fetch fresh data
  currentFilter = {
    id: groupId,
    name: group.name,
    athletes: group.athletes
  };
  
  applyCurrentFilter();
  
  showNotification(`Filtering by: ${sanitizeText(group.name)}`);
}

// Apply filter for athletes not in any group
async function applyUngroupedFilter() {
  const startTime = performance.now();
  
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  log(`📦 Storage loaded in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  // Collect all athlete IDs that are in groups
  const groupedAthleteIds = new Set();
  for (const group of Object.values(groups)) {
    if (group.athletes) {
      group.athletes.forEach(athlete => groupedAthleteIds.add(athlete.id));
    }
  }
  
  log('[feed-groups] Athletes in groups:', Array.from(groupedAthleteIds));
  
  // Find all athletes in the feed
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  const ungroupedAthletes = [];
  
  feedEntries.forEach(entry => {
    const athleteLink = entry.querySelector('a[href*="/athletes/"]:not([href*="/training"]):not([href*="/calendar"])');
    if (athleteLink) {
      const athleteId = extractAthleteId(athleteLink.href);
      if (athleteId && !groupedAthleteIds.has(athleteId)) {
        const athleteName = athleteLink.getAttribute('data-athlete-name') || athleteLink.textContent.trim();
        ungroupedAthletes.push({ id: athleteId, name: athleteName });
      }
    }
  });
  
  const scanTime = (performance.now() - startTime).toFixed(2);
  log(`[feed-groups] ✓ Ungrouped scan completed in ${scanTime}ms: ${ungroupedAthletes.length} athletes found`);
  
  // Set current filter to ungrouped athletes
  currentFilter = {
    id: '__ungrouped__',
    name: 'Ungrouped',
    athletes: ungroupedAthletes
  };
  
  applyCurrentFilter();
  showNotification(`Filtering by: Ungrouped (${ungroupedAthletes.length} athletes)`);
}

// Get the logged-in athlete's ID from Strava's global nav profile link.
// Returns a string ID or null if it cannot be determined.
function getLoggedInAthleteId() {
  // Strava renders a profile/avatar link in the top nav pointing to /athletes/{id}
  const candidates = [
    // Newer nav: data-testid on the profile link
    document.querySelector('a[data-testid="nav-profile-link"]'),
    // Fallback: any /athletes/ link inside <nav> or the global header
    ...(document.querySelectorAll('nav a[href*="/athletes/"], header a[href*="/athletes/"]') || []),
  ].filter(Boolean);

  for (const el of candidates) {
    const id = extractAthleteId(el.href);
    if (id) {
      log('[feed-groups] Logged-in athlete ID:', id);
      return id;
    }
  }

  log('[feed-groups] Could not determine logged-in athlete ID — own activities will not be skipped');
  return null;
}

// Give kudos to all visible feed entries that haven't been kudo'd yet
async function giveBulkKudos() {
  const btn = document.getElementById('strava-groups-bulk-kudos-btn');
  if (!btn || btn.disabled) return;

  const loggedInAthleteId = getLoggedInAthleteId();

  // Read "include rode-with athletes" setting (default: true)
  const settingsResult = await browser.storage.local.get(['bulkKudosIncludeRodWith']);
  const includeRodWith = settingsResult.bulkKudosIncludeRodWith !== false;

  // Determine which entries to scan: only visible ones if a filter is active
  const feedEntries = document.querySelectorAll(FEED_SELECTOR);
  const visibleEntries = [...feedEntries].filter(entry => {
    const style = window.getComputedStyle(entry);
    return style.display !== 'none' && style.visibility !== 'hidden';
  });

  // Find all un-kudo'd kudos buttons in visible entries, skipping own activities.
  // Bug fix: use querySelectorAll to collect ALL kudos buttons per entry so that
  // "rode with" participants in group activities are not overlooked.
  const unkudoedButtons = [];
  visibleEntries.forEach(entry => {
    const allKudosButtons = [...entry.querySelectorAll('button[data-testid="kudos_button"]')];
    if (allKudosButtons.length === 0) return;

    // Determine if the primary (first) athlete in this entry is the logged-in user.
    // Their button sits at index 0 and must be skipped — clicking kudos on your own
    // activity opens the kudos-giver list rather than giving kudos.
    // Bug fix: we no longer bail out of the whole entry; we only skip that one button,
    // so any "rode with" participants at subsequent indices are still processed.
    let primaryIsOwn = false;
    if (loggedInAthleteId) {
      const primaryAthleteLink = entry.querySelector(
        'a[href*="/athletes/"]:not([href*="/training"]):not([href*="/calendar"])'
      );
      primaryIsOwn =
        !!primaryAthleteLink &&
        extractAthleteId(primaryAthleteLink.href) === loggedInAthleteId;
    }

    allKudosButtons.forEach((kudosButton, idx) => {
      // Skip the primary athlete's button when it belongs to the logged-in user
      if (idx === 0 && primaryIsOwn) {
        log('[feed-groups] Skipping own-activity kudos button in bulk kudos');
        return;
      }

      // Buttons at idx > 0 belong to "rode with" participants — respect the setting
      if (idx > 0 && !includeRodWith) return;

      // If the SVG inside is the unfilled variant, it hasn't been kudo'd yet
      const unfilledSvg = kudosButton.querySelector('svg[data-testid="unfilled_kudos"]');
      const hasKudos =
        !unfilledSvg ||
        kudosButton.classList.contains('active') ||
        kudosButton.classList.contains('given') ||
        kudosButton.getAttribute('aria-pressed') === 'true';

      if (!hasKudos) {
        unkudoedButtons.push(kudosButton);
      }
    });
  });

  if (unkudoedButtons.length === 0) {
    showNotification('All visible activities have already been kudo\'d! 👍');
    return;
  }

  // Disable button and show progress
  btn.disabled = true;
  btn.classList.add('strava-groups-bulk-kudos-active');
  const kudosProgressEl = document.getElementById('strava-groups-kudos-progress');

  if (kudosProgressEl) {
    kudosProgressEl.style.color = '#FC4C02';
  }

  let given = 0;
  for (const kudosButton of unkudoedButtons) {
    given++;
    if (kudosProgressEl) {
      kudosProgressEl.textContent = `Kudos ${given}/${unkudoedButtons.length}`;
    }
    kudosButton.click();
    // Small delay between clicks to avoid overwhelming the server
    await new Promise(resolve => setTimeout(resolve, 350));
  }

  // Done
  if (kudosProgressEl) {
    kudosProgressEl.textContent = '';
  }
  btn.disabled = false;
  btn.classList.remove('strava-groups-bulk-kudos-active');
  showNotification(`Gave kudos to ${given} ${given === 1 ? 'athlete' : 'athletes'}! 👍`);
}

// Apply filter for activities without kudos
async function applyNoKudosFilter() {
  const startTime = performance.now();
  log('[feed-groups] Applying No Kudos filter');
  
  // Find all feed entries
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  const noKudosActivities = [];
  
  feedEntries.forEach(entry => {
    // Check if the activity has been given kudos by looking for the kudos button state
    // Strava uses a filled SVG path when kudos have been given
    const kudosButton = entry.querySelector('button[data-testid="kudos_button"], button.kudo-btn, button[class*="kudos"], button[class*="Kudo"]');
    
    if (kudosButton) {
      // Check for filled kudos icon - Strava uses a filled path when kudos are given
      const filledPath = kudosButton.querySelector('path[d*="M14.625 10.96V9.5"]');
      const emptyPath = kudosButton.querySelector('path[d*="M13.5 9.062"]'); // Outline/empty version
      
      // Also check other indicators
      const hasKudos = filledPath || 
                       kudosButton.classList.contains('active') ||
                       kudosButton.classList.contains('given') ||
                       kudosButton.classList.contains('filled') ||
                       kudosButton.getAttribute('aria-pressed') === 'true' ||
                       kudosButton.querySelector('.icon-kudo.active') ||
                       kudosButton.querySelector('[class*="filled"]') ||
                       kudosButton.querySelector('svg[class*="active"]') ||
                       kudosButton.querySelector('svg[class*="filled"]');
      
      if (!hasKudos) {
        // Get athlete info from this entry
        const athleteLink = entry.querySelector('a[href*="/athletes/"]:not([href*="/training"]):not([href*="/calendar"])');
        if (athleteLink) {
          const athleteId = extractAthleteId(athleteLink.href);
          const athleteName = athleteLink.getAttribute('data-athlete-name') || athleteLink.textContent.trim();
          
          // Check if we already have this athlete (avoid duplicates)
          if (athleteId && !noKudosActivities.find(a => a.id === athleteId)) {
            noKudosActivities.push({ id: athleteId, name: athleteName });
          }
        }
      }
    }
  });
  
  const scanTime = (performance.now() - startTime).toFixed(2);
  log(`[feed-groups] ✓ No Kudos scan completed in ${scanTime}ms: ${noKudosActivities.length} activities found`);
  
  // Set current filter to no kudos activities
  currentFilter = {
    id: '__nokudos__',
    name: 'No Kudos',
    athletes: noKudosActivities
  };
  
  applyCurrentFilter();
  showNotification(`Filtering by: No Kudos (${noKudosActivities.length} activities)`);
}

// Apply the current filter to the feed
// Note: Feed entry selectors are based on Strava's current DOM structure (as of Jan 2026)
// The main feed entry container is div[data-testid="web-feed-entry"] which contains
// both the athlete header and the activity details.
function applyCurrentFilter() {
  if (!currentFilter) return;

  // Don't apply feed filter on athlete profile pages — the filter state in storage
  // is preserved so it resumes correctly when returning to the dashboard.
  if (ATHLETE_PROFILE_PATH_PATTERN.test(window.location.pathname)) {
    log('[feed-groups] Skipping filter on athlete profile page');
    return;
  }

  // Prevent re-entrant calls while filtering is in progress
  if (isFiltering) {
    log('[feed-groups] ⏭️ Skipping filter - already in progress');
    return;
  }
  
  isFiltering = true;
  
  // Start performance tracking
  const startTime = performance.now();
  
  // For "No Kudos" filter, we need to rescan each time because kudos status can change
  // and new activities are loaded dynamically
  if (currentFilter.id === '__nokudos__') {
    applyNoKudosFilterDirect();
    isFiltering = false;
    return;
  }
  
  const athleteIds = currentFilter.athletes.map(a => a.id);
  log('Applying filter for athlete IDs:', athleteIds);
  
  // Find all feed entries - Strava uses data-testid="web-feed-entry" for each feed item
  let feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  
  // Fallback: if Strava changed the structure, use the old selectors
  if (feedEntries.length === 0) {
    log('No web-feed-entry found, trying fallback selectors');
    feedEntries = document.querySelectorAll('[class*="feed-entry"], [class*="Activity"], div[data-testid*="activity"]');
  }
  
  log(`[feed-groups] Found ${feedEntries.length} feed entries to filter`);
  
  const totalEntries = feedEntries.length;
  let hiddenCount = 0;
  let shownCount = 0;
  let processedCount = 0;
  
  // Show initial progress
  updateFilterProgress(0, totalEntries);
  
  feedEntries.forEach((entry, index) => {
    // Look for athlete links within this entry
    // Filter out links that are for training/calendar (not actual athlete profile links)
    const athleteLinks = entry.querySelectorAll('a[href*="/athletes/"]:not([href*="/training"]):not([href*="/calendar"])');
    let shouldShow = false;
    
    athleteLinks.forEach(link => {
      const athleteId = extractAthleteId(link.href);
      if (athleteId && athleteIds.includes(athleteId)) {
        shouldShow = true;
      }
    });
    
    // Hide or show the entry
    if (shouldShow) {
      entry.style.display = '';
      shownCount++;
    } else {
      entry.style.display = 'none';
      hiddenCount++;
    }
    
    processedCount++;
    
    // Update progress every 5 items to avoid too many DOM updates
    if (processedCount % 5 === 0 || processedCount === totalEntries) {
      updateFilterProgress(processedCount, totalEntries);
    }
  });
  
  // Calculate and log performance
  const endTime = performance.now();
  const duration = (endTime - startTime).toFixed(2);
  
  log(`[feed-groups] ✓ Filter applied in ${duration}ms: ${shownCount} shown, ${hiddenCount} hidden`);
  
  // Show final count without "processing" indicator
  updateFilterProgress(totalEntries, totalEntries, shownCount, true);
  
  // Reset filtering flag
  isFiltering = false;
  
  // Clear progress after 3 seconds
  setTimeout(() => clearFilterProgress(), 3000);
}

// Update filter progress indicator
function updateFilterProgress(processed, total, shownCount = null, isFinal = false) {
  const progressEl = document.getElementById('strava-groups-filter-progress');
  if (!progressEl) return;
  
  if (isFinal && shownCount !== null) {
    // Show final result
    progressEl.textContent = `✓ ${shownCount} shown`;
    progressEl.style.color = '#4CAF50';
  } else {
    // Show progress
    progressEl.textContent = `Filtering... ${processed}/${total}`;
    progressEl.style.color = '#FC4C02';
  }
}

// Clear filter progress indicator
function clearFilterProgress() {
  const progressEl = document.getElementById('strava-groups-filter-progress');
  if (progressEl) {
    progressEl.textContent = '';
  }
}

// Apply "No Kudos" filter directly by scanning kudos status in real-time
// This is called from applyCurrentFilter() when filter is __nokudos__
function applyNoKudosFilterDirect() {
  const startTime = performance.now();
  log('Applying No Kudos filter (direct scan)');
  
  // Find all feed entries
  const feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  log(`Found ${feedEntries.length} feed entries to scan for kudos status`);
  
  let hiddenCount = 0;
  let shownCount = 0;
  let processedCount = 0;
  const totalEntries = feedEntries.length;
  
  // Show initial progress
  updateFilterProgress(0, totalEntries);
  
  feedEntries.forEach((entry, index) => {
    // Check if the activity has been given kudos by looking for the kudos button state
    const kudosButton = entry.querySelector('button[data-testid="kudos_button"], button.kudo-btn, button[class*="kudos"], button[class*="Kudo"]');
    
    let hasKudos = false;
    if (kudosButton) {
      // Check for filled kudos icon - Strava uses a filled path when kudos are given
      const filledPath = kudosButton.querySelector('path[d*="M14.625 10.96V9.5"]');
      
      // Also check other indicators
      hasKudos = filledPath || 
                 kudosButton.classList.contains('active') ||
                 kudosButton.classList.contains('given') ||
                 kudosButton.classList.contains('filled') ||
                 kudosButton.getAttribute('aria-pressed') === 'true' ||
                 kudosButton.querySelector('.icon-kudo.active') ||
                 kudosButton.querySelector('[class*="filled"]') ||
                 kudosButton.querySelector('svg[class*="active"]') ||
                 kudosButton.querySelector('svg[class*="filled"]');
    }
    
    // Show only activities WITHOUT kudos
    if (!hasKudos && kudosButton) {
      entry.style.display = '';
      shownCount++;
    } else {
      entry.style.display = 'none';
      hiddenCount++;
    }
    
    processedCount++;
    
    // Update progress every 5 items to avoid too many DOM updates
    if (processedCount % 5 === 0 || processedCount === totalEntries) {
      updateFilterProgress(processedCount, totalEntries);
    }
  });
  
  const duration = (performance.now() - startTime).toFixed(2);
  log(`[feed-groups] ✓ No Kudos filter applied in ${duration}ms: ${shownCount} shown, ${hiddenCount} hidden`);
  
  // Show final count
  updateFilterProgress(totalEntries, totalEntries, shownCount, true);
  
  // Clear progress after 3 seconds
  setTimeout(() => clearFilterProgress(), 3000);
}

// Clear filter
async function clearCurrentFilter() {
  currentFilter = null;
  await browser.storage.local.remove('currentFilterId');
  
  log('Clearing filter');
  
  // Show all feed entries - use the same selector as applyCurrentFilter()
  let feedEntries = document.querySelectorAll('[data-testid="web-feed-entry"]');
  
  // Fallback for older Strava structure
  if (feedEntries.length === 0) {
    log('Using fallback selectors to clear filter');
    feedEntries = document.querySelectorAll('[class*="feed-entry"], [class*="Activity"], div[data-testid*="activity"]');
  }
  
  log(`[feed-groups] Clearing filter on ${feedEntries.length} elements`);
  
  feedEntries.forEach(entry => {
    entry.style.display = '';
  });
  
  showNotification('Filter cleared');
}

// Listen for messages from popup
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  log('[feed-groups] Received message:', message);

  if (message.action === 'applyFilter') {
    applyFilter(message.groupId);
  } else if (message.action === 'clearFilter') {
    clearCurrentFilter();
  } else if (message.action === 'getAthleteId') {
    // Follow Tracker: background requests logged-in athlete ID from this tab
    const athleteId = getLoggedInAthleteId();
    sendResponse({ athleteId });
    return true;
  }

  return true;
});

// Listen for storage changes and re-apply filter if groups are updated
browser.storage.onChanged.addListener(async (changes, area) => {
  if (area === 'local' && changes.groups && currentFilter) {
    log('[feed-groups] Groups updated in storage, re-applying filter');
    // Re-fetch the current filter group with updated athlete list
    await applyFilter(currentFilter.id);
  }
  
  // Update the UI if groups changed
  if (area === 'local' && changes.groups) {
    updateGroupManagementUI();
  }
  
  // Rebuild membership cache and refresh all inline indicators whenever groups change
  if (area === 'local' && changes.groups) {
    buildAthleteMembershipsCache(changes.groups.newValue || {});
    refreshMembershipIndicators();
    if (segmentRowFilterCallback) segmentRowFilterCallback();
  }
  
  // Update selected athlete display
  if (area === 'local' && changes.selectedAthlete) {
    updateSelectedAthleteUI();
  }
});

// Add handler for athlete profile pages
function addProfilePageHandler() {
  // Check if we're on an athlete profile page
  const urlMatch = window.location.pathname.match(/\/athletes\/(\d+)/);
  if (!urlMatch) return;
  
  const athleteId = urlMatch[1];
  
  // Find the athlete's name on the profile page
  // Strava typically shows it in the header
  const findAthleteName = () => {
    // Try different selectors for athlete name
    const nameSelectors = [
      '.athlete-name',
      'h1.text-title1',
      '[data-testid="athlete-name"]',
      'h1'
    ];
    
    for (const selector of nameSelectors) {
      const nameElement = document.querySelector(selector);
      if (nameElement && nameElement.textContent.trim()) {
        return nameElement.textContent.trim();
      }
    }
    return 'Unknown Athlete';
  };
  
  // Add a button to select this athlete
  const addSelectButton = () => {
    // Don't add if already added
    if (document.getElementById('strava-groups-profile-select')) return;
    
    const athleteName = findAthleteName();
    
    // Create select button
    const selectButton = document.createElement('button');
    selectButton.id = 'strava-groups-profile-select';
    selectButton.className = 'strava-groups-profile-select-btn';
    selectButton.innerHTML = '<span style="color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; padding: 0 4px; margin-right: 4px;">+</span>Add to Group';
    selectButton.title = 'Select this athlete to add to a group';
    
    selectButton.addEventListener('click', async () => {
      await selectAthlete({ id: athleteId, name: athleteName });
      selectButton.innerHTML = '✓ Selected';
      setTimeout(() => {
        selectButton.innerHTML = '<span style="color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; padding: 0 4px; margin-right: 4px;">+</span>Add to Group';
      }, 2000);
    });
    
    // Try to find a good location to insert the button
    // Look for the athlete actions area or header
    const insertLocations = [
      '.athlete-profile-header .actions',
      '.page-header .actions',
      'header .actions',
      '.athlete-profile-header',
      '.page-header',
      'header'
    ];
    
    for (const selector of insertLocations) {
      const container = document.querySelector(selector);
      if (container) {
        container.appendChild(selectButton);
        log('Added profile select button to:', selector);
        return;
      }
    }
    
    // Fallback: add to body with fixed positioning
    selectButton.style.position = 'fixed';
    selectButton.style.top = '80px';
    selectButton.style.right = '20px';
    selectButton.style.zIndex = '9998';
    document.body.appendChild(selectButton);
    log('Added profile select button to body (fallback)');
  };
  
  // Add button when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addSelectButton);
  } else {
    addSelectButton();
  }
  
  // Re-add button if DOM changes (for SPA navigation)
  setTimeout(addSelectButton, 1000);
}

// Add handlers for activity pages to select athletes who participated
function addActivityPageHandlers() {
  // Check if we're on an activity page
  const urlMatch = window.location.pathname.match(/\/activities\/(\d+)/);
  if (!urlMatch) return;
  
  // Add selection indicators to athletes who did this activity with you
  const addActivityAthleteHandlers = () => {
    // Find athlete links in the activity (e.g., in kudos, comments, or participants)
    const athleteLinks = document.querySelectorAll('a[href*="/athletes/"]:not([data-strava-groups-processed])');
    
    athleteLinks.forEach(link => {
      const athleteId = extractAthleteId(link.href);
      if (!athleteId) return;
      
      // Skip if it's a training/calendar link
      if (link.href.includes('/training') || link.href.includes('/calendar')) return;
      
      // Skip avatar links - only add to athlete name links
      if (link.hasAttribute('data-testid') && 
          (link.getAttribute('data-testid').includes('avatar') || 
           link.getAttribute('data-testid').includes('owner-avatar'))) {
        return;
      }
      
      // Skip if link contains an image or svg (likely an avatar)
      if (link.querySelector('img, svg')) {
        return;
      }
      
      // Skip if already processed
      if (link.getAttribute('data-strava-groups-processed')) return;
      
      link.setAttribute('data-strava-groups-processed', 'true');
      
      const athleteName = link.textContent.trim();
      
      // Store original name
      if (!link.getAttribute('data-athlete-name')) {
        link.setAttribute('data-athlete-name', athleteName);
      }
      
      // Add indicator
      const indicator = document.createElement('span');
      indicator.className = 'strava-groups-indicator';
      indicator.textContent = '+';
      indicator.title = 'Click to add to group';
      indicator.setAttribute('role', 'button');
      indicator.setAttribute('tabindex', '0');
      indicator.setAttribute('aria-label', `Add ${athleteName} to group`);
      indicator.dataset.stravaGroupsIndicatorFor = String(athleteId);
      
      // Store timeout ID on the element itself to avoid closure memory leaks
      indicator.dataset.feedbackTimeout = '';
      
      const handleSelect = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const storedName = link.getAttribute('data-athlete-name');
        if (athleteId && storedName) {
          await selectAthlete({ id: athleteId, name: storedName });
          
          const existingTimeout = indicator.dataset.feedbackTimeout;
          if (existingTimeout) {
            clearTimeout(Number(existingTimeout));
          }
          
          // Visual feedback — restore correct membership state after 1 s
          indicator.textContent = '✓';
          const timeout = setTimeout(() => {
            applyIndicatorMembershipState(indicator, link, athleteId, storedName);
            delete indicator.dataset.feedbackTimeout;
          }, 1000);
          indicator.dataset.feedbackTimeout = String(timeout);
        }
      };
      
      indicator.addEventListener('click', handleSelect);
      indicator.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleSelect(e);
        }
      });
      
      // Append indicator to the link and apply current membership state
      link.appendChild(indicator);
      applyIndicatorMembershipState(indicator, link, athleteId, athleteName);
    });
  };
  
  // Add handlers when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addActivityAthleteHandlers);
  } else {
    addActivityAthleteHandlers();
  }
  
  // Observe for dynamically loaded content (comments, kudos)
  const observer = new MutationObserver(debounce(addActivityAthleteHandlers, 300));
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// Open the group management panel
function openGroupManagementPanel() {
  const panel = document.getElementById('strava-groups-panel');
  if (panel && !panel.classList.contains('open')) {
    panel.classList.add('open');
  }
}

// Create the group management UI on the page
function createGroupManagementUI() {
  // Create simple floating button in top-right corner
  const floatingButton = document.createElement('button');
  floatingButton.id = 'strava-groups-floating-btn';
  floatingButton.className = 'strava-groups-floating-btn';
  floatingButton.innerHTML = '👥';
  floatingButton.title = 'Manage Athlete Filters';
  floatingButton.setAttribute('aria-label', 'Open group management panel');
  
  // Add button directly to body
  document.body.appendChild(floatingButton);
  
  // Create side panel
  const panel = document.createElement('div');
  panel.id = 'strava-groups-panel';
  panel.className = 'strava-groups-panel';
  panel.innerHTML = `
    <div class="strava-groups-panel-header">
      <h2>Athlete Filters</h2>
      <button class="strava-groups-close-btn" aria-label="Close panel">✕</button>
    </div>

    <!-- What's New banner (hidden until an update is detected) -->
    <div id="whats-new-banner" class="whats-new-banner" style="display:none;">
      <div class="whats-new-header">
        <span class="whats-new-title">🎉 What’s new in v<span id="whats-new-version"></span></span>
        <button id="whats-new-dismiss" class="whats-new-dismiss">Got it ✕</button>
      </div>
      <ul id="whats-new-list" class="whats-new-list"></ul>
      <a href="https://statelessnessone.github.io/athlete-filters/releases/" target="_blank" rel="noopener" class="whats-new-link">View full release notes →</a>
    </div>

    <!-- Tab Navigation -->
    <div class="strava-groups-tabs">
      <button class="strava-groups-tab active" data-tab="selected">Selected Athletes</button>
      <button class="strava-groups-tab" data-tab="groups">Groups</button>
      <button class="strava-groups-tab" data-tab="tracker">Follow Tracker</button>
      <button class="strava-groups-tab" data-tab="backup">Backup</button>
      <button class="strava-groups-tab" data-tab="about">About</button>
    </div>
    
    <div class="strava-groups-panel-content">
      <!-- Selected Athletes Tab -->
      <div class="strava-groups-tab-content active" data-tab-content="selected">
        <div class="strava-groups-section">
          <div class="strava-groups-section-header">
            <h3>Selected Athletes (<span id="strava-groups-selected-count">0</span>)</h3>
            <button id="strava-groups-clear-selection" class="strava-groups-text-btn" style="display: none;">Clear All</button>
          </div>
          <div id="strava-groups-selected-athlete" class="strava-groups-selected-info">
            <p>Click the <span style="display: inline-flex; align-items: center; justify-content: center; color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; width: 18px; height: 18px; font-size: 14px; line-height: 1;">+</span> icon next to athlete names to select them</p>
          </div>
        </div>
        
        <div class="strava-groups-section" id="strava-groups-add-section" style="display: none;">
          <h3>Add Selected to Group</h3>
          <div class="strava-groups-input-group">
            <select id="strava-groups-select"></select>
            <button id="strava-groups-add-btn">Add</button>
          </div>
        </div>
        
        <div class="strava-groups-section">
          <h3>Create New Group</h3>
          <div class="strava-groups-input-group">
            <input type="text" id="strava-groups-new-group-name" placeholder="Group name..." maxlength="50">
            <button id="strava-groups-create-btn">Create</button>
          </div>
        </div>
      </div>
      
      <!-- Groups Management Tab -->
      <div class="strava-groups-tab-content" data-tab-content="groups">
        <div class="strava-groups-section">
          <h3>Your Groups</h3>
          <div id="strava-groups-list"></div>
        </div>

        <!-- Bulk Kudos Settings -->
        <details id="kudos-sidebar-settings" class="ft-sidebar-settings">
          <summary class="ft-sidebar-settings-summary">⚙ Bulk Kudos Settings</summary>
          <div class="ft-sidebar-settings-body">
            <label class="ft-sidebar-setting ft-sidebar-setting-checkbox">
              <input type="checkbox" id="kudos-setting-include-rod-with" checked>
              <span class="ft-sidebar-setting-label">Include "rode with" athletes</span>
              <span class="ft-sidebar-setting-hint">Give kudos to all participants in group activities, not just the primary athlete</span>
            </label>
            <button id="kudos-sidebar-settings-save" class="strava-groups-action-btn ft-settings-save-btn">Save</button>
            <p id="kudos-sidebar-settings-msg" class="ft-sidebar-settings-msg" style="display:none;"></p>
          </div>
        </details>
      </div>
      
      <!-- Backup & Restore Tab -->
      <div class="strava-groups-tab-content" data-tab-content="backup">
        <div class="strava-groups-section">
          <h3>Backup & Restore</h3>
          <div class="strava-groups-import-export">
            <button id="strava-groups-export-btn" class="strava-groups-action-btn">📥 Export Data</button>
            <button id="strava-groups-import-btn" class="strava-groups-action-btn">📤 Import Data</button>
            <input type="file" id="strava-groups-import-file" accept=".json" style="display: none;">
          </div>
          <p id="ft-last-backup-status" class="strava-groups-help-text">Last backup: never</p>
        </div>
      </div>
      
      <!-- About Tab -->
      <div class="strava-groups-tab-content" data-tab-content="about">
        <div class="strava-groups-section">
          <h3>Athlete Filters <span class="about-version">v<span id="about-version-num"></span></span></h3>
          <p class="strava-groups-about-text">Organize and filter your Strava feed using custom athlete groups, and track follower changes over time.</p>

          <details class="about-details" open>
            <summary class="about-summary">🎉 What’s New</summary>
            <ul id="about-whats-new-list" class="strava-groups-feature-list about-wn-list"></ul>
            <a href="https://statelessnessone.github.io/athlete-filters/releases/" target="_blank" rel="noopener" class="about-releases-link">View all release notes →</a>
          </details>

          <details class="about-details">
            <summary class="about-summary">✨ Features</summary>
            <ul class="strava-groups-feature-list">
              <li><strong>Athlete Groups</strong> — create named groups and filter your Strava feed by group</li>
              <li><strong>Feed Filtering</strong> — show all, by group, ungrouped athletes, or activities without kudos</li>
              <li><strong>Bulk Kudos</strong> — give kudos to all visible un-kudo’d activities in one click</li>
              <li><strong>Group Labels</strong> — athlete group membership shown on following/followers pages</li>
              <li><strong>Follow Tracker</strong> — scan followers &amp; following to detect gains, losses and name changes over time</li>
              <li><strong>History Log</strong> — filterable event history with time-period and event-type filters</li>
              <li><strong>Resizable Sidebar</strong> — drag the left edge to any width; preference is remembered</li>
              <li><strong>Backup &amp; Restore</strong> — export and import all your data via the Backup tab</li>
            </ul>
          </details>

          <details class="about-details">
            <summary class="about-summary">🔒 Privacy</summary>
            <p class="strava-groups-about-text">All data is stored locally in your browser. No data is collected, transmitted, or shared with any external servers. Your athlete groups, selections, and Follow Tracker history never leave your device.</p>
          </details>

          <details class="about-details">
            <summary class="about-summary">💾 Data Storage</summary>
            <p class="strava-groups-about-text">Everything is stored using browser extension local storage. Use the Backup tab to export a copy for safekeeping or to transfer between browsers.</p>
          </details>

          <details class="about-details">
            <summary class="about-summary">🔗 Links</summary>
            <ul class="strava-groups-feature-list">
              <li><a href="https://statelessnessone.github.io/athlete-filters/" target="_blank" rel="noopener">Extension home page</a></li>
              <li><a href="https://statelessnessone.github.io/athlete-filters/releases/" target="_blank" rel="noopener">Release notes</a></li>
              <li><a href="https://statelessnessone.github.io/athlete-filters/privacy.html" target="_blank" rel="noopener">Privacy policy</a></li>
              <li><a href="https://statelessnessone.github.io/athlete-filters/support.html" target="_blank" rel="noopener">Support</a></li>
            </ul>
          </details>
        </div>
      </div>

      <!-- Follow Tracker Tab -->
      <div class="strava-groups-tab-content" data-tab-content="tracker">
        <div class="strava-groups-section">
          <h3>Follow Tracker</h3>

          <!-- Progress bar (hidden by default) -->
          <div id="ft-sidebar-progress" class="ft-sidebar-progress" style="display:none;">
            <div class="ft-sidebar-progress-header">
              <span id="ft-sidebar-progress-step" class="ft-sidebar-progress-step"></span>
              <span id="ft-sidebar-progress-pct" class="ft-sidebar-progress-pct"></span>
            </div>
            <div class="ft-sidebar-progress-bar">
              <div id="ft-sidebar-progress-fill" class="ft-sidebar-progress-fill"></div>
            </div>
            <p id="ft-sidebar-progress-msg" class="ft-sidebar-progress-msg">Scanning…</p>
          </div>

          <!-- Stats strip -->
          <div class="ft-sidebar-stats">
            <div class="ft-sidebar-stat">
              <span class="ft-sidebar-stat-label">Followers</span>
              <span id="ft-sidebar-followers" class="ft-sidebar-stat-value">—</span>
            </div>
            <div class="ft-sidebar-stat">
              <span class="ft-sidebar-stat-label">Following</span>
              <span id="ft-sidebar-following" class="ft-sidebar-stat-value">—</span>
            </div>
            <div class="ft-sidebar-stat">
              <span class="ft-sidebar-stat-label">Mutual</span>
              <span id="ft-sidebar-mutual" class="ft-sidebar-stat-value">—</span>
            </div>
          </div>

          <p id="ft-sidebar-last-scan" class="ft-sidebar-last-scan">Never scanned</p>

          <!-- Changes since last scan -->
          <div id="ft-sidebar-changes" class="ft-sidebar-changes" style="display:none;">
            <h4>Since Last Scan</h4>
            <ul id="ft-sidebar-changes-list" class="ft-sidebar-changes-list"></ul>
          </div>

          <!-- Actions -->
          <div class="ft-sidebar-actions">
            <button id="ft-sidebar-scan-btn" class="strava-groups-action-btn">🔍 Scan Now</button>
            <button id="ft-sidebar-export-btn" class="strava-groups-action-btn">📄 Export CSV</button>
          </div>

          <!-- History -->
          <div id="ft-sidebar-history-section" class="ft-sidebar-history-section" style="display:none;">
            <h4 class="ft-history-heading">History</h4>
            <div class="ft-history-filters">
              <select id="ft-filter-period" class="ft-filter-select">
                <option value="all">All time</option>
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
              </select>
              <select id="ft-filter-type" class="ft-filter-select">
                <option value="all">All events</option>
                <option value="followers">Followers ±</option>
                <option value="following">Following ±</option>
                <option value="names">Name changes</option>
              </select>
            </div>
            <div id="ft-history-summary" class="ft-history-summary"></div>
            <ul id="ft-sidebar-history-list" class="ft-sidebar-history-list"></ul>
          </div>

          <p id="ft-sidebar-error" class="ft-sidebar-error" style="display:none;"></p>

          <!-- Settings -->
          <details id="ft-sidebar-settings" class="ft-sidebar-settings">
            <summary class="ft-sidebar-settings-summary">⚙ Settings</summary>
            <div class="ft-sidebar-settings-body">
              <label class="ft-sidebar-setting">
                <span class="ft-sidebar-setting-label">Max pages per scan</span>
                <span class="ft-sidebar-setting-hint">Strava returns ~25 athletes per page</span>
                <input type="number" id="ft-setting-max-pages" class="ft-sidebar-setting-input"
                  min="1" max="2000" placeholder="400">
              </label>
              <p class="ft-sidebar-setting-derived" id="ft-setting-derived"></p>
              <label class="ft-sidebar-setting">
                <span class="ft-sidebar-setting-label">Force full scan after (days)</span>
                <span class="ft-sidebar-setting-hint">Always scan both lists when this many days have passed since the last full scan. Default: 14.</span>
                <input type="number" id="ft-setting-full-scan-interval" class="ft-sidebar-setting-input"
                  min="1" max="365" placeholder="14">
              </label>
              <p class="ft-sidebar-setting-derived" id="ft-setting-last-full-scan"></p>
              <button id="ft-sidebar-settings-save" class="strava-groups-action-btn ft-settings-save-btn">Save</button>
              <p id="ft-sidebar-settings-msg" class="ft-sidebar-settings-msg" style="display:none;"></p>

              <!-- Danger Zone -->
              <div class="ft-danger-zone">
                <p class="ft-danger-zone-title">⚠ Danger Zone</p>
                <p class="ft-danger-zone-desc">Permanently delete all stored history and snapshots. Type <strong>RESET</strong> to confirm.</p>
                <div class="ft-danger-confirm" id="ft-danger-confirm">
                  <input type="text" id="ft-danger-input" class="ft-danger-input"
                    placeholder="Type RESET to confirm" autocomplete="off" spellcheck="false">
                  <button id="ft-danger-clear-btn" class="ft-danger-btn" disabled>Delete Everything</button>
                </div>
                <p id="ft-danger-msg" class="ft-danger-msg" style="display:none;"></p>
              </div>
        </div>
      </div>
    </div>
  `;
  
  // Add panel to page (button is inserted next to upload button in insertButton function)
  document.body.appendChild(panel);

  // ── Resizable panel ──────────────────────────────────────────────────────
  const PANEL_MIN_W = 280;
  const PANEL_MAX_W = () => Math.min(Math.round(window.innerWidth * 0.85), 900);
  const savedPanelW = parseInt(localStorage.getItem('sgPanelWidth'), 10) || 400;
  panel.style.setProperty('--panel-w', savedPanelW + 'px');

  const resizeHandle = document.createElement('div');
  resizeHandle.className = 'strava-groups-resize-handle';
  resizeHandle.title = 'Drag to resize';
  panel.insertBefore(resizeHandle, panel.firstChild);

  resizeHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startW = panel.offsetWidth;
    panel.style.transition = 'none';
    resizeHandle.classList.add('dragging');

    function onMouseMove(ev) {
      const delta = startX - ev.clientX; // drag left → wider
      const newW  = Math.max(PANEL_MIN_W, Math.min(PANEL_MAX_W(), startW + delta));
      panel.style.setProperty('--panel-w', newW + 'px');
    }

    function onMouseUp() {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      panel.style.transition = '';
      resizeHandle.classList.remove('dragging');
      localStorage.setItem('sgPanelWidth', panel.offsetWidth);
    }

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });
  // ─────────────────────────────────────────────────────────────────────────

  // Event listeners - stop propagation to prevent triggering Strava's upload menu
  floatingButton.addEventListener('click', (e) => {
    e.stopPropagation();
    e.preventDefault();
    panel.classList.toggle('open');
  });
  
  floatingButton.addEventListener('mouseenter', (e) => {
    e.stopPropagation();
  });
  
  floatingButton.addEventListener('mouseover', (e) => {
    e.stopPropagation();
  });
  
  floatingButton.addEventListener('mousedown', (e) => {
    e.stopPropagation();
  });
  
  panel.querySelector('.strava-groups-close-btn').addEventListener('click', () => {
    panel.classList.remove('open');
  });
  
  // Tab switching functionality
  const tabs = panel.querySelectorAll('.strava-groups-tab');
  const tabContents = panel.querySelectorAll('.strava-groups-tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.dataset.tab;
      
      // Remove active class from all tabs and contents
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(tc => tc.classList.remove('active'));
      
      // Add active class to clicked tab and corresponding content
      tab.classList.add('active');
      const targetContent = panel.querySelector(`[data-tab-content="${targetTab}"]`);
      if (targetContent) {
        targetContent.classList.add('active');
      }
      // Init Follow Tracker panel when its tab is first activated
      if (targetTab === 'tracker') {
        ftInitSidebarTab();
      }
    });
  });
  
  // Close on escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panel.classList.contains('open')) {
      panel.classList.remove('open');
    }
  });
  
  // Button event listeners
  document.getElementById('strava-groups-create-btn').addEventListener('click', createGroupFromUI);
  document.getElementById('strava-groups-add-btn').addEventListener('click', addAthletesToGroupFromUI);
  document.getElementById('strava-groups-clear-selection').addEventListener('click', clearSelectedAthletes);
  document.getElementById('strava-groups-export-btn').addEventListener('click', exportData);
  document.getElementById('strava-groups-import-btn').addEventListener('click', () => {
    const fileInput = document.getElementById('strava-groups-import-file');
    if (fileInput) {
      fileInput.click();
    } else {
  console.error('[feed-groups] ❌ File input not found!');
    }
  });
  document.getElementById('strava-groups-import-file').addEventListener('change', importData);

  // Populate last-backup date
  browser.storage.local.get(['lastBackupDate']).then(r => ftUpdateLastBackupStatus(r.lastBackupDate || null)).catch(() => {});
  
  // Follow Tracker sidebar buttons
  document.getElementById('ft-sidebar-scan-btn').addEventListener('click', ftSidebarScanNow);
  document.getElementById('ft-sidebar-export-btn').addEventListener('click', ftSidebarExportCSV);
  document.getElementById('ft-sidebar-settings-save').addEventListener('click', ftSidebarSaveSettings);
  document.getElementById('ft-setting-max-pages').addEventListener('input', ftSidebarUpdateDerived);
  document.getElementById('ft-setting-full-scan-interval').addEventListener('input', ftSidebarUpdateDerived);
  document.getElementById('kudos-sidebar-settings-save').addEventListener('click', kudosSidebarSaveSettings);
  document.getElementById('ft-danger-input').addEventListener('input', ftDangerInputChanged);
  document.getElementById('ft-danger-clear-btn').addEventListener('click', ftDangerClearAll);
  document.getElementById('ft-filter-period').addEventListener('change', ftApplyHistoryFilters);
  document.getElementById('ft-filter-type').addEventListener('change', ftApplyHistoryFilters);
  document.getElementById('whats-new-dismiss').addEventListener('click', ftDismissWhatsNew);

  // Enter key support for inputs
  document.getElementById('strava-groups-new-group-name').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      createGroupFromUI();
    }
  });
  
  // Remember last selected group
  document.getElementById('strava-groups-select').addEventListener('change', (e) => {
    lastSelectedGroupId = e.target.value;
  });
  
  // Initialize UI
  updateGroupManagementUI();
  updateSelectedAthleteUI();
  kudosSidebarLoadSettings();
  ftCheckWhatsNew();
  ftInitAboutTab();
}

// Update the groups list in the UI
async function updateGroupManagementUI() {
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  log(`[feed-groups] 📦 Storage loaded (UI update) in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  const groupsList = document.getElementById('strava-groups-list');
  const groupSelect = document.getElementById('strava-groups-select');
  
  if (!groupsList) return; // UI not created yet
  
  // Update groups list
  if (Object.keys(groups).length === 0) {
    groupsList.innerHTML = '<p class="strava-groups-empty">No groups yet</p>';
  } else {
    groupsList.innerHTML = '';
    
    // Sort groups alphabetically by name
    const sortedGroups = Object.entries(groups).sort((a, b) => 
      a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
    );
    
    for (const [groupId, group] of sortedGroups) {
      const groupDiv = document.createElement('div');
      groupDiv.className = 'strava-groups-group-item';
      
      const athleteCount = group.athletes ? group.athletes.length : 0;
      
      // Create header
      const header = document.createElement('div');
      header.className = 'strava-groups-group-header';
      header.dataset.groupId = groupId;
      
      const nameSpan = document.createElement('span');
      nameSpan.className = 'strava-groups-group-name';
      nameSpan.dataset.groupId = groupId;
      nameSpan.textContent = sanitizeText(group.name);
      
      const countSpan = document.createElement('span');
      countSpan.className = 'strava-groups-group-count';
      countSpan.textContent = `${athleteCount} athlete${athleteCount !== 1 ? 's' : ''}`;
      
      const editBtn = document.createElement('button');
      editBtn.className = 'strava-groups-edit-btn';
      editBtn.dataset.groupId = groupId;
      editBtn.title = 'Edit group name';
      editBtn.textContent = '✏️';
      
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'strava-groups-delete-btn';
      deleteBtn.dataset.groupId = groupId;
      deleteBtn.title = 'Delete group';
      deleteBtn.textContent = '🗑️';
      
      header.appendChild(nameSpan);
      header.appendChild(countSpan);
      header.appendChild(editBtn);
      header.appendChild(deleteBtn);
      
      const athletesList = document.createElement('div');
      athletesList.className = 'strava-groups-athletes-list';
      athletesList.style.display = 'none';
      
      groupDiv.appendChild(header);
      groupDiv.appendChild(athletesList);
      
      // Toggle athletes list
      groupDiv.querySelector('.strava-groups-group-header').addEventListener('click', (e) => {
        if (e.target.classList.contains('strava-groups-delete-btn') || 
            e.target.classList.contains('strava-groups-edit-btn') ||
            e.target.tagName === 'INPUT') return;
        toggleAthletesListUI(groupDiv, group);
      });
      
      // Edit button
      groupDiv.querySelector('.strava-groups-edit-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        editGroupNameInline(groupId, group.name, e.target);
      });
      
      // Delete button
      groupDiv.querySelector('.strava-groups-delete-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        deleteGroupFromUI(groupId, group.name);
      });
      
      groupsList.appendChild(groupDiv);
    }
  }
  
  // Update select
  groupSelect.innerHTML = '<option value="">Select a group...</option>';
  
  // Sort groups alphabetically by name
  const sortedGroupsSelect = Object.entries(groups).sort((a, b) => 
    a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
  );
  
  for (const [groupId, group] of sortedGroupsSelect) {
    const option = document.createElement('option');
    option.value = groupId;
    option.textContent = group.name;
    groupSelect.appendChild(option);
  }
  
  // Restore last selected group
  if (lastSelectedGroupId && groups[lastSelectedGroupId]) {
    groupSelect.value = lastSelectedGroupId;
  }
  
  // Update top filter dropdown if it exists
  updateTopFilterDropdown();
}

// Update selected athlete display
async function updateSelectedAthleteUI() {
  const athleteDiv = document.getElementById('strava-groups-selected-athlete');
  const addSection = document.getElementById('strava-groups-add-section');
  const countSpan = document.getElementById('strava-groups-selected-count');
  const clearBtn = document.getElementById('strava-groups-clear-selection');
  
  if (!athleteDiv) return; // UI not created yet
  
  // Load groups to check membership
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  // Update count
  if (countSpan) {
    countSpan.textContent = selectedAthletes.length;
  }
  
  if (selectedAthletes.length > 0) {
    // Calculate pagination
    const totalPages = Math.ceil(selectedAthletes.length / ATHLETES_PER_PAGE);
    const startIndex = (selectedAthletesPage - 1) * ATHLETES_PER_PAGE;
    const endIndex = Math.min(startIndex + ATHLETES_PER_PAGE, selectedAthletes.length);
    const athletesToShow = selectedAthletes.slice(startIndex, endIndex);
    
    // Show list of selected athletes with pagination
    athleteDiv.innerHTML = '<div class="strava-groups-selected-list"></div>';
    const listDiv = athleteDiv.querySelector('.strava-groups-selected-list');
    
    athletesToShow.forEach((athlete, displayIndex) => {
      const actualIndex = startIndex + displayIndex;
      const athleteCard = document.createElement('div');
      athleteCard.className = 'strava-groups-athlete-card';
      
      // Find which groups this athlete belongs to
      const athleteGroups = [];
      for (const [groupId, group] of Object.entries(groups)) {
        if (group.athletes && group.athletes.some(a => String(a.id) === String(athlete.id))) {
          athleteGroups.push(group.name);
        }
      }
      
      // Sort groups alphabetically
      athleteGroups.sort((a, b) => alphabeticalSort(a, b));
      
      const cardContent = document.createElement('div');
      
      const nameStrong = document.createElement('strong');
      nameStrong.textContent = sanitizeText(athlete.name);
      
      const idSpan = document.createElement('span');
      idSpan.className = 'strava-groups-athlete-id';
      idSpan.textContent = `ID: ${athlete.id}`;
      
      cardContent.appendChild(nameStrong);
      cardContent.appendChild(idSpan);
      
      if (athleteGroups.length > 0) {
        const memberOf = document.createElement('div');
        memberOf.className = 'strava-groups-member-of';
        
        const label = document.createElement('span');
        label.className = 'strava-groups-member-label';
        label.textContent = 'Groups:';
        
        const memberList = document.createElement('div');
        memberList.className = 'strava-groups-member-list';
        
        athleteGroups.forEach(name => {
          const tag = document.createElement('span');
          tag.className = 'strava-groups-member-tag';
          tag.textContent = sanitizeText(name);
          memberList.appendChild(tag);
        });
        
        memberOf.appendChild(label);
        memberOf.appendChild(memberList);
        cardContent.appendChild(memberOf);
      }
      
      const removeBtn = document.createElement('button');
      removeBtn.className = 'strava-groups-remove-selection-btn';
      removeBtn.dataset.index = actualIndex;
      removeBtn.title = 'Remove from selection';
      removeBtn.textContent = '✕';
      
      athleteCard.appendChild(cardContent);
      athleteCard.appendChild(removeBtn);
      
      athleteCard.querySelector('.strava-groups-remove-selection-btn').addEventListener('click', async () => {
        selectedAthletes.splice(actualIndex, 1);
        // Reset to page 1 if current page would be empty
        if (selectedAthletes.length > 0 && startIndex >= selectedAthletes.length) {
          selectedAthletesPage = Math.max(1, selectedAthletesPage - 1);
        }
        if (selectedAthletes.length > 0) {
          await browser.storage.local.set({ selectedAthletes });
        } else {
          await browser.storage.local.remove('selectedAthletes');
          await browser.storage.local.remove('selectedAthlete');
        }
        updateSelectedAthleteUI();
      });
      
      listDiv.appendChild(athleteCard);
    });
    
    // Add pagination controls if needed
    if (totalPages > 1) {
      const paginationDiv = document.createElement('div');
      paginationDiv.className = 'strava-groups-pagination';
      
      const prevBtn = document.createElement('button');
      prevBtn.className = 'strava-groups-pagination-btn';
      prevBtn.textContent = '‹ Previous';
      prevBtn.disabled = selectedAthletesPage === 1;
      prevBtn.addEventListener('click', () => {
        selectedAthletesPage = Math.max(1, selectedAthletesPage - 1);
        updateSelectedAthleteUI();
      });
      
      const pageInfo = document.createElement('span');
      pageInfo.className = 'strava-groups-pagination-info';
      pageInfo.textContent = `Page ${selectedAthletesPage} of ${totalPages} (${startIndex + 1}-${endIndex} of ${selectedAthletes.length})`;
      
      const nextBtn = document.createElement('button');
      nextBtn.className = 'strava-groups-pagination-btn';
      nextBtn.textContent = 'Next ›';
      nextBtn.disabled = selectedAthletesPage === totalPages;
      nextBtn.addEventListener('click', () => {
        selectedAthletesPage = Math.min(totalPages, selectedAthletesPage + 1);
        updateSelectedAthleteUI();
      });
      
      paginationDiv.appendChild(prevBtn);
      paginationDiv.appendChild(pageInfo);
      paginationDiv.appendChild(nextBtn);
      athleteDiv.appendChild(paginationDiv);
    }
    
    addSection.style.display = 'block';
    if (clearBtn) clearBtn.style.display = 'inline-block';
  } else {
    athleteDiv.innerHTML = '<p>Click the <span style="display: inline-flex; align-items: center; justify-content: center; color: #FC4C02; font-weight: bold; border: 2px solid #FC4C02; border-radius: 50%; width: 18px; height: 18px; font-size: 14px; line-height: 1;">+</span> icon next to athlete names to select them</p>';
    addSection.style.display = 'none';
    if (clearBtn) clearBtn.style.display = 'none';
    selectedAthletesPage = 1; // Reset page when cleared
  }
}

// Clear selected athletes
async function clearSelectedAthletes() {
  selectedAthletes = [];
  await browser.storage.local.remove(['selectedAthletes', 'selectedAthlete']);
  updateSelectedAthleteUI();
  showNotification('Selection cleared');
}

// Toggle athletes list in a group
function toggleAthletesListUI(groupDiv, group) {
  const athletesList = groupDiv.querySelector('.strava-groups-athletes-list');
  
  if (athletesList.style.display === 'none') {
    if (!group.athletes || group.athletes.length === 0) {
      athletesList.innerHTML = '<p class="strava-groups-empty">No athletes in this group</p>';
    } else {
      athletesList.innerHTML = '';
      
      // Sort athletes alphabetically by name
      const sortedAthletes = [...group.athletes].sort((a, b) => 
        alphabeticalSort(a.name, b.name)
      );
      
      sortedAthletes.forEach(athlete => {
        const athleteDiv = document.createElement('div');
        athleteDiv.className = 'strava-groups-athlete-item';
        
        const nameSpan = document.createElement('span');
        nameSpan.textContent = sanitizeText(athlete.name);
        
        const removeBtn = document.createElement('button');
        removeBtn.className = 'strava-groups-remove-btn';
        removeBtn.dataset.groupId = group.id;
        removeBtn.dataset.athleteId = athlete.id;
        removeBtn.title = 'Remove from group';
        removeBtn.textContent = '✕';
        
        athleteDiv.appendChild(nameSpan);
        athleteDiv.appendChild(removeBtn);
        
        athleteDiv.querySelector('.strava-groups-remove-btn').addEventListener('click', (e) => {
          e.stopPropagation();
          removeAthleteFromGroupUI(group.id, athlete.id);
        });
        
        athletesList.appendChild(athleteDiv);
      });
    }
    athletesList.style.display = 'block';
  } else {
    athletesList.style.display = 'none';
  }
}

// Create group from UI
async function createGroupFromUI() {
  const nameInput = document.getElementById('strava-groups-new-group-name');
  const name = nameInput.value.trim();
  
  if (!name) {
    showNotification('Please enter a group name');
    return;
  }
  
  if (name.length > 50) {
    showNotification('Group name must be 50 characters or less');
    return;
  }
  
  const sanitizedName = name.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  if (sanitizedName !== name) {
    showNotification('Group name contains invalid characters');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  const groupId = 'group_' + Date.now() + '_' + Math.random().toString(36).slice(2, 11);
  
  groups[groupId] = {
    id: groupId,
    name: sanitizedName,
    athletes: []
  };
  
  await browser.storage.local.set({ groups });
  
  nameInput.value = '';
  showNotification(`Group "${sanitizedName}" created`);
}

// Add athlete to group from UI
async function addAthletesToGroupFromUI() {
  if (selectedAthletes.length === 0) {
    showNotification('No athletes selected');
    return;
  }
  
  const groupSelect = document.getElementById('strava-groups-select');
  const groupId = groupSelect.value;
  
  if (!groupId) {
    showNotification('Please select a group');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (!groups[groupId]) {
    showNotification('Group not found');
    return;
  }
  
  let addedCount = 0;
  let skippedCount = 0;
  
  selectedAthletes.forEach(athlete => {
    if (!groups[groupId].athletes.some(a => a.id === athlete.id)) {
      groups[groupId].athletes.push(athlete);
      addedCount++;
    } else {
      skippedCount++;
    }
  });
  
  await browser.storage.local.set({ groups });
  
  // Clear selection after adding
  selectedAthletes = [];
  await browser.storage.local.remove(['selectedAthletes', 'selectedAthlete']);
  updateSelectedAthleteUI();
  
  const message = addedCount > 0 
    ? `Added ${addedCount} athlete${addedCount !== 1 ? 's' : ''} to ${groups[groupId].name}${skippedCount > 0 ? ` (${skippedCount} already in group)` : ''}`
    : `All selected athletes already in ${groups[groupId].name}`;
  
  showNotification(message);
  
  // Keep the group selected for next batch
  lastSelectedGroupId = groupId;
}

// Edit group name inline
async function editGroupNameInline(groupId, currentName, editButton) {
  // Find the group name span
  const nameSpan = document.querySelector(`.strava-groups-group-name[data-group-id="${groupId}"]`);
  if (!nameSpan) return;
  
  // Create input element
  const input = document.createElement('input');
  input.type = 'text';
  input.value = currentName;
  input.className = 'strava-groups-edit-input';
  input.style.width = '150px';
  input.style.fontSize = '14px';
  input.style.padding = '2px 6px';
  input.style.border = '1px solid #FC4C02';
  input.style.borderRadius = '3px';
  input.style.outline = 'none';
  
  // Function to save changes
  const saveEdit = async () => {
    const newName = input.value.trim();
    
    if (!newName) {
      showNotification('Group name cannot be empty');
      input.focus();
      return;
    }
    
    if (newName === currentName) {
      // No change, just restore
      nameSpan.textContent = currentName;
      nameSpan.style.display = '';
      editButton.style.display = '';
      input.remove();
      return;
    }
    
    // Save to storage
    const result = await browser.storage.local.get(['groups']);
    const groups = result.groups || {};
    
    if (groups[groupId]) {
      groups[groupId].name = newName;
      await browser.storage.local.set({ groups });
      
      // Update UI
      nameSpan.textContent = sanitizeText(newName);
      nameSpan.style.display = '';
      editButton.style.display = '';
      input.remove();
      
      // Update dropdown
      updateTopFilterDropdown();
      
      showNotification(`Renamed to "${sanitizeText(newName)}"`);
    }
  };
  
  // Function to cancel edit
  const cancelEdit = () => {
    nameSpan.style.display = '';
    editButton.style.display = '';
    input.remove();
  };
  
  // Handle enter key to save
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveEdit();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      cancelEdit();
    }
  });
  
  // Handle blur to save
  input.addEventListener('blur', saveEdit);
  
  // Replace span with input
  nameSpan.style.display = 'none';
  editButton.style.display = 'none';
  nameSpan.parentNode.insertBefore(input, nameSpan);
  input.focus();
  input.select();
}

// Delete group from UI
async function deleteGroupFromUI(groupId, groupName) {
  const confirmed = await showConfirmDialog(`Delete group "${groupName}"?`);
  if (!confirmed) {
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  delete groups[groupId];
  
  await browser.storage.local.set({ groups });
  
  showNotification('Group deleted');
}

// Remove athlete from group
async function removeAthleteFromGroupUI(groupId, athleteId) {
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (groups[groupId]) {
    groups[groupId].athletes = groups[groupId].athletes.filter(a => a.id !== athleteId);
    await browser.storage.local.set({ groups });
    showNotification('Athlete removed from group');
  }
}

// Apply filter from UI
function applyFilterFromUI() {
  const filterSelect = document.getElementById('strava-groups-filter-select');
  const groupId = filterSelect.value;
  
  if (groupId) {
    applyFilter(groupId);
  } else {
    clearCurrentFilter();
  }
}

// Add filter dropdown to the top of the page (next to Strava's filters)
function addTopFilterDropdown() {
  // Only add on dashboard or feed pages
  if (!window.location.pathname.match(/\/(dashboard|athlete\/training)/)) {
    return;
  }
  
  // Check if already added
  if (document.getElementById('strava-groups-top-filter')) {
    return;
  }
  
  // Function to try inserting the dropdown
  const tryInsertDropdown = () => {
    // Look for the feed filter form using stable selectors
    // Find form containing input#feedFilter
    // Note: :has() requires Firefox 121+, so we use fallback for Firefox 109-120
    const feedInput = document.querySelector('input#feedFilter');
    let form = feedInput?.closest('form');
    
    if (!form) {
      log('[feed-groups] Feed filter form not found yet (looking for input#feedFilter)');
      return false;
    }
    
    // Look for feed-header - try multiple locations
    let feedHeader = form.querySelector('.feed-header');
    if (!feedHeader) {
      // Try finding it as a sibling after the form
      feedHeader = form.nextElementSibling;
      if (feedHeader && !feedHeader.classList.contains('feed-header')) {
        feedHeader = null;
      }
    }
    if (!feedHeader) {
      // Try finding it in parent element
      feedHeader = form.parentElement?.querySelector('.feed-header');
    }
    
    // If still not found, create it inside the form (inline with Strava filter)
    // Complex insertion logic needed because Chrome and Firefox have different DOM structures
    // - Firefox: .feed-header exists as sibling
    // - Chrome: No .feed-header, need to insert into form and expand width
    let insertionPoint;
    if (feedHeader) {
      insertionPoint = feedHeader;
      log('[feed-groups] ✓ Found existing .feed-header');
    } else {
      // Expand the form to accommodate both dropdowns side-by-side
      // Without this, Strava's dropdown gets compressed
      form.style.maxWidth = 'none';
      form.style.justifyContent = 'flex-start';
      form.style.gap = '16px';
      
      // Create a div inside the form to hold our dropdown inline with Strava filter
      const wrapper = document.createElement('div');
      wrapper.style.cssText = 'display: inline-flex; align-items: center; flex-shrink: 0;';
      
      // Insert it at the end of the form (next to Strava filter)
      form.appendChild(wrapper);
      insertionPoint = wrapper;
      log('[feed-groups] ✓ Created inline wrapper inside form');
    }
    
    // Create our filter dropdown wrapper
    const filterWrapper = document.createElement('div');
    filterWrapper.id = 'strava-groups-top-filter';
    filterWrapper.className = 'strava-groups-top-filter';
    filterWrapper.style.cssText = 'display: inline-flex; align-items: center; gap: 8px;';
    
    const label = document.createElement('label');
    label.textContent = 'Group: ';
    label.style.marginRight = '8px';
    label.style.fontSize = '14px';
    label.style.color = '#666';
    
    const filterSelect = document.createElement('select');
    filterSelect.id = 'strava-groups-top-filter-select';
    filterSelect.className = 'strava-groups-top-filter-select';
    filterSelect.innerHTML = '<option value="">All Athletes</option>';
    
    filterSelect.addEventListener('change', async (e) => {
      const groupId = e.target.value;
      if (groupId) {
        await applyFilter(groupId);
      } else {
        clearCurrentFilter();
      }
      // Remove focus from dropdown so keyboard navigation (Home/End) works on page
      e.target.blur();
    });
    
    filterWrapper.appendChild(label);
    filterWrapper.appendChild(filterSelect);
    
    // Add status area: two stacked rows so filter info and kudos counter
    // are always visible simultaneously and never overwrite each other.
    const statusArea = document.createElement('div');
    statusArea.id = 'strava-groups-status-area';
    statusArea.style.cssText = 'display: flex; flex-direction: column; justify-content: center; margin-left: 12px; min-width: 120px;';

    const progressIndicator = document.createElement('span');
    progressIndicator.id = 'strava-groups-filter-progress';
    progressIndicator.className = 'strava-groups-filter-progress';

    const kudosProgress = document.createElement('span');
    kudosProgress.id = 'strava-groups-kudos-progress';
    kudosProgress.className = 'strava-groups-kudos-progress';

    statusArea.appendChild(progressIndicator);
    statusArea.appendChild(kudosProgress);
    filterWrapper.appendChild(statusArea);

    // Add "Give Kudos" button
    const kudosBtn = document.createElement('button');
    kudosBtn.id = 'strava-groups-bulk-kudos-btn';
    kudosBtn.className = 'strava-groups-bulk-kudos-btn';
    kudosBtn.type = 'button';
    kudosBtn.title = 'Give kudos to all visible activities that have not been kudo\'d yet';
    kudosBtn.setAttribute('aria-label', 'Give kudos to all visible activities that have not been kudo\'d yet');
    kudosBtn.innerHTML = '<svg fill="currentColor" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" width="16" height="16"><path d="M6.18.36A.625.625 0 016.746 0h.366a2.625 2.625 0 012.609 2.918L9.374 6h3.69a2.185 2.185 0 011.68 3.584l-.119.142v1.291c0 .458-.16.902-.454 1.254l-.171.205v.399A2.125 2.125 0 0111.875 15H5.703c-.256 0-.507-.077-.72-.22l-1.157-.777a.042.042 0 00-.024-.007l-1.483.031A1.292 1.292 0 011 12.736V8.81c0-.38.168-.742.46-.988l2.032-1.711zm.964.89L4.566 6.765a.625.625 0 01-.163.213l-2.138 1.8a.042.042 0 00-.015.032v3.926c0 .023.02.042.043.041l1.483-.03c.266-.006.527.07.748.219l1.156.777a.042.042 0 00.023.007h6.172a.875.875 0 00.875-.875v-.851l.46-.553a.708.708 0 00.165-.454V9.274l.408-.49a.935.935 0 00-.718-1.534h-5.09l.504-4.471c.09-.805-.53-1.51-1.335-1.529z"></path></svg>';
    kudosBtn.addEventListener('click', () => giveBulkKudos());
    filterWrapper.appendChild(kudosBtn);
    
    // Insert into the insertion point (feedHeader)
    // Try to append as first child or just append
    if (insertionPoint.firstChild) {
      insertionPoint.insertBefore(filterWrapper, insertionPoint.firstChild);
      log('✓ Inserted dropdown as first child');
    } else {
      insertionPoint.appendChild(filterWrapper);
      log('✓ Appended dropdown to container');
    }
    
    // Initialize with groups
    updateTopFilterDropdown();
    
    return true;
  };
  
  // Try immediately
  if (tryInsertDropdown()) {
    return;
  }
  
  // If not found, wait for it to appear
  log('[feed-groups] Waiting for form.uRdSO2YS and .feed-header to appear...');
  const observer = new MutationObserver((mutations, obs) => {
    if (tryInsertDropdown()) {
      obs.disconnect();
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Timeout after 10 seconds
  setTimeout(() => {
    observer.disconnect();
    if (!document.getElementById('strava-groups-top-filter')) {
      log('[feed-groups] ✗ Timeout: Could not add top filter dropdown after 10 seconds');
    }
  }, 10000);
}


// Update the top filter dropdown with current groups
async function updateTopFilterDropdown() {
  const filterSelect = document.getElementById('strava-groups-top-filter-select');
  if (!filterSelect) return;
  
  const storageStartTime = performance.now();
  const result = await browser.storage.local.get(['groups']);
  const storageTime = (performance.now() - storageStartTime).toFixed(2);
  
  const groups = result.groups || {};
  
  const groupCount = Object.keys(groups).length;
  const totalAthletes = Object.values(groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0);
  log(`[feed-groups] 📦 Storage loaded (dropdown update) in ${storageTime}ms: ${groupCount} groups, ${totalAthletes} total athletes`);
  
  // Store current value
  const currentValue = filterSelect.value;
  
  // Rebuild options
  filterSelect.innerHTML = '<option value="">All Athletes</option>';
  
  // Add virtual filters
  const ungroupedOption = document.createElement('option');
  ungroupedOption.value = '__ungrouped__';
  ungroupedOption.textContent = '🔍 Ungrouped Athletes';
  filterSelect.appendChild(ungroupedOption);
  
  const noKudosOption = document.createElement('option');
  noKudosOption.value = '__nokudos__';
  noKudosOption.textContent = '🤔 No Kudos';
  filterSelect.appendChild(noKudosOption);
  
  // Add separator if there are groups
  if (Object.keys(groups).length > 0) {
    const separator = document.createElement('option');
    separator.disabled = true;
    separator.textContent = '──────────';
    filterSelect.appendChild(separator);
  }
  
  // Sort groups alphabetically by name
  const sortedGroups = Object.entries(groups).sort((a, b) => 
    a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
  );
  
  for (const [groupId, group] of sortedGroups) {
    const option = document.createElement('option');
    option.value = groupId;
    option.textContent = group.name;
    filterSelect.appendChild(option);
  }
  
  // Restore selection
  if (currentValue && (currentValue === '__ungrouped__' || currentValue === '__nokudos__' || groups[currentValue])) {
    filterSelect.value = currentValue;
  } else if (currentFilter && currentFilter.id) {
    filterSelect.value = currentFilter.id;
  }
}

// Export all data to JSON file
async function exportData() {
  try {
    const backupDate = new Date().toISOString();

    // Persist the backup date before we read storage so it's included in the export
    await browser.storage.local.set({ lastBackupDate: backupDate });

    const data = await browser.storage.local.get(null);

    // Exclude transient/debug state — no value in a backup
    delete data.ftScanStatus;
    delete data.ftLastParseError;
    delete data.ftNetworkPending;
    delete data.ftLastFullScanAt;
    delete data.ftFullScanIntervalDays;

    const exportObj = {
      version: browser.runtime.getManifest().version,
      exportDate: backupDate,
      data,
    };

    const jsonStr = JSON.stringify(exportObj, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `strava-athlete-filters-${backupDate.split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    ftUpdateLastBackupStatus(backupDate);
    showNotification('\u2713 Data exported successfully');
  } catch (error) {
    showNotification('\u2717 Export failed: ' + error.message);
  }
}

function ftUpdateLastBackupStatus(isoDate) {
  const el = document.getElementById('ft-last-backup-status');
  if (!el) return;
  if (!isoDate) { el.textContent = 'Last backup: never'; return; }
  el.textContent = 'Last backup: ' + new Date(isoDate).toLocaleString();
}

// Import data from JSON file
async function importData(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    const text = await file.text();
    const importObj = JSON.parse(text);

    if (!importObj.version || !importObj.data) {
      throw new Error('Invalid backup file format');
    }

    const d = importObj.data;

    // Build a human-readable summary of what the backup contains
    const groupCount    = d.groups != null ? Object.keys(d.groups).length : null;
    const totalAthletes = d.groups != null
      ? Object.values(d.groups).reduce((sum, g) => sum + (g.athletes?.length || 0), 0)
      : null;
    const snapshot   = d.followTracker?.latestSnapshot;
    const eventCount = d.followTracker?.events?.length ?? null;

    const lines = [`Restore from backup dated ${importObj.exportDate || 'unknown'}?\n`];
    if (groupCount != null)
      lines.push(`\u2022 ${groupCount} group${groupCount !== 1 ? 's' : ''} (${totalAthletes} athlete${totalAthletes !== 1 ? 's' : ''})`);
    else
      lines.push('\u2022 Groups: not in backup \u2014 existing data will be kept');

    if (d.followTracker != null)
      lines.push(`\u2022 Follow Tracker: ${snapshot ? `snapshot + ${eventCount} event${eventCount !== 1 ? 's' : ''}` : 'included (no snapshot yet)'}`);
    else
      lines.push('\u2022 Follow Tracker: not in backup \u2014 existing data will be kept');

    if (d.loggedInAthleteId != null)
      lines.push(`\u2022 Athlete ID: ${d.loggedInAthleteId}`);

    lines.push('\nOnly keys present in the backup will be restored.');

    const confirmed = await showConfirmDialog(lines.join('\n'));
    if (!confirmed) { event.target.value = ''; return; }

    // Restore only the keys that exist in the backup.
    // We deliberately do NOT clear() first — keys absent from the backup
    // retain their current values, giving graceful handling of missing data.
    // Always strip transient scan state even if it crept into an old backup.
    const toRestore = { ...d };
    delete toRestore.ftScanStatus;
    delete toRestore.ftLastParseError;
    delete toRestore.ftNetworkPending;
    delete toRestore.ftLastFullScanAt;
    delete toRestore.ftFullScanIntervalDays;

    await browser.storage.local.set(toRestore);

    ftUpdateLastBackupStatus(toRestore.lastBackupDate || null);
    await updateGroupManagementUI();
    clearCurrentFilter();

    showNotification('\u2713 Backup restored successfully');
  } catch (error) {
    showNotification('\u2717 Import failed: ' + error.message);
  } finally {
    event.target.value = '';
  }
}

// Add group labels to following/followers pages
async function addGroupLabelsToFollowingPages() {
  log('🏷️ Checking if on following/followers page:', window.location.pathname);
  
  // Check if we're on a following/followers page
  const isFollowingPage = window.location.pathname.match(/\/athletes\/\d+\/follows/);
  
  if (!isFollowingPage) {
    log('❌ Not on following/followers page, skipping labels');
    return;
  }
  
  log('[feed-groups] ✅ On following/followers page, adding group labels');

  // Keep reference to observer for disconnecting/reconnecting
  let observer = null;
  let processing = false;
  
  // Get the tab content element early so it's available in the closure
  const tabContent = document.querySelector('.tab-content');
  
  // Inject indicators and membership badges into each athlete row.
  // Reuses applyIndicatorMembershipState so the visual treatment is identical
  // to the feed and activity-page surfaces.
  const addLabelsToAthletes = () => {
    // Prevent re-entrant calls
    if (processing) {
      log('[feed-groups] ⏸️ Already processing, skipping...');
      return;
    }
    
    processing = true;
    
    // Disconnect observer while we make changes to prevent infinite loop
    if (observer) {
      observer.disconnect();
    }

    const athleteItems = document.querySelectorAll('ul.list-athletes li[data-athlete-id]');
    
    log(`[feed-groups] 🔍 Found ${athleteItems.length} athlete items in list`);
    
    let labeledCount = 0;
    
    athleteItems.forEach(item => {
      const athleteId = item.getAttribute('data-athlete-id');
      
      if (!athleteId) return;
      
      // Skip if already processed
      if (item.hasAttribute('data-strava-groups-processed')) return;
      
      // Find the text-callout div that contains the athlete name
      const nameContainer = item.querySelector('.text-callout');
      if (!nameContainer) return;
      
      const athleteLink = nameContainer.querySelector('a');
      if (!athleteLink) return;
      
      // Mark as processed to prevent re-processing
      item.setAttribute('data-strava-groups-processed', 'true');
      
      const athleteName = athleteLink.textContent.trim();
      if (!athleteLink.getAttribute('data-athlete-name')) {
        athleteLink.setAttribute('data-athlete-name', athleteName);
      }
      
      // Build the indicator the same way as feed / activity pages
      const indicator = document.createElement('span');
      indicator.className = 'strava-groups-indicator';
      indicator.textContent = '+';
      indicator.setAttribute('role', 'button');
      indicator.setAttribute('tabindex', '0');
      indicator.dataset.stravaGroupsIndicatorFor = String(athleteId);
      indicator.dataset.feedbackTimeout = '';
      
      indicator.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await selectAthlete({ id: athleteId, name: athleteName });
        const existingTimeout = indicator.dataset.feedbackTimeout;
        if (existingTimeout) clearTimeout(Number(existingTimeout));
        indicator.textContent = '✓';
        const timeout = setTimeout(() => {
          applyIndicatorMembershipState(indicator, athleteLink, athleteId, athleteName);
          delete indicator.dataset.feedbackTimeout;
        }, 1000);
        indicator.dataset.feedbackTimeout = String(timeout);
      });
      
      indicator.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          indicator.click();
        }
      });
      
      // Append to the link and apply current membership state (badge pills + colour)
      athleteLink.appendChild(indicator);
      applyIndicatorMembershipState(indicator, athleteLink, athleteId, athleteName);
      
      labeledCount++;
    });
    
    if (labeledCount > 0) {
      log(`[feed-groups] ✨ Added buttons and labels to ${labeledCount} athletes`);
    }
    
    // Reconnect observer after processing
    processing = false;
    if (observer && tabContent) {
      observer.observe(tabContent, {
        childList: true,
        subtree: true
      });
    }
  };
  
  // Add labels initially (with a delay to ensure DOM is ready)
  setTimeout(() => {
    addLabelsToAthletes();
  }, 500);
  
  // Observe for dynamic content loading (pagination)
  let observerTimeout;
  observer = new MutationObserver(() => {
    // Debounce: only run after mutations stop for 200ms
    clearTimeout(observerTimeout);
    observerTimeout = setTimeout(() => {
      addLabelsToAthletes();
    }, 200);
  });
  
  // Start observing
  if (tabContent) {
    log('👀 Observing .tab-content for changes');
    observer.observe(tabContent, {
      childList: true,
      subtree: true
    });
  } else {
    log('⚠️ .tab-content not found, labels may not update on pagination');
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Follow Tracker — sidebar tab helpers
// ─────────────────────────────────────────────────────────────────────────────

// Cached event list so filter dropdowns can re-render without re-reading storage
let ftAllEvents = [];

// Release notes shown in the What’s New banner, keyed by version string
const WHATS_NEW = {
  '0.1.0': [
    'Follow Tracker: scan followers & following, detect gains, losses and renames over time',
    'Filterable history log — filter by time period (7 / 30 / 90 days) and event type',
    'Resizable sidebar panel — drag the left edge to adjust width',
    'Configurable max scan depth and CSV export of full history',
  ],
};

async function ftCheckWhatsNew() {
  try {
    const r = await browser.storage.local.get(['whatsNew', 'dismissedWhatsNew']);
    const wn = r.whatsNew;
    if (!wn || !wn.version) return;
    if (r.dismissedWhatsNew === wn.version) return;
    const notes = WHATS_NEW[wn.version];
    if (!notes) return; // no notes registered for this version

    const banner  = document.getElementById('whats-new-banner');
    const verEl   = document.getElementById('whats-new-version');
    const listEl  = document.getElementById('whats-new-list');
    if (!banner || !verEl || !listEl) return;

    verEl.textContent  = wn.version;
    listEl.innerHTML   = notes.map(n => `<li>${n}</li>`).join('');
    banner.style.display = '';
  } catch (err) {
    // non-fatal
  }
}

async function ftDismissWhatsNew() {
  const banner = document.getElementById('whats-new-banner');
  if (banner) banner.style.display = 'none';
  try {
    const r = await browser.storage.local.get('whatsNew');
    if (r.whatsNew && r.whatsNew.version) {
      await browser.storage.local.set({ dismissedWhatsNew: r.whatsNew.version });
    }
  } catch (err) {
    // non-fatal
  }
}

function ftInitAboutTab() {
  try {
    const manifest = browser.runtime.getManifest();
    const ver = manifest.version;
    const verEl = document.getElementById('about-version-num');
    if (verEl) verEl.textContent = ver;

    const listEl = document.getElementById('about-whats-new-list');
    if (listEl) {
      const notes = WHATS_NEW[ver];
      if (notes && notes.length) {
        listEl.innerHTML = notes.map(n => `<li>${n}</li>`).join('');
      } else {
        listEl.innerHTML = '<li>No notes registered for this version.</li>';
      }
    }
  } catch (err) {
    // non-fatal
  }
}
async function ftInitSidebarTab() {
  try {
    const result = await browser.storage.local.get(['followTracker', 'loggedInAthleteId', 'ftScanSettings', 'ftFullScanIntervalDays', 'ftLastFullScanAt']);
    const data = result.followTracker || null;
    ftRenderSidebarStats(data, result.loggedInAthleteId || null);
    ftRenderSidebarChanges(data);
    ftRenderSidebarHistory(data);
    ftSidebarLoadSettings(result.ftScanSettings || {}, {
      ftFullScanIntervalDays: result.ftFullScanIntervalDays,
      ftLastFullScanAt: result.ftLastFullScanAt,
    });
  } catch (err) {
    ftSidebarShowError('Failed to load data: ' + err.message);
  }
}

function ftRenderSidebarStats(data, athleteId) {
  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };

  // Show which athlete ID is being used (helps diagnose wrong/missing ID)
  const lsEl = document.getElementById('ft-sidebar-last-scan');

  if (!data || !data.latestSnapshot) {
    setEl('ft-sidebar-followers', '—');
    setEl('ft-sidebar-following', '—');
    setEl('ft-sidebar-mutual', '—');
    if (lsEl) lsEl.textContent = 'Never scanned' + (athleteId ? ` (athlete ${athleteId})` : ' (athlete ID unknown)');
    return;
  }

  const snap = data.latestSnapshot;
  const followerIds  = new Set(Object.keys(snap.followers  || {}));
  const followingIds = new Set(Object.keys(snap.following  || {}));
  const mutualCount  = [...followerIds].filter(id => followingIds.has(id)).length;

  setEl('ft-sidebar-followers', followerIds.size);
  setEl('ft-sidebar-following', followingIds.size);
  setEl('ft-sidebar-mutual',    mutualCount);

  if (lsEl) {
    const scanStr = data.lastScanDate
      ? 'Last scanned: ' + new Date(data.lastScanDate * 1000).toLocaleString()
      : 'Never scanned';
    const idStr = athleteId ? ` · athlete ${athleteId}` : '';
    const warnStr = (followerIds.size === 0 && followingIds.size === 0 && data.lastScanDate)
      ? ' ⚠️ 0 results — check console for API shape errors'
      : '';
    lsEl.textContent = scanStr + idStr + warnStr;
  }
}

function ftRenderSidebarChanges(data) {
  const section = document.getElementById('ft-sidebar-changes');
  const list    = document.getElementById('ft-sidebar-changes-list');
  if (!section || !list) return;

  const events = (data && data.events) ? data.events : [];
  if (events.length === 0) { section.style.display = 'none'; return; }

  const labels = {
    follower_gained: '📈 Follower +',
    follower_lost:   '📉 Follower −',
    followed:        '➕ Following',
    unfollowed:      '➖ Unfollowed',
    name_changed:    '✏️ Renamed',
  };

  const summary = {};
  events.forEach(e => { summary[e.type] = (summary[e.type] || 0) + 1; });

  list.innerHTML = Object.entries(summary)
    .map(([type, count]) => `<li>${labels[type] || type}: <strong>${count}</strong></li>`)
    .join('');
  section.style.display = '';
}

function ftRenderSidebarHistory(data) {
  const section = document.getElementById('ft-sidebar-history-section');
  if (!section) return;

  ftAllEvents = (data && data.events) ? data.events : [];
  if (ftAllEvents.length === 0) { section.style.display = 'none'; return; }
  section.style.display = '';
  ftApplyHistoryFilters();
}

function ftApplyHistoryFilters() {
  const list    = document.getElementById('ft-sidebar-history-list');
  const summary = document.getElementById('ft-history-summary');
  if (!list) return;

  const periodEl  = document.getElementById('ft-filter-period');
  const typeEl    = document.getElementById('ft-filter-type');
  const period    = periodEl ? periodEl.value : 'all';
  const typeFilter = typeEl ? typeEl.value : 'all';

  // Compute cutoff date string (YYYY-MM-DD) for period filtering
  let cutoff = null;
  if (period !== 'all') {
    const d = new Date();
    d.setDate(d.getDate() - parseInt(period, 10));
    cutoff = d.toISOString().slice(0, 10);
  }

  const typeGroups = {
    followers: ['follower_gained', 'follower_lost'],
    following: ['followed', 'unfollowed'],
    names:     ['name_changed'],
  };

  let filtered = [...ftAllEvents];
  if (cutoff) {
    filtered = filtered.filter(e => (e.date || '') >= cutoff);
  }
  if (typeFilter !== 'all') {
    const allowed = typeGroups[typeFilter] || [];
    filtered = filtered.filter(e => allowed.includes(e.type));
  }

  // Summary count strip
  const counts = { follower_gained: 0, follower_lost: 0, followed: 0, unfollowed: 0, name_changed: 0 };
  for (const e of filtered) { if (e.type in counts) counts[e.type]++; }
  if (summary) {
    summary.innerHTML =
      `<span class="ft-sum-item" title="Followers gained">📈 ${counts.follower_gained}</span>` +
      `<span class="ft-sum-item" title="Followers lost">📉 ${counts.follower_lost}</span>` +
      `<span class="ft-sum-item" title="Started following">➕ ${counts.followed}</span>` +
      `<span class="ft-sum-item" title="Stopped following">➖ ${counts.unfollowed}</span>` +
      `<span class="ft-sum-item" title="Name changes">✏️ ${counts.name_changed}</span>`;
  }

  const labels = {
    follower_gained: '📈 Follower +',
    follower_lost:   '📉 Follower −',
    followed:        '➕ Following',
    unfollowed:      '➖ Unfollowed',
    name_changed:    '✏️ Renamed',
  };

  const MAX = 200;
  const recent = [...filtered].reverse().slice(0, MAX);

  if (recent.length === 0) {
    list.innerHTML = '<li class="ft-history-empty">No events match this filter.</li>';
    return;
  }

  list.innerHTML = recent.map(e => {
    const dateStr  = e.date || '';
    const label    = labels[e.type] || e.type;
    const id       = e.id || e.athleteId || '';
    const name     = e.name || e.athleteName || id;
    const nameHtml = id
      ? `<a href="https://www.strava.com/athletes/${id}" target="_blank" rel="noopener" class="ft-history-athlete">${name}</a>`
      : `<span class="ft-history-athlete">${name}</span>`;
    let detail;
    if (e.type === 'name_changed' && e.oldName) {
      const oldLink = id
        ? `<a href="https://www.strava.com/athletes/${id}" target="_blank" rel="noopener" class="ft-history-athlete">${e.oldName}</a>`
        : `<span class="ft-history-athlete">${e.oldName}</span>`;
      detail = `: ${oldLink} → ${nameHtml}`;
    } else {
      detail = name ? `: ${nameHtml}` : '';
    }
    return `<li class="ft-history-item"><span class="ft-history-date">${dateStr}</span> ${label}${detail}</li>`;
  }).join('');

  if (filtered.length > MAX) {
    list.innerHTML += `<li class="ft-history-more">… and ${filtered.length - MAX} older events. Export CSV to see all.</li>`;
  }
}

async function ftSidebarScanNow() {
  const btn = document.getElementById('ft-sidebar-scan-btn');
  if (btn) { btn.disabled = true; btn.textContent = '\u23F3 Scanning\u2026'; }
  ftSidebarHideError();

  // Capture live counts now so we can sanity-check the result later
  const liveCounts = ftReadLiveCounts();

  const pollInterval = setInterval(async () => {
    try {
      const r  = await browser.storage.local.get(['ftScanStatus']);
      const st = r.ftScanStatus;
      if (!st || st.status === 'idle') { clearInterval(pollInterval); return; }
      ftSidebarShowProgress(st);
      if (st.status === 'complete' || st.status === 'error') {
        clearInterval(pollInterval);
        ftSidebarHideProgress();
        if (btn) { btn.disabled = false; btn.textContent = '\uD83D\uDD0D Scan Now'; }
        if (st.status === 'error') {
          ftSidebarShowError(st.error || 'Scan failed');
        } else {
          // Sanity check — only validate lists that were actually freshly scanned
          const fc = st.followerCount || 0;
          const fg = st.followingCount || 0;
          const expF = liveCounts.followers;
          const expG = liveCounts.following;
          const listsScanned = st.listsScanned || 'both';
          const checkFollowers = (listsScanned === 'both' || listsScanned === 'followers');
          const checkFollowing = (listsScanned === 'both' || listsScanned === 'following');
          if ((checkFollowers && expF != null && fc !== expF) || (checkFollowing && expG != null && fg !== expG)) {
            ftSidebarShowError(`Scan found ${fc} followers / ${fg} following but your profile shows ${expF ?? '?'} / ${expG ?? '?'}. Please try again.`);
            return;
          }
          await ftInitSidebarTab();
          ftHideRescanBanner();
        }
      }
    } catch (_) { clearInterval(pollInterval); }
  }, 200);

  try {
    await browser.runtime.sendMessage({ action: 'ftStartScan', listsToScan: 'both' });
  } catch (err) {
    clearInterval(pollInterval);
    ftSidebarHideProgress();
    if (btn) { btn.disabled = false; btn.textContent = '\uD83D\uDD0D Scan Now'; }
    ftSidebarShowError('Could not start scan: ' + err.message);
  }
}

// Determine which follow lists to scan based on what changed and whether the
// full-scan interval has elapsed. Returns { listsToScan, isForced }.
async function ftDetermineListsToScan() {
  const result = await browser.storage.local.get(['ftLastFullScanAt', 'ftFullScanIntervalDays']);
  const intervalDays = Number(result.ftFullScanIntervalDays) > 0
    ? Number(result.ftFullScanIntervalDays)
    : 14;
  const lastFullScanAt = result.ftLastFullScanAt || 0;
  // Require a recorded scan before treating elapsed time as a forced-full-scan trigger;
  // a missing ftLastFullScanAt means this device has never completed a full scan, which is
  // different from the interval having expired after a known scan.
  const intervalElapsed = lastFullScanAt > 0 && (Date.now() - lastFullScanAt) > (intervalDays * 86400000);

  if (intervalElapsed) {
    return { listsToScan: 'both', isForced: true };
  }

  const { followers: followersChanged, following: followingChanged } = ftChangedLists;
  if (followersChanged && followingChanged) return { listsToScan: 'both',      isForced: false };
  if (followersChanged)                    return { listsToScan: 'followers',  isForced: false };
  if (followingChanged)                    return { listsToScan: 'following',  isForced: false };
  // Neither changed — manual trigger, scan both
  return { listsToScan: 'both', isForced: false };
}

// Simple CSV field escaper for sidebar exports
function ftSidebarCsvEscape(value) {
  if (value === null || value === undefined) return '';
  let str = String(value);
  // Normalize line endings
  str = str.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  if (!/[",\n]/.test(str) && str.indexOf(',') === -1) {
    return str;
  }
  return '"' + str.replace(/"/g, '""') + '"';
}

async function ftSidebarExportCSV() {
  try {
    const result = await browser.storage.local.get(['followTracker']);
    const data   = result.followTracker || {};
    const events = data.events || [];
    if (events.length === 0) { ftSidebarShowError('No events to export.'); return; }
    ftSidebarHideError();

    const header = 'date,type,id,name,oldName\n';
    const rows = events.map(e => {
      const date = e.date || (e.timestamp ? new Date(e.timestamp * 1000).toISOString() : '');
      const type = e.type || '';
      const id   = e.id || e.athleteId || '';
      const name = e.name || e.athleteName || '';
      const oldName = e.oldName || '';
      return [
        ftSidebarCsvEscape(date),
        ftSidebarCsvEscape(type),
        ftSidebarCsvEscape(id),
        ftSidebarCsvEscape(name),
        ftSidebarCsvEscape(oldName)
      ].join(',');
    });
    const csv  = header + rows.join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = 'follow-tracker-events.csv';
    a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    ftSidebarShowError('Export failed: ' + err.message);
  }
}

function ftSidebarShowProgress(st) {
  const wrap = document.getElementById('ft-sidebar-progress');
  const fill = document.getElementById('ft-sidebar-progress-fill');
  const msg  = document.getElementById('ft-sidebar-progress-msg');
  const step = document.getElementById('ft-sidebar-progress-step');
  const pct  = document.getElementById('ft-sidebar-progress-pct');
  if (!wrap) return;
  wrap.style.display = '';

  // Drive bar from step/totalSteps — what the scanner actually emits
  if (fill && st.step && st.totalSteps) {
    const pctVal = Math.round((st.step / st.totalSteps) * 100);
    fill.style.width = pctVal + '%';
    if (pct) pct.textContent = pctVal + '%';
  }
  if (step && st.step && st.totalSteps) {
    step.textContent = `Step ${st.step} of ${st.totalSteps}`;
  }
  if (msg) msg.textContent = st.message || 'Scanning…';
}

function ftSidebarHideProgress() {
  const wrap = document.getElementById('ft-sidebar-progress');
  if (wrap) wrap.style.display = 'none';
}

function ftSidebarShowError(msg) {
  const el = document.getElementById('ft-sidebar-error');
  if (el) { el.textContent = msg; el.style.display = ''; }
}

function ftSidebarHideError() {
  const el = document.getElementById('ft-sidebar-error');
  if (el) { el.style.display = 'none'; el.textContent = ''; }
}

function ftSidebarLoadSettings(s, extraKeys) {
  const maxEl = document.getElementById('ft-setting-max-pages');
  if (maxEl) maxEl.value = s.maxPages || '';
  ftSidebarUpdateDerived();

  const intervalEl = document.getElementById('ft-setting-full-scan-interval');
  if (intervalEl) intervalEl.value = extraKeys?.ftFullScanIntervalDays || '';

  ftSidebarUpdateLastFullScan(extraKeys?.ftLastFullScanAt || 0);
}

function ftSidebarUpdateLastFullScan(tsMs) {
  const el = document.getElementById('ft-setting-last-full-scan');
  if (!el) return;
  if (!tsMs) {
    el.textContent = 'No full scan on record for this device.';
    return;
  }
  const d = new Date(tsMs);
  el.textContent = `Last full scan: ${d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}`;
}

function ftSidebarUpdateDerived() {
  const maxEl   = document.getElementById('ft-setting-max-pages');
  const derived = document.getElementById('ft-setting-derived');
  if (!maxEl || !derived) return;
  const pages = parseInt(maxEl.value, 10);
  // Strava returns ~25 per page — show the effective athlete ceiling
  const perPage = 25;
  if (pages > 0) {
    derived.textContent = `≈ ${(pages * perPage).toLocaleString()} athletes max`;
  } else {
    derived.textContent = `Default: 400 pages ≈ 10,000 athletes`;
  }
}

async function ftSidebarSaveSettings() {
  const maxEl      = document.getElementById('ft-setting-max-pages');
  const intervalEl = document.getElementById('ft-setting-full-scan-interval');
  const msgEl      = document.getElementById('ft-sidebar-settings-msg');
  if (!maxEl) return;

  const maxPages = parseInt(maxEl.value, 10);
  if (maxEl.value !== '' && (isNaN(maxPages) || maxPages < 1)) {
    if (msgEl) { msgEl.textContent = 'Max pages must be a positive number.'; msgEl.style.display = ''; }
    return;
  }

  const intervalDays = intervalEl ? parseInt(intervalEl.value, 10) : NaN;
  if (intervalEl && intervalEl.value !== '' && (isNaN(intervalDays) || intervalDays < 1)) {
    if (msgEl) { msgEl.textContent = 'Full scan interval must be a positive number of days.'; msgEl.style.display = ''; }
    return;
  }

  const settings = {};
  if (maxEl.value !== '') settings.maxPages = maxPages;
  // Clear the key if inputs are blank (revert to defaults)
  if (Object.keys(settings).length === 0) {
    await browser.storage.local.remove('ftScanSettings');
  } else {
    await browser.storage.local.set({ ftScanSettings: settings });
  }

  // Save full-scan interval as its own top-level key
  if (intervalEl) {
    if (intervalEl.value !== '' && !isNaN(intervalDays)) {
      await browser.storage.local.set({ ftFullScanIntervalDays: intervalDays });
    } else {
      await browser.storage.local.remove('ftFullScanIntervalDays');
    }
  }

  if (msgEl) {
    msgEl.textContent = 'Saved.';
    msgEl.style.display = '';
    setTimeout(() => { msgEl.style.display = 'none'; }, 2000);
  }
  ftSidebarUpdateDerived();
}

async function kudosSidebarLoadSettings() {
  const result = await browser.storage.local.get(['bulkKudosIncludeRodWith']);
  const checkbox = document.getElementById('kudos-setting-include-rod-with');
  if (checkbox) {
    checkbox.checked = result.bulkKudosIncludeRodWith !== false;
  }
}

async function kudosSidebarSaveSettings() {
  const checkbox = document.getElementById('kudos-setting-include-rod-with');
  const msgEl    = document.getElementById('kudos-sidebar-settings-msg');
  if (!checkbox) return;

  await browser.storage.local.set({ bulkKudosIncludeRodWith: checkbox.checked });

  if (msgEl) {
    msgEl.textContent = 'Saved.';
    msgEl.style.display = '';
    setTimeout(() => { msgEl.style.display = 'none'; }, 2000);
  }
}

function ftDangerInputChanged() {
  const input = document.getElementById('ft-danger-input');
  const btn   = document.getElementById('ft-danger-clear-btn');
  if (!input || !btn) return;
  btn.disabled = (input.value.trim() !== 'RESET');
}

async function ftDangerClearAll() {
  const input  = document.getElementById('ft-danger-input');
  const btn    = document.getElementById('ft-danger-clear-btn');
  const msgEl  = document.getElementById('ft-danger-msg');
  if (!input || input.value.trim() !== 'RESET') return;

  try {
    await browser.storage.local.remove(['followTracker', 'ftScanStatus']);
    // Reset confirmation UI
    input.value = '';
    if (btn) btn.disabled = true;
    if (msgEl) {
      msgEl.textContent = 'All data cleared.';
      msgEl.style.display = '';
      setTimeout(() => { msgEl.style.display = 'none'; }, 3000);
    }
    // Re-render sidebar with empty state
    await ftInitSidebarTab();
  } catch (err) {
    if (msgEl) {
      msgEl.textContent = 'Error clearing data: ' + err.message;
      msgEl.style.display = '';
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Follow Tracker — live count monitoring & rescan banner
// ─────────────────────────────────────────────────────────────────────────────

// Read the live follower/following counts currently shown in the Strava DOM.
// Selects the [data-testid] stat containers and extracts the first integer
// from their text content, avoiding dependence on obfuscated class names.
function ftReadLiveCounts() {
  function extractCount(el) {
    if (!el) return null;
    const m = el.textContent.replace(/,/g, '').match(/\d+/);
    return m ? parseInt(m[0], 10) : null;
  }
  return {
    following: extractCount(document.querySelector('[data-testid="following-stat"]')),
    followers: extractCount(document.querySelector('[data-testid="followers-stat"]')),
  };
}

// Compare live DOM counts against the last stored scan and show/hide the banner
async function ftCheckCountDiscrepancy() {
  if (ftRescanBannerDismissedThisSession) return;

  const live = ftReadLiveCounts();
  if (live.followers === null && live.following === null) return; // Stats not in DOM

  try {
    const result = await browser.storage.local.get(['followTracker']);
    const data = result.followTracker;

    if (!data || !data.latestSnapshot) {
      ftShowRescanBanner(live.followers, live.following, null, null);
      return;
    }

    const snap = data.latestSnapshot;
    const storedFollowers = Object.keys(snap.followers || {}).length;
    const storedFollowing = Object.keys(snap.following || {}).length;

    const followersChanged = live.followers !== null && live.followers !== storedFollowers;
    const followingChanged = live.following !== null && live.following !== storedFollowing;

    if (followersChanged || followingChanged) {
      ftChangedLists = { followers: followersChanged, following: followingChanged };
      ftShowRescanBanner(live.followers, live.following, storedFollowers, storedFollowing);
    } else {
      ftHideRescanBanner();
    }
  } catch (_) {
    // Non-fatal — storage may not be ready
  }
}

// Create/update the rescan suggestion banner
function ftShowRescanBanner(liveFollowers, liveFollowing, storedFollowers, storedFollowing) {
  if (ftRescanBannerDismissedThisSession) return;

  let banner = document.getElementById('ft-rescan-banner');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'ft-rescan-banner';
    banner.className = 'ft-rescan-banner';
    banner.innerHTML = `
      <div class="ft-rescan-banner-content">
        <div class="ft-rescan-banner-msg" role="status" aria-live="polite" aria-atomic="true">
          <strong class="ft-rescan-banner-title"></strong>
          <span class="ft-rescan-banner-detail"></span>
        </div>
        <button class="ft-rescan-banner-scan-btn">&#x1F50D; Scan Now</button>
        <button class="ft-rescan-banner-dismiss-btn" aria-label="Dismiss">&times;</button>
      </div>
    `;
    document.body.appendChild(banner);

    banner.querySelector('.ft-rescan-banner-scan-btn').addEventListener('click', () => {
      ftBannerStartScan(banner);
    });
    banner.querySelector('.ft-rescan-banner-dismiss-btn').addEventListener('click', () => {
      ftDismissRescanBanner();
    });
  }

  // Apply a stronger visual treatment when there is no scan data at all
  if (storedFollowers === null && storedFollowing === null) {
    banner.classList.add('ft-rescan-banner--first-scan');
  } else {
    banner.classList.remove('ft-rescan-banner--first-scan');
  }

  let title, detail;
  if (storedFollowers === null && storedFollowing === null) {
    title = 'No previous follower scan detected.';
    detail = 'Run a scan to start tracking your follower/following changes.';
  } else {
    const parts = [];
    if (liveFollowers !== null) parts.push(`followers: ${storedFollowers} \u2192 ${liveFollowers}`);
    if (liveFollowing !== null) parts.push(`following: ${storedFollowing} \u2192 ${liveFollowing}`);
    title = 'Follower/following counts have changed since your last scan.';
    detail = parts.join(' \u00B7 ');
  }

  banner.querySelector('.ft-rescan-banner-title').textContent = title;
  banner.querySelector('.ft-rescan-banner-detail').textContent = detail;

  const scanBtn = banner.querySelector('.ft-rescan-banner-scan-btn');
  if (scanBtn && !scanBtn.dataset.scanning) scanBtn.textContent = '\uD83D\uDD0D Scan Now';

  banner.style.display = '';
}

function ftHideRescanBanner() {
  const banner = document.getElementById('ft-rescan-banner');
  if (banner) banner.style.display = 'none';
}

function ftDismissRescanBanner() {
  ftRescanBannerDismissedThisSession = true;
  ftHideRescanBanner();
}

// Run a scan directly from the rescan banner, showing inline progress
async function ftBannerStartScan(banner) {
  const scanBtn  = banner.querySelector('.ft-rescan-banner-scan-btn');
  const detailEl = banner.querySelector('.ft-rescan-banner-detail');

  if (scanBtn) { scanBtn.disabled = true; scanBtn.dataset.scanning = '1'; scanBtn.textContent = '\u23F3 Scanning\u2026'; }
  const setDetail = (msg) => { if (detailEl) detailEl.textContent = msg; };

  // Determine which lists to scan (partial vs full)
  const { listsToScan, isForced } = await ftDetermineListsToScan();
  if (isForced) {
    setDetail('Running full scan (full-scan interval elapsed)…');
  } else if (listsToScan === 'followers') {
    setDetail('Running partial scan: followers list only…');
  } else if (listsToScan === 'following') {
    setDetail('Running partial scan: following list only…');
  } else {
    setDetail('Running full scan…');
  }

  // Capture live counts now so we can sanity-check the result later
  const liveCounts = ftReadLiveCounts();

  // Guard: don't stop polling on 'idle' until we've seen at least one non-idle
  // status — background.js may not have written its first 'scanning' update yet
  // when the first poll fires.
  let seenScanning = false;
  const pollInterval = setInterval(async () => {
    try {
      const r  = await browser.storage.local.get(['ftScanStatus']);
      const st = r.ftScanStatus;
      if (!st || st.status === 'idle') {
        if (seenScanning) clearInterval(pollInterval);
        return;
      }
      seenScanning = true;
      if (st.message) setDetail(st.message);
      if (st.status === 'complete' || st.status === 'error') {
        clearInterval(pollInterval);
        if (scanBtn) { scanBtn.disabled = false; delete scanBtn.dataset.scanning; }
        if (st.status === 'error') {
          if (scanBtn) scanBtn.textContent = '\uD83D\uDD0D Scan Now';
          setDetail('\u26A0\uFE0F ' + (st.error || 'Scan failed. Try again.'));
        } else {
          // Sanity check — only validate lists that were freshly scanned
          const fc = st.followerCount || 0;
          const fg = st.followingCount || 0;
          const expF  = liveCounts.followers;
          const expG  = liveCounts.following;
          const scanned = st.listsScanned || 'both';
          const checkFollowers = (scanned === 'both' || scanned === 'followers');
          const checkFollowing = (scanned === 'both' || scanned === 'following');
          if ((checkFollowers && expF != null && fc !== expF) || (checkFollowing && expG != null && fg !== expG)) {
            if (scanBtn) scanBtn.textContent = '\uD83D\uDD0D Scan Now';
            setDetail(`\u26A0\uFE0F Scan found ${fc} followers / ${fg} following but your profile shows ${expF ?? '?'} / ${expG ?? '?'}. Please try again.`);
            return;
          }
          ftRescanBannerDismissedThisSession = true;
          if (scanBtn) scanBtn.textContent = '\u2713 Done';
          setDetail(`Scan complete \u2014 ${fc} followers, ${fg} following.`);
          setTimeout(() => ftHideRescanBanner(), 2500);
          const trackerContent = document.querySelector('[data-tab-content="tracker"]');
          if (trackerContent && trackerContent.classList.contains('active')) await ftInitSidebarTab();
        }
      }
    } catch (_) { clearInterval(pollInterval); }
  }, 300);

  try {
    await browser.runtime.sendMessage({ action: 'ftStartScan', listsToScan });
  } catch (err) {
    clearInterval(pollInterval);
    if (scanBtn) { scanBtn.disabled = false; delete scanBtn.dataset.scanning; scanBtn.textContent = '\uD83D\uDD0D Scan Now'; }
    setDetail('\u26A0\uFE0F Could not start scan: ' + err.message);
  }
}

// Watch for SPA navigation and re-check counts after Strava re-renders
function ftObserveStatsForSpaNav() {
  let navTimer = null;
  const scheduleCheck = () => {
    clearTimeout(navTimer);
    navTimer = setTimeout(() => ftCheckCountDiscrepancy(), 1500);
  };

  window.addEventListener('popstate', scheduleCheck);

  try {
    const origPushState = history.pushState.bind(history);
    history.pushState = function (...args) {
      origPushState(...args);
      scheduleCheck();
    };
  } catch (_) {
    // pushState may not be patchable in all environments
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Segment leaderboard — membership indicators + "My Athlete Lists" filter panel
// ─────────────────────────────────────────────────────────────────────────────

// Callback set by addSegmentLeaderboardHandlers so the storage-change listener
// can re-apply the row filter when groups are renamed/deleted.
let segmentRowFilterCallback = null;

function addSegmentLeaderboardHandlers() {
  log('[seg] addSegmentLeaderboardHandlers called, path:', window.location.pathname);
  if (!window.location.pathname.match(/^\/segments\/\d+/)) {
    log('[seg] ⛔ path does not match /segments/\\d+ — exiting');
    return;
  }

  log('[seg] 🏁 Segment leaderboard page detected');

  // Track which list names are currently checked
  const checkedLists = new Set();

  // ── Helpers ──────────────────────────────────────────────────────────────

  function rowAthleteId(tr) {
    const td = tr.querySelector('td.athlete[data-tracking-properties]');
    if (!td) return null;
    try {
      return String(JSON.parse(td.dataset.trackingProperties).athlete_id);
    } catch (_) {
      return null;
    }
  }

  // Expose so the storage-change listener can re-apply the filter after group renames/deletions
  segmentRowFilterCallback = applyRowFilter;

  function applyRowFilter() {
    const tbody = document.querySelector('#results table.table-leaderboard tbody');
    log('[seg] applyRowFilter — tbody found:', !!tbody, '| checkedLists:', [...checkedLists]);
    if (!tbody) return;
    let shown = 0, hidden = 0;
    tbody.querySelectorAll('tr').forEach(tr => {
      if (checkedLists.size === 0) { tr.style.display = ''; shown++; return; }
      const id = rowAthleteId(tr);
      const memberships = id ? (athleteMembershipsCache.get(id) || []) : [];
      const visible = memberships.some(name => checkedLists.has(name));
      tr.style.display = visible ? '' : 'none';
      visible ? shown++ : hidden++;
    });
    log(`[seg] applyRowFilter done — shown:${shown} hidden:${hidden}`);
  }

  function applyIndicatorsToRows() {
    const tds = document.querySelectorAll('#results td.athlete[data-tracking-properties]');
    log('[seg] applyIndicatorsToRows — td.athlete count:', tds.length);
    let injected = 0, skipped = 0;
    tds.forEach(td => {
      if (td.hasAttribute('data-strava-groups-processed')) { skipped++; return; }
      td.setAttribute('data-strava-groups-processed', 'true');

      let athleteId;
      try {
        athleteId = String(JSON.parse(td.dataset.trackingProperties).athlete_id);
      } catch (e) {
        log('[seg] ⚠️ failed to parse tracking-properties:', td.dataset.trackingProperties, e);
        return;
      }

      const link = td.querySelector('a[href*="/athletes/"]');
      if (!link) {
        log('[seg] ⚠️ no athlete link found in td for id', athleteId);
        return;
      }

      const athleteName = link.textContent.trim();
      if (!link.getAttribute('data-athlete-name')) {
        link.setAttribute('data-athlete-name', athleteName);
      }

      const indicator = document.createElement('span');
      indicator.className = 'strava-groups-indicator';
      indicator.textContent = '+';
      indicator.setAttribute('role', 'button');
      indicator.setAttribute('tabindex', '0');
      indicator.dataset.stravaGroupsIndicatorFor = athleteId;
      indicator.dataset.feedbackTimeout = '';

      indicator.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const storedName = link.getAttribute('data-athlete-name');
        await selectAthlete({ id: athleteId, name: storedName });
        const existingTimeout = indicator.dataset.feedbackTimeout;
        if (existingTimeout) clearTimeout(Number(existingTimeout));
        indicator.textContent = '✓';
        const timeout = setTimeout(() => {
          applyIndicatorMembershipState(indicator, link, athleteId, storedName);
          delete indicator.dataset.feedbackTimeout;
        }, 1000);
        indicator.dataset.feedbackTimeout = String(timeout);
      });

      indicator.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); indicator.click(); }
      });

      link.appendChild(indicator);
      applyIndicatorMembershipState(indicator, link, athleteId, athleteName);
      injected++;
      log(`[seg] injected indicator for ${athleteName} (${athleteId})`);
    });
    log(`[seg] applyIndicatorsToRows done — injected:${injected} skipped:${skipped}`);
  }

  // ── Filter panel UI ───────────────────────────────────────────────────────

  const PANEL_ID = 'strava-af-segment-filter';

  function buildFilterPanel() {
    log('[seg] buildFilterPanel called');
    if (document.getElementById(PANEL_ID)) {
      log('[seg] filter panel already exists — skipping');
      return;
    }

    const filterCol = document.querySelector('.col-lg-2 ul.filters, .col-md-3 ul.filters');
    log('[seg] filterCol found:', !!filterCol, filterCol);
    if (!filterCol) {
      log('[seg] ⚠️ could not find .col-lg-2 ul.filters or .col-md-3 ul.filters');
      return;
    }

    browser.storage.local.get(['groups']).then(data => {
      const groups = data.groups || {};
      const groupNames = Object.values(groups)
        .map(g => g.name)
        .filter(Boolean)
        .sort((a, b) => a.localeCompare(b));

      // Prune stale selections (e.g. after a group rename or deletion)
      const validGroupNames = new Set(groupNames);
      [...checkedLists].forEach(name => { if (!validGroupNames.has(name)) checkedLists.delete(name); });

      log('[seg] groups in storage:', Object.keys(groups).length, '| names:', groupNames);

      if (groupNames.length === 0) {
        log('[seg] no groups — filter panel not shown');
        return;
      }

      const ul = document.createElement('ul');
      ul.className = 'filters list-unstyled'; // 'filters' lets Strava's own .filters .filter-link CSS apply
      ul.id = PANEL_ID;

      // Use Strava's own filter-header class for the section heading
      const header = document.createElement('li');
      header.className = 'filter-header';
      header.textContent = 'My Athlete Lists';
      ul.appendChild(header);

      // Use Strava's own filter-link + selected classes — their CSS handles all styling
      groupNames.forEach(name => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        // Re-apply selected state if this list was active before the panel was rebuilt
        a.className = checkedLists.has(name) ? 'selected filter-link' : 'filter-link';
        a.href = '#';
        a.textContent = name;
        a.addEventListener('click', (e) => {
          e.preventDefault();
          if (checkedLists.has(name)) {
            checkedLists.delete(name);
            a.className = 'filter-link';
          } else {
            checkedLists.add(name);
            a.className = 'selected filter-link';
          }
          showAllLi.style.display = checkedLists.size > 0 ? '' : 'none';
          log('[seg] filter link toggled — checkedLists:', [...checkedLists]);
          applyRowFilter();
        });
        li.appendChild(a);
        ul.appendChild(li);
      });

      // "Show all" resets all selections — styled as a plain filter-link
      const showAllLi = document.createElement('li');
      showAllLi.style.display = checkedLists.size > 0 ? '' : 'none';
      const showAllA = document.createElement('a');
      showAllA.className = 'filter-link strava-af-filter-showall-btn';
      showAllA.href = '#';
      showAllA.textContent = 'Show all';
      showAllA.addEventListener('click', (e) => {
        e.preventDefault();
        checkedLists.clear();
        ul.querySelectorAll('a.filter-link.selected').forEach(a => a.classList.remove('selected'));
        showAllLi.style.display = 'none';
        applyRowFilter();
      });
      showAllLi.appendChild(showAllA);
      ul.appendChild(showAllLi);

      filterCol.parentElement.appendChild(ul);
      log('[seg] ✅ filter panel injected with', groupNames.length, 'lists');
    });
  }

  // ── Watch for Strava AJAX leaderboard replacements ───────────────────────
  // Observe the widest stable container so we catch both #results (right col)
  // and the filter column (left col) being replaced on filter changes.

  const resultsRoot = document.getElementById('results')?.closest('.container') ||
                      document.getElementById('results')?.parentElement?.parentElement ||
                      document.body;
  log('[seg] observer root:', resultsRoot.tagName, resultsRoot.id || resultsRoot.className);
  new MutationObserver(debounce((mutations) => {
    const nonSpanNodes = mutations.flatMap(m =>
      Array.from(m.addedNodes).filter(n =>
        n.nodeType === Node.ELEMENT_NODE && n.tagName !== 'SPAN'
      )
    );
    log('[seg] observer fired — total mutations:', mutations.length,
        '| non-span added nodes:', nonSpanNodes.length,
        nonSpanNodes.map(n => n.tagName + (n.id ? '#'+n.id : '') + (n.className ? '.'+String(n.className).split(' ')[0] : '')));
    if (nonSpanNodes.length === 0) return;
    buildFilterPanel();
    applyIndicatorsToRows();
    applyRowFilter();
  }, 300)).observe(resultsRoot, { childList: true, subtree: true });

  // Initial run
  setTimeout(() => {
    log('[seg] initial run (600ms timeout)');
    buildFilterPanel();
    applyIndicatorsToRows();
  }, 600);
}

// ─────────────────────────────────────────────────────────────────────────────

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
  cleanupAllListeners();
  log('[feed-groups] Cleaned up all event listeners');
});

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
