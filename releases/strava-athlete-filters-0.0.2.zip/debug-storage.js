// Storage debugging utility
// Run this in the browser console to check storage state

(async function debugStorage() {
  console.log('=== Storage Debug Utility ===');
  
  // Check if browser API is available
  if (typeof browser === 'undefined') {
    console.error('❌ browser API not available');
    if (typeof chrome !== 'undefined') {
      console.log('📌 Using Chrome - creating browser alias...');
      window.browser = chrome;
    } else {
      console.error('❌ No browser API available at all!');
      return;
    }
  }
  
  try {
    // Get all storage data
    const allData = await browser.storage.local.get(null);
    console.log('📦 All storage data:', allData);
    
    // Check groups specifically
    const groups = allData.groups || {};
    const groupCount = Object.keys(groups).length;
    console.log(`👥 Groups found: ${groupCount}`);
    
    if (groupCount > 0) {
      console.log('📋 Group details:');
      for (const [groupName, group] of Object.entries(groups)) {
        const athleteCount = group.athletes?.length || 0;
        console.log(`  - "${groupName}": ${athleteCount} athletes`);
        console.log(`    Athletes:`, group.athletes || []);
      }
    } else {
      console.log('⚠️ No groups found in storage!');
    }
    
    // Check extension ID
    if (browser.runtime && browser.runtime.id) {
      console.log(`🆔 Extension ID: ${browser.runtime.id}`);
    }
    
    // Storage size estimate
    const dataStr = JSON.stringify(allData);
    const sizeKB = (dataStr.length / 1024).toFixed(2);
    console.log(`💾 Storage size: ~${sizeKB} KB`);
    
  } catch (error) {
    console.error('❌ Error accessing storage:', error);
  }
  
  console.log('=== End Debug ===');
})();
