// Popup script for managing groups and athletes

// Debug mode (set to true for development)
const DEBUG = false;
const log = DEBUG ? console.log.bind(console) : () => {};
const warn = DEBUG ? console.warn.bind(console) : () => {};
const error = console.error.bind(console);

// Utility: Alphabetical sort comparator
function alphabeticalSort(a, b) {
  return a.localeCompare(b);
}

// Utility: Sort athletes by name
function sortAthletesByName(athletes) {
  return [...athletes].sort((a, b) => alphabeticalSort(a.name, b.name));
}

let selectedAthlete = null;

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  await loadGroups();
  await loadSelectedAthlete();
  setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
  document.getElementById('createGroup').addEventListener('click', createGroup);
  document.getElementById('addToGroup').addEventListener('click', addAthleteToGroup);
  document.getElementById('applyFilter').addEventListener('click', applyFilter);
  document.getElementById('clearFilter').addEventListener('click', clearFilter);
  document.getElementById('refreshPage').addEventListener('click', refreshPage);
}

// Load groups from storage
async function loadGroups() {
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  displayGroups(groups);
  updateGroupSelects(groups);
}

// Display groups in the UI
function displayGroups(groups) {
  const groupsList = document.getElementById('groupsList');
  
  if (Object.keys(groups).length === 0) {
    groupsList.innerHTML = '<div class="empty-state">No groups created yet</div>';
    return;
  }
  
  groupsList.innerHTML = '';
  
  // Sort groups alphabetically by name
  const sortedGroups = Object.entries(groups).sort((a, b) => 
    alphabeticalSort(a[1].name, b[1].name)
  );
  
  for (const [groupId, group] of sortedGroups) {
    const groupDiv = document.createElement('div');
    groupDiv.className = 'group-item';
    
    const athleteCount = group.athletes ? group.athletes.length : 0;
    
    // Create elements safely using DOM methods
    const nameSpan = document.createElement('span');
    nameSpan.className = 'group-name';
    nameSpan.textContent = group.name;
    nameSpan.addEventListener('click', () => toggleGroupAthletes(groupDiv, group));
    
    const countSpan = document.createElement('span');
    countSpan.className = 'group-count';
    countSpan.textContent = `${athleteCount} athlete${athleteCount !== 1 ? 's' : ''}`;
    
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-group';
    deleteButton.textContent = 'Delete';
    deleteButton.setAttribute('data-group-id', groupId);
    deleteButton.setAttribute('aria-label', `Delete ${group.name} group`);
    deleteButton.addEventListener('click', () => deleteGroup(groupId, group.name));
    
    groupDiv.appendChild(nameSpan);
    groupDiv.appendChild(countSpan);
    groupDiv.appendChild(deleteButton);
    
    groupsList.appendChild(groupDiv);
  }
}

// Toggle display of athletes in a group
function toggleGroupAthletes(groupDiv, group) {
  let athletesDiv = groupDiv.querySelector('.athletes-list');
  
  if (athletesDiv) {
    athletesDiv.remove();
    return;
  }
  
  if (!group.athletes || group.athletes.length === 0) {
    return;
  }
  
  athletesDiv = document.createElement('div');
  athletesDiv.className = 'athletes-list';
  
  // Sort athletes alphabetically by name
  const sortedAthletes = sortAthletesByName(group.athletes);
  
  for (const athlete of sortedAthletes) {
    const athleteDiv = document.createElement('div');
    athleteDiv.className = 'athlete-item';
    
    const nameSpan = document.createElement('span');
    nameSpan.textContent = athlete.name;
    
    const removeButton = document.createElement('button');
    removeButton.className = 'remove-athlete';
    removeButton.textContent = 'Remove';
    removeButton.setAttribute('data-athlete-id', String(athlete.id));
    removeButton.setAttribute('aria-label', `Remove ${athlete.name} from group`);
    removeButton.addEventListener('click', (e) => {
      e.stopPropagation();
      removeAthleteFromGroup(group.id, athlete.id);
    });
    
    athleteDiv.appendChild(nameSpan);
    athleteDiv.appendChild(removeButton);
    athletesDiv.appendChild(athleteDiv);
  }
  
  groupDiv.appendChild(athletesDiv);
}

// Update group select dropdowns
function updateGroupSelects(groups) {
  const groupSelect = document.getElementById('groupSelect');
  const filterGroup = document.getElementById('filterGroup');
  
  // Clear and rebuild
  groupSelect.innerHTML = '<option value="">Select a group...</option>';
  filterGroup.innerHTML = '<option value="">All Athletes</option>';
  
  // Sort groups alphabetically by name
  const sortedGroups = Object.entries(groups).sort((a, b) => 
    a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
  );
  
  for (const [groupId, group] of sortedGroups) {
    const option1 = document.createElement('option');
    option1.value = groupId;
    option1.textContent = group.name;
    groupSelect.appendChild(option1);
    
    const option2 = document.createElement('option');
    option2.value = groupId;
    option2.textContent = group.name;
    filterGroup.appendChild(option2);
  }
}

// Create a new group
async function createGroup() {
  const nameInput = document.getElementById('newGroupName');
  const name = nameInput.value.trim();
  
  if (!name) {
    showInlineMessage('Please enter a group name', 'error');
    return;
  }
  
  // Validate max length (reasonable limit for UI display)
  if (name.length > 50) {
    showInlineMessage('Group name must be 50 characters or less', 'error');
    return;
  }
  
  // Sanitize control characters from group name
  const sanitizedName = name.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  if (sanitizedName !== name) {
    showInlineMessage('Group name contains invalid characters', 'error');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  // Generate unique ID with random component to avoid collisions
  const groupId = 'group_' + Date.now() + '_' + Math.random().toString(36).slice(2, 11);
  
  groups[groupId] = {
    id: groupId,
    name: sanitizedName,
    athletes: []
  };
  
  await browser.storage.local.set({ groups });
  
  nameInput.value = '';
  await loadGroups();
  showInlineMessage(`Group "${sanitizedName}" created`, 'success');
}

// Delete a group
async function deleteGroup(groupId, groupName) {
  const confirmed = await showConfirmDialog(
    'Delete Group',
    `Are you sure you want to delete "${groupName}"?`
  );
  
  if (!confirmed) {
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  delete groups[groupId];
  
  await browser.storage.local.set({ groups });
  await loadGroups();
  showInlineMessage('Group deleted', 'success');
}

// Load selected athlete info
async function loadSelectedAthlete() {
  const result = await browser.storage.local.get(['selectedAthlete', 'groups']);
  selectedAthlete = result.selectedAthlete;
  const groups = result.groups || {};
  
  const infoDiv = document.getElementById('selectedAthleteInfo');
  const addToGroupSection = document.getElementById('addToGroupSection');
  
  if (selectedAthlete) {
    infoDiv.innerHTML = '';
    
    const athleteInfo = document.createElement('div');
    athleteInfo.className = 'athlete-info';
    
    const athleteName = document.createElement('div');
    athleteName.className = 'athlete-name';
    athleteName.textContent = selectedAthlete.name;
    
    const athleteId = document.createElement('div');
    athleteId.className = 'athlete-id';
    athleteId.textContent = `ID: ${selectedAthlete.id}`;
    
    athleteInfo.appendChild(athleteName);
    athleteInfo.appendChild(athleteId);
    
    // Find which groups this athlete belongs to
    const athleteGroups = [];
    console.log('[feed-groups] Checking athlete:', selectedAthlete.id, 'Type:', typeof selectedAthlete.id);
    console.log('[feed-groups] Available groups:', Object.keys(groups).length);
    
    for (const [groupId, group] of Object.entries(groups)) {
      console.log('[feed-groups] Checking group:', group.name, 'Athletes:', group.athletes);
      if (group.athletes && group.athletes.length > 0) {
        console.log('[feed-groups] First athlete in group - ID:', group.athletes[0].id, 'Type:', typeof group.athletes[0].id);
        const found = group.athletes.some(a => {
          const match = a.id === selectedAthlete.id || String(a.id) === String(selectedAthlete.id);
          if (match) {
            console.log('[feed-groups] Match found in group:', group.name);
          }
          return match;
        });
        if (found) {
          athleteGroups.push(group.name);
        }
      }
    }
    
    // Display groups list if athlete is in any groups
    if (athleteGroups.length > 0) {
      const groupsSection = document.createElement('div');
      groupsSection.className = 'athlete-groups-section';
      
      const groupsLabel = document.createElement('div');
      groupsLabel.className = 'athlete-groups-label';
      groupsLabel.textContent = `Member of ${athleteGroups.length} group${athleteGroups.length !== 1 ? 's' : ''}:`;
      
      const groupsList = document.createElement('div');
      groupsList.className = 'athlete-groups-list';
      
      // Sort groups alphabetically
      athleteGroups.sort(alphabeticalSort);
      
      for (const groupName of athleteGroups) {
        const groupTag = document.createElement('span');
        groupTag.className = 'group-tag';
        groupTag.textContent = groupName;
        groupsList.appendChild(groupTag);
      }
      
      groupsSection.appendChild(groupsLabel);
      groupsSection.appendChild(groupsList);
      athleteInfo.appendChild(groupsSection);
    }
    
    infoDiv.appendChild(athleteInfo);
    
    addToGroupSection.style.display = 'block';
  } else {
    infoDiv.innerHTML = '<p class="info-text">Click on an athlete in the Strava feed to add them to a group</p>';
    addToGroupSection.style.display = 'none';
  }
}

// Add athlete to selected group
async function addAthleteToGroup() {
  if (!selectedAthlete) {
    showInlineMessage('No athlete selected', 'error');
    return;
  }
  
  const groupSelect = document.getElementById('groupSelect');
  const groupId = groupSelect.value;
  
  if (!groupId) {
    showInlineMessage('Please select a group', 'error');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (!groups[groupId]) {
    showInlineMessage('Group not found', 'error');
    return;
  }
  
  // Check if athlete already in group
  if (groups[groupId].athletes.some(a => a.id === selectedAthlete.id)) {
    showInlineMessage('Athlete already in this group', 'error');
    return;
  }
  
  groups[groupId].athletes.push(selectedAthlete);
  
  await browser.storage.local.set({ groups });
  await loadGroups();
  await loadSelectedAthlete();
  
  showInlineMessage(`Added ${selectedAthlete.name} to ${groups[groupId].name}`, 'success');
}

// Remove athlete from group
async function removeAthleteFromGroup(groupId, athleteId) {
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (groups[groupId]) {
    groups[groupId].athletes = groups[groupId].athletes.filter(a => a.id !== athleteId);
    await browser.storage.local.set({ groups });
    await loadGroups();
    await loadSelectedAthlete();
    showInlineMessage('Athlete removed from group', 'success');
  }
}

// Apply filter to feed
async function applyFilter() {
  const filterGroup = document.getElementById('filterGroup');
  const groupId = filterGroup.value;
  
  console.log('[feed-groups] Applying filter for groupId:', groupId);
  
  // Send message to content script
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  
  if (tabs[0]) {
    console.log('[feed-groups] Sending message to tab:', tabs[0].id);
    try {
      await browser.tabs.sendMessage(tabs[0].id, {
        action: 'applyFilter',
        groupId: groupId
      });
      console.log('[feed-groups] Filter message sent successfully');
    } catch (error) {
      console.error('[feed-groups] Failed to apply filter:', error);
      showInlineMessage('Please make sure you are on the Strava dashboard page.', 'error');
    }
  } else {
    console.error('No active tab found');
    showInlineMessage('No active tab found', 'error');
  }
}

// Clear filter
async function clearFilter() {
  console.log('[feed-groups] Clearing filter');
  
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  
  if (tabs[0]) {
    console.log('[feed-groups] Sending clear filter message to tab:', tabs[0].id);
    try {
      await browser.tabs.sendMessage(tabs[0].id, {
        action: 'clearFilter'
      });
      console.log('[feed-groups] Clear filter message sent successfully');
    } catch (error) {
      console.error('[feed-groups] Failed to clear filter:', error);
      showInlineMessage('Please make sure you are on the Strava dashboard page.', 'error');
    }
  } else {
    console.error('No active tab found');
    showInlineMessage('No active tab found', 'error');
  }
}

// Show inline message
let inlineMessageTimeout = null;

function showInlineMessage(message, type = 'info') {
  // Clear any existing timeout
  if (inlineMessageTimeout) {
    clearTimeout(inlineMessageTimeout);
  }
  
  // Create or update a message element
  let messageDiv = document.getElementById('inlineMessage');
  if (!messageDiv) {
    messageDiv = document.createElement('div');
    messageDiv.id = 'inlineMessage';
    messageDiv.className = 'inline-message';
    document.querySelector('.container').insertBefore(messageDiv, document.querySelector('.section'));
  }
  
  messageDiv.className = `inline-message ${type}`;
  messageDiv.textContent = message;
  messageDiv.style.display = 'block';
  
  inlineMessageTimeout = setTimeout(() => {
    messageDiv.style.display = 'none';
    inlineMessageTimeout = null;
  }, 3000);
}

// Show confirm dialog
function showConfirmDialog(title, message) {
  return new Promise((resolve) => {
    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    
    // Create modal
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-labelledby', 'modal-title');
    
    // Create title
    const titleEl = document.createElement('h3');
    titleEl.id = 'modal-title';
    titleEl.className = 'modal-title';
    titleEl.textContent = title;
    
    // Create message
    const messageEl = document.createElement('p');
    messageEl.className = 'modal-message';
    messageEl.textContent = message;
    
    // Create buttons container
    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'modal-buttons';
    
    // Cleanup function to remove modal and event listener
    const cleanup = (result) => {
      document.removeEventListener('keydown', handleEscape);
      overlay.remove();
      resolve(result);
    };
    
    // Create cancel button
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'cancel-btn';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.addEventListener('click', () => cleanup(false));
    
    // Create confirm button
    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'confirm-btn';
    confirmBtn.textContent = 'Confirm';
    confirmBtn.addEventListener('click', () => cleanup(true));
    
    // Handle Escape key
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        cleanup(false);
      }
    };
    document.addEventListener('keydown', handleEscape);
    
    buttonsDiv.appendChild(cancelBtn);
    buttonsDiv.appendChild(confirmBtn);
    
    modal.appendChild(titleEl);
    modal.appendChild(messageEl);
    modal.appendChild(buttonsDiv);
    overlay.appendChild(modal);
    
    document.body.appendChild(overlay);
    
    // Focus confirm button
    confirmBtn.focus();
  });
}

// Refresh page
async function refreshPage() {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  
  if (tabs[0]) {
    await browser.tabs.reload(tabs[0].id);
  }
}

// Listen for storage changes
browser.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.groups) {
      loadGroups();
    }
    if (changes.selectedAthlete) {
      loadSelectedAthlete();
    }
  }
});
