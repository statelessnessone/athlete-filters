// Background script for the extension
// In Firefox this runs as background.scripts, in Chrome as service_worker
// Note: The source manifest.json uses scripts for Firefox development.
// At build time, build.sh generates browser-specific manifests:
// - Firefox: background.scripts
// - Chrome: background.service_worker

// Debug mode (set to true for development)
const DEBUG = false;
const log = DEBUG ? console.log.bind(console) : () => {};
const error = console.error.bind(console);

// For Chrome compatibility, check if browser is undefined and create alias
if (typeof browser === 'undefined' && typeof chrome !== 'undefined') {
  globalThis.browser = chrome;
}

log('[feed-groups] Background script loaded');

// Initialize extension on install
browser.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    log('[feed-groups] Extension installed');
    
    // Initialize storage keys if they don't exist
    const result = await browser.storage.local.get(['groups', 'selectedAthlete']);
    const updates = {};

    if (typeof result.groups === 'undefined') {
      updates.groups = {};
    }

    if (typeof result.selectedAthlete === 'undefined') {
      updates.selectedAthlete = null;
    }

    if (Object.keys(updates).length > 0) {
      await browser.storage.local.set(updates);
    }
  }
});