// Follow Tracker: Diff Engine
// Computes differences between two follow snapshots and returns typed event objects.
//
// Event types:
//   follower_gained  — someone started following you
//   follower_lost    — someone stopped following you
//   followed         — you started following someone
//   unfollowed       — you stopped following someone
//   name_changed     — an athlete you follow/are followed by changed their name

function ftComputeDiff(oldSnapshot, newSnapshot) {
  const events = [];
  if (!oldSnapshot) return events; // First scan — no diff available yet

  const date = new Date().toISOString().split('T')[0];

  const oldFollowers = oldSnapshot.followers || {};
  const newFollowers = newSnapshot.followers || {};
  const oldFollowing = oldSnapshot.following || {};
  const newFollowing = newSnapshot.following || {};

  // Followers gained
  for (const [id, name] of Object.entries(newFollowers)) {
    if (!(id in oldFollowers)) {
      events.push({ date, type: 'follower_gained', id, name });
    }
  }

  // Followers lost
  for (const [id, name] of Object.entries(oldFollowers)) {
    if (!(id in newFollowers)) {
      events.push({ date, type: 'follower_lost', id, name });
    }
  }

  // New following (you started following someone)
  for (const [id, name] of Object.entries(newFollowing)) {
    if (!(id in oldFollowing)) {
      events.push({ date, type: 'followed', id, name });
    }
  }

  // Unfollowed (you stopped following someone)
  for (const [id, name] of Object.entries(oldFollowing)) {
    if (!(id in newFollowing)) {
      events.push({ date, type: 'unfollowed', id, name });
    }
  }

  // Name changes — search both followers and following, deduplicate by id
  const nameChangedIds = new Set();

  for (const [id, newName] of Object.entries(newFollowers)) {
    if (id in oldFollowers && oldFollowers[id] !== newName) {
      events.push({ date, type: 'name_changed', id, name: newName, oldName: oldFollowers[id] });
      nameChangedIds.add(id);
    }
  }

  for (const [id, newName] of Object.entries(newFollowing)) {
    if (!nameChangedIds.has(id) && id in oldFollowing && oldFollowing[id] !== newName) {
      events.push({ date, type: 'name_changed', id, name: newName, oldName: oldFollowing[id] });
    }
  }

  return events;
}

// Derive mutual / followers-only / following-only sets from a snapshot
function ftGetRelationships(snapshot) {
  if (!snapshot) return { mutual: {}, followersOnly: {}, followingOnly: {} };

  const followers = snapshot.followers || {};
  const following = snapshot.following || {};
  const mutual = {};
  const followersOnly = {};
  const followingOnly = {};

  for (const [id, name] of Object.entries(followers)) {
    if (id in following) mutual[id] = name;
    else followersOnly[id] = name;
  }

  for (const [id, name] of Object.entries(following)) {
    if (!(id in followers)) followingOnly[id] = name;
  }

  return { mutual, followersOnly, followingOnly };
}

// Summarise a list of events into signed counts per type for display
function ftSummariseEvents(events) {
  const summary = {
    follower_gained: 0,
    follower_lost: 0,
    followed: 0,
    unfollowed: 0,
    name_changed: 0
  };
  for (const e of (events || [])) {
    if (e.type in summary) summary[e.type]++;
  }
  return summary;
}
