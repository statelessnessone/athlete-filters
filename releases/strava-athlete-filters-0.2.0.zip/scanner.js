// Follow Tracker: Scanner
// Provides scan settings, status helpers, and snapshot/diff utilities used by
// background.js. The active scan path is tab-based (background.js opens real
// browser tabs to collect SSR athlete lists via networkInterceptor.js).

// Default scan settings — overridable via browser.storage.local key 'ftScanSettings'.
const FT_DEFAULT_MAX_PAGES = 400; // 400 × 25 = 10 000 athletes safety cap
const FT_SETTINGS_KEY = 'ftScanSettings';

// Read scan settings from storage, falling back to defaults.
async function ftGetScanSettings() {
  const result = await browser.storage.local.get([FT_SETTINGS_KEY]);
  const s = result[FT_SETTINGS_KEY] || {};
  return {
    maxPages: (Number(s.maxPages) > 0 ? Number(s.maxPages) : FT_DEFAULT_MAX_PAGES),
  };
}

// ── Scan status helpers (written to storage so popup can observe) ─────────────

async function ftSetScanStatus(status) {
  await browser.storage.local.set({ ftScanStatus: status });
}

async function ftGetScanStatus() {
  const result = await browser.storage.local.get(['ftScanStatus']);
  return result.ftScanStatus || { status: 'idle' };
}
