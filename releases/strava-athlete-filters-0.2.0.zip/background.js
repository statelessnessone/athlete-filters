// Background script for the extension
// In Firefox this runs as background.scripts, in Chrome as service_worker
// Note: The source manifest.json uses scripts for Firefox development.
// At build time, build.sh generates browser-specific manifests:
// - Firefox: background.scripts
// - Chrome: background.service_worker

// In Chrome MV3 the background is a service worker; we must explicitly import
// shared modules here. In Firefox, manifest.json background.scripts loads them
// in order before this file runs, so we skip the importScripts call.
if (typeof ServiceWorkerGlobalScope !== 'undefined' &&
    self instanceof ServiceWorkerGlobalScope) {
  importScripts('browser-polyfill.js', 'snapshotManager.js', 'diffEngine.js', 'scanner.js');
}

// Debug mode (set to true for development)
const DEBUG = false;
const log = DEBUG ? console.log.bind(console) : () => {};
const error = console.error.bind(console);

// For Chrome compatibility, check if browser is undefined and create alias
if (typeof browser === 'undefined' && typeof chrome !== 'undefined') {
  globalThis.browser = chrome;
}

log('[feed-groups] Background script loaded');

// Initialize extension on install
browser.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    log('[feed-groups] Extension installed');

    // Initialize storage keys if they don't exist
    const result = await browser.storage.local.get(['groups', 'selectedAthlete']);
    const updates = {};

    if (typeof result.groups === 'undefined') {
      updates.groups = {};
    }

    if (typeof result.selectedAthlete === 'undefined') {
      updates.selectedAthlete = null;
    }

    if (Object.keys(updates).length > 0) {
      await browser.storage.local.set(updates);
    }
  } else if (details.reason === 'update') {
    log('[feed-groups] Extension updated from', details.previousVersion);
    const manifest = browser.runtime.getManifest();
    await browser.storage.local.set({
      whatsNew: { version: manifest.version, previousVersion: details.previousVersion }
    });
  }
});

// ── Follow Tracker: message handler ──────────────────────────────────────────

let ftScanInProgress = false;

// Tab-based scan coordination: maps `${scanId}_${type}_${page}` → resolve fn
const pendingTabResolvers = new Map();
const pendingTabIds = new Map();

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ftStartScan') {
    handleFollowScan(sendResponse);
    return true;
  }

  if (message.action === 'ftScanPageData') {
    // Data reported back from a background scan tab (networkInterceptor.js)
    const { scanId, page, type } = message;
    const key = `${scanId}_${type}_${page}`;
    const resolver = pendingTabResolvers.get(key);
    if (resolver) {
      pendingTabResolvers.delete(key);
      const tabId = pendingTabIds.get(key);
      pendingTabIds.delete(key);
      // Close the scan tab
      const closeId = sender.tab?.id ?? tabId;
      if (closeId) browser.tabs.remove(closeId).catch(() => {});
      resolver({ athletes: message.athletes || {}, totalPages: message.totalPages });
    }
    return false;
  }

  if (message.action === 'ftNetworkCapture') {
    handleNetworkCapture(message).catch(e =>
      error('[follow-tracker] Network capture error:', e)
    );
    return false;
  }

  if (message.action === 'ftGetStatus') {
    ftGetScanStatus().then(sendResponse).catch(() => sendResponse({ status: 'idle' }));
    return true;
  }
});

// Open one background scan tab and wait for networkInterceptor to report back.
// Returns { athletes: {id: name}, totalPages: number }
function openScanTabAndWait(athleteId, type, page, scanId) {
  return new Promise((resolve, reject) => {
    const key = `${scanId}_${type}_${page}`;
    pendingTabResolvers.set(key, resolve);

    const url = `https://www.strava.com/athletes/${athleteId}/follows` +
      `?type=${type}&page=${page}&ft_scan_id=${encodeURIComponent(scanId)}&ft_scan_page=${page}`;

    browser.tabs.create({ url, active: false }).then(tab => {
      pendingTabIds.set(key, tab.id);
    }).catch(err => {
      pendingTabResolvers.delete(key);
      reject(new Error(`Could not open scan tab: ${err.message}`));
    });

    // 45-second timeout per page
    setTimeout(() => {
      if (!pendingTabResolvers.has(key)) return;
      const tabId = pendingTabIds.get(key);
      pendingTabResolvers.delete(key);
      pendingTabIds.delete(key);
      if (tabId) browser.tabs.remove(tabId).catch(() => {});
      reject(new Error(`Scan timed out waiting for ${type} page ${page}. Please try again.`));
    }, 45000);
  });
}

// Fetch all pages of one follow type via background tabs.
async function fetchFollowsViaTab(athleteId, type, scanId, onProgress) {
  const allAthletes = {};

  // Page 1 also tells us the total page count
  const { athletes: pg1, totalPages } = await openScanTabAndWait(athleteId, type, 1, scanId);
  Object.assign(allAthletes, pg1);
  if (onProgress) onProgress(Object.keys(allAthletes).length, 1);

  for (let p = 2; p <= totalPages; p++) {
    const { athletes } = await openScanTabAndWait(athleteId, type, p, scanId);
    Object.assign(allAthletes, athletes);
    if (onProgress) onProgress(Object.keys(allAthletes).length, p);
  }

  return allAthletes;
}

async function handleFollowScan(sendResponse) {
  if (ftScanInProgress) {
    sendResponse({ success: false, error: 'A scan is already in progress.' });
    return;
  }

  ftScanInProgress = true;
  const scanId = Date.now().toString(36);

  try {
    const stored = await browser.storage.local.get(['loggedInAthleteId']);
    let athleteId = stored.loggedInAthleteId || await getAthleteIdFromActiveTab();

    if (!athleteId) {
      await ftSetScanStatus({ status: 'error', error: 'Could not determine your athlete ID. Please open Strava in a tab and try again.' });
      sendResponse({ success: false, error: 'Could not determine your athlete ID.' });
      return;
    }

    await browser.storage.local.set({ loggedInAthleteId: athleteId });

    await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps: 3, message: 'Fetching following list…' });
    const following = await fetchFollowsViaTab(athleteId, 'following', scanId, async (count, pg) => {
      await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps: 3, message: `Fetching following… ${count} found (page ${pg})` });
    });

    await ftSetScanStatus({ status: 'scanning', step: 2, totalSteps: 3, message: 'Fetching followers list…' });
    const followers = await fetchFollowsViaTab(athleteId, 'followers', scanId, async (count, pg) => {
      await ftSetScanStatus({ status: 'scanning', step: 2, totalSteps: 3, message: `Fetching followers… ${count} found (page ${pg})` });
    });

    await ftSetScanStatus({ status: 'scanning', step: 3, totalSteps: 3, message: 'Saving results…' });

    const snapshot = { date: Math.floor(Date.now() / 1000), followers, following };
    const snapshotData = await ftGetData();
    const events = ftComputeDiff(snapshotData.latestSnapshot, snapshot);
    await ftSaveSnapshot(snapshot, events);

    const result = {
      followerCount: Object.keys(followers).length,
      followingCount: Object.keys(following).length,
      newEvents: events.length,
      isFirstScan: !snapshotData.latestSnapshot,
    };

    await ftSetScanStatus({ status: 'complete', completedAt: Math.floor(Date.now() / 1000), ...result });
    sendResponse({ success: true, ...result });
  } catch (e) {
    error('[follow-tracker] Scan failed:', e);
    const msg = e.message || 'Scan failed. Please try again.';
    await ftSetScanStatus({ status: 'error', error: msg });
    sendResponse({ success: false, error: msg });
  } finally {
    ftScanInProgress = false;
  }
}

// Query the active browser tab for the logged-in athlete ID via content script message
async function getAthleteIdFromActiveTab() {
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0]) return null;
    const response = await browser.tabs.sendMessage(tabs[0].id, { action: 'getAthleteId' });
    return response?.athleteId || null;
  } catch (_) {
    return null;
  }
}

// Handle passively intercepted follow data from networkInterceptor.js
async function handleNetworkCapture(message) {
  // Build a partial snapshot update — we accumulate pages into a pending object
  // stored under 'ftNetworkPending' until the page is fully loaded.
  const result = await browser.storage.local.get(['ftNetworkPending']);
  const pending = result.ftNetworkPending || { followers: {}, following: {} };

  const type = message.type; // 'followers' or 'following'
  if (type === 'followers' || type === 'following') {
    Object.assign(pending[type], message.athletes);
  }

  await browser.storage.local.set({ ftNetworkPending: pending });
  log(`[follow-tracker] Network capture: ${Object.keys(message.athletes).length} ${type}`);
}



