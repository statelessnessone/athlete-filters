// Follow Tracker: Snapshot Manager
// Manages follow tracker data in browser.storage.local
//
// Storage schema (stored under key 'followTracker'):
// {
//   latestSnapshot: {
//     date: <unix timestamp>,
//     followers: { "<id>": "<name>", ... },
//     following: { "<id>": "<name>", ... }
//   },
//   events: [
//     { date: "YYYY-MM-DD", type: "follower_gained"|"follower_lost"|
//                                 "followed"|"unfollowed"|"name_changed",
//       id: "<string>", name: "<string>", oldName?: "<string>" }
//   ],
//   lastScanDate: <unix timestamp> | null
// }

const FOLLOW_TRACKER_KEY = 'followTracker';

// Read all follow tracker data from storage
async function ftGetData() {
  const result = await browser.storage.local.get([FOLLOW_TRACKER_KEY]);
  return result[FOLLOW_TRACKER_KEY] || { latestSnapshot: null, events: [], lastScanDate: null };
}

// Write all follow tracker data to storage
async function ftSaveData(data) {
  await browser.storage.local.set({ [FOLLOW_TRACKER_KEY]: data });
}

// Persist a new snapshot and append any new events
async function ftSaveSnapshot(snapshot, newEvents) {
  const data = await ftGetData();
  data.latestSnapshot = snapshot;
  data.lastScanDate = snapshot.date;
  if (newEvents && newEvents.length > 0) {
    data.events = [...(data.events || []), ...newEvents];
  }
  await ftSaveData(data);
}

// Append events without touching the snapshot (e.g. from network interceptor)
async function ftAppendEvents(newEvents) {
  if (!newEvents || newEvents.length === 0) return;
  const data = await ftGetData();
  data.events = [...(data.events || []), ...newEvents];
  await ftSaveData(data);
}

// Wipe all follow tracker data
async function ftClearData() {
  await browser.storage.local.remove(FOLLOW_TRACKER_KEY);
}

// Generate a CSV string from the event log
function ftExportCSV(events) {
  const header = 'date,type,id,name,oldName';
  if (!events || events.length === 0) return header + '\n';
  const rows = events.map(e => {
    const name = (e.name || '').replace(/"/g, '""');
    const oldName = (e.oldName || '').replace(/"/g, '""');
    return `${e.date},${e.type},${e.id},"${name}","${oldName}"`;
  });
  return [header, ...rows].join('\n');
}

// Format a unix timestamp into a human-readable string
function ftFormatDate(unixTs) {
  if (!unixTs) return 'Never';
  return new Date(unixTs * 1000).toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}
