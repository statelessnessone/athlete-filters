// Popup script for managing groups and athletes

// Debug mode (set to true for development)
const DEBUG = false;
const log = DEBUG ? console.log.bind(console) : () => {};
const warn = DEBUG ? console.warn.bind(console) : () => {};
const error = console.error.bind(console);

// Utility: Alphabetical sort comparator
function alphabeticalSort(a, b) {
  return a.localeCompare(b);
}

// Utility: Sort athletes by name
function sortAthletesByName(athletes) {
  return [...athletes].sort((a, b) => alphabeticalSort(a.name, b.name));
}

let selectedAthlete = null;

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  setupTabs();
  ftSetupEventListeners();
  await loadGroups();
  await loadSelectedAthlete();
  setupEventListeners();
  displayVersion();
});

// Display extension version from manifest
function displayVersion() {
  const manifest = browser.runtime.getManifest();
  document.getElementById('extensionVersion').textContent = manifest.version;
}

// Setup event listeners
function setupEventListeners() {
  document.getElementById('createGroup').addEventListener('click', createGroup);
  document.getElementById('addToGroup').addEventListener('click', addAthleteToGroup);
  document.getElementById('applyFilter').addEventListener('click', applyFilter);
  document.getElementById('clearFilter').addEventListener('click', clearFilter);
  document.getElementById('refreshPage').addEventListener('click', refreshPage);
}

// Load groups from storage
async function loadGroups() {
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  displayGroups(groups);
  updateGroupSelects(groups);
}

// Display groups in the UI
function displayGroups(groups) {
  const groupsList = document.getElementById('groupsList');
  
  if (Object.keys(groups).length === 0) {
    groupsList.innerHTML = '<div class="empty-state">No groups created yet</div>';
    return;
  }
  
  groupsList.innerHTML = '';
  
  // Sort groups alphabetically by name
  const sortedGroups = Object.entries(groups).sort((a, b) => 
    alphabeticalSort(a[1].name, b[1].name)
  );
  
  for (const [groupId, group] of sortedGroups) {
    const groupDiv = document.createElement('div');
    groupDiv.className = 'group-item';
    
    const athleteCount = group.athletes ? group.athletes.length : 0;
    
    // Create elements safely using DOM methods
    const nameSpan = document.createElement('span');
    nameSpan.className = 'group-name';
    nameSpan.textContent = group.name;
    nameSpan.addEventListener('click', () => toggleGroupAthletes(groupDiv, group));
    
    const countSpan = document.createElement('span');
    countSpan.className = 'group-count';
    countSpan.textContent = `${athleteCount} athlete${athleteCount !== 1 ? 's' : ''}`;
    
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-group';
    deleteButton.textContent = 'Delete';
    deleteButton.setAttribute('data-group-id', groupId);
    deleteButton.setAttribute('aria-label', `Delete ${group.name} group`);
    deleteButton.addEventListener('click', () => deleteGroup(groupId, group.name));
    
    groupDiv.appendChild(nameSpan);
    groupDiv.appendChild(countSpan);
    groupDiv.appendChild(deleteButton);
    
    groupsList.appendChild(groupDiv);
  }
}

// Toggle display of athletes in a group
function toggleGroupAthletes(groupDiv, group) {
  let athletesDiv = groupDiv.querySelector('.athletes-list');
  
  if (athletesDiv) {
    athletesDiv.remove();
    return;
  }
  
  if (!group.athletes || group.athletes.length === 0) {
    return;
  }
  
  athletesDiv = document.createElement('div');
  athletesDiv.className = 'athletes-list';
  
  // Sort athletes alphabetically by name
  const sortedAthletes = sortAthletesByName(group.athletes);
  
  for (const athlete of sortedAthletes) {
    const athleteDiv = document.createElement('div');
    athleteDiv.className = 'athlete-item';
    
    const nameSpan = document.createElement('span');
    nameSpan.textContent = athlete.name;
    
    const removeButton = document.createElement('button');
    removeButton.className = 'remove-athlete';
    removeButton.textContent = 'Remove';
    removeButton.setAttribute('data-athlete-id', String(athlete.id));
    removeButton.setAttribute('aria-label', `Remove ${athlete.name} from group`);
    removeButton.addEventListener('click', (e) => {
      e.stopPropagation();
      removeAthleteFromGroup(group.id, athlete.id);
    });
    
    athleteDiv.appendChild(nameSpan);
    athleteDiv.appendChild(removeButton);
    athletesDiv.appendChild(athleteDiv);
  }
  
  groupDiv.appendChild(athletesDiv);
}

// Update group select dropdowns
function updateGroupSelects(groups) {
  const groupSelect = document.getElementById('groupSelect');
  const filterGroup = document.getElementById('filterGroup');
  
  // Clear and rebuild
  groupSelect.innerHTML = '<option value="">Select a group...</option>';
  filterGroup.innerHTML = '<option value="">All Athletes</option>';
  
  // Sort groups alphabetically by name
  const sortedGroups = Object.entries(groups).sort((a, b) => 
    a[1].name.localeCompare(b[1].name, undefined, { sensitivity: 'base' })
  );
  
  for (const [groupId, group] of sortedGroups) {
    const option1 = document.createElement('option');
    option1.value = groupId;
    option1.textContent = group.name;
    groupSelect.appendChild(option1);
    
    const option2 = document.createElement('option');
    option2.value = groupId;
    option2.textContent = group.name;
    filterGroup.appendChild(option2);
  }
}

// Create a new group
async function createGroup() {
  const nameInput = document.getElementById('newGroupName');
  const name = nameInput.value.trim();
  
  if (!name) {
    showInlineMessage('Please enter a group name', 'error');
    return;
  }
  
  // Validate max length (reasonable limit for UI display)
  if (name.length > 50) {
    showInlineMessage('Group name must be 50 characters or less', 'error');
    return;
  }
  
  // Sanitize control characters from group name
  const sanitizedName = name.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  if (sanitizedName !== name) {
    showInlineMessage('Group name contains invalid characters', 'error');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  // Generate unique ID with random component to avoid collisions
  const groupId = 'group_' + Date.now() + '_' + Math.random().toString(36).slice(2, 11);
  
  groups[groupId] = {
    id: groupId,
    name: sanitizedName,
    athletes: []
  };
  
  await browser.storage.local.set({ groups });
  
  nameInput.value = '';
  await loadGroups();
  showInlineMessage(`Group "${sanitizedName}" created`, 'success');
}

// Delete a group
async function deleteGroup(groupId, groupName) {
  const confirmed = await showConfirmDialog(
    'Delete Group',
    `Are you sure you want to delete "${groupName}"?`
  );
  
  if (!confirmed) {
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  delete groups[groupId];
  
  await browser.storage.local.set({ groups });
  await loadGroups();
  showInlineMessage('Group deleted', 'success');
}

// Load selected athlete info
async function loadSelectedAthlete() {
  const result = await browser.storage.local.get(['selectedAthlete', 'groups']);
  selectedAthlete = result.selectedAthlete;
  const groups = result.groups || {};
  
  const infoDiv = document.getElementById('selectedAthleteInfo');
  const addToGroupSection = document.getElementById('addToGroupSection');
  
  if (selectedAthlete) {
    infoDiv.innerHTML = '';
    
    const athleteInfo = document.createElement('div');
    athleteInfo.className = 'athlete-info';
    
    const athleteName = document.createElement('div');
    athleteName.className = 'athlete-name';
    athleteName.textContent = selectedAthlete.name;
    
    const athleteId = document.createElement('div');
    athleteId.className = 'athlete-id';
    athleteId.textContent = `ID: ${selectedAthlete.id}`;
    
    athleteInfo.appendChild(athleteName);
    athleteInfo.appendChild(athleteId);
    
    // Find which groups this athlete belongs to
    const athleteGroups = [];
    log('[feed-groups] Checking athlete:', selectedAthlete.id, 'Type:', typeof selectedAthlete.id);
    log('[feed-groups] Available groups:', Object.keys(groups).length);
    
    for (const [groupId, group] of Object.entries(groups)) {
      log('[feed-groups] Checking group:', group.name, 'Athletes:', group.athletes);
      if (group.athletes && group.athletes.length > 0) {
        log('[feed-groups] First athlete in group - ID:', group.athletes[0].id, 'Type:', typeof group.athletes[0].id);
        const found = group.athletes.some(a => {
          const match = a.id === selectedAthlete.id || String(a.id) === String(selectedAthlete.id);
          if (match) {
            log('[feed-groups] Match found in group:', group.name);
          }
          return match;
        });
        if (found) {
          athleteGroups.push(group.name);
        }
      }
    }
    
    // Display groups list if athlete is in any groups
    if (athleteGroups.length > 0) {
      const groupsSection = document.createElement('div');
      groupsSection.className = 'athlete-groups-section';
      
      const groupsLabel = document.createElement('div');
      groupsLabel.className = 'athlete-groups-label';
      groupsLabel.textContent = `Member of ${athleteGroups.length} group${athleteGroups.length !== 1 ? 's' : ''}:`;
      
      const groupsList = document.createElement('div');
      groupsList.className = 'athlete-groups-list';
      
      // Sort groups alphabetically
      athleteGroups.sort(alphabeticalSort);
      
      for (const groupName of athleteGroups) {
        const groupTag = document.createElement('span');
        groupTag.className = 'group-tag';
        groupTag.textContent = groupName;
        groupsList.appendChild(groupTag);
      }
      
      groupsSection.appendChild(groupsLabel);
      groupsSection.appendChild(groupsList);
      athleteInfo.appendChild(groupsSection);
    }
    
    infoDiv.appendChild(athleteInfo);
    
    addToGroupSection.style.display = 'block';
  } else {
    infoDiv.innerHTML = '<p class="info-text">Click on an athlete in the Strava feed to add them to a group</p>';
    addToGroupSection.style.display = 'none';
  }
}

// Add athlete to selected group
async function addAthleteToGroup() {
  if (!selectedAthlete) {
    showInlineMessage('No athlete selected', 'error');
    return;
  }
  
  const groupSelect = document.getElementById('groupSelect');
  const groupId = groupSelect.value;
  
  if (!groupId) {
    showInlineMessage('Please select a group', 'error');
    return;
  }
  
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (!groups[groupId]) {
    showInlineMessage('Group not found', 'error');
    return;
  }
  
  // Check if athlete already in group
  if (groups[groupId].athletes.some(a => a.id === selectedAthlete.id)) {
    showInlineMessage('Athlete already in this group', 'error');
    return;
  }
  
  groups[groupId].athletes.push(selectedAthlete);
  
  await browser.storage.local.set({ groups });
  await loadGroups();
  await loadSelectedAthlete();
  
  showInlineMessage(`Added ${selectedAthlete.name} to ${groups[groupId].name}`, 'success');
}

// Remove athlete from group
async function removeAthleteFromGroup(groupId, athleteId) {
  const result = await browser.storage.local.get(['groups']);
  const groups = result.groups || {};
  
  if (groups[groupId]) {
    groups[groupId].athletes = groups[groupId].athletes.filter(a => a.id !== athleteId);
    await browser.storage.local.set({ groups });
    await loadGroups();
    await loadSelectedAthlete();
    showInlineMessage('Athlete removed from group', 'success');
  }
}

// Apply filter to feed
async function applyFilter() {
  const filterGroup = document.getElementById('filterGroup');
  const groupId = filterGroup.value;
  
  console.log('[feed-groups] Applying filter for groupId:', groupId);
  
  // Send message to content script
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  
  if (tabs[0]) {
    console.log('[feed-groups] Sending message to tab:', tabs[0].id);
    try {
      await browser.tabs.sendMessage(tabs[0].id, {
        action: 'applyFilter',
        groupId: groupId
      });
      console.log('[feed-groups] Filter message sent successfully');
    } catch (error) {
      console.error('[feed-groups] Failed to apply filter:', error);
      showInlineMessage('Please make sure you are on the Strava dashboard page.', 'error');
    }
  } else {
    console.error('No active tab found');
    showInlineMessage('No active tab found', 'error');
  }
}

// Clear filter
async function clearFilter() {
  console.log('[feed-groups] Clearing filter');
  
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  
  if (tabs[0]) {
    console.log('[feed-groups] Sending clear filter message to tab:', tabs[0].id);
    try {
      await browser.tabs.sendMessage(tabs[0].id, {
        action: 'clearFilter'
      });
      console.log('[feed-groups] Clear filter message sent successfully');
    } catch (error) {
      console.error('[feed-groups] Failed to clear filter:', error);
      showInlineMessage('Please make sure you are on the Strava dashboard page.', 'error');
    }
  } else {
    console.error('No active tab found');
    showInlineMessage('No active tab found', 'error');
  }
}

// Show inline message
let inlineMessageTimeout = null;

function showInlineMessage(message, type = 'info') {
  // Clear any existing timeout
  if (inlineMessageTimeout) {
    clearTimeout(inlineMessageTimeout);
  }
  
  // Create or update a message element
  let messageDiv = document.getElementById('inlineMessage');
  if (!messageDiv) {
    messageDiv = document.createElement('div');
    messageDiv.id = 'inlineMessage';
    messageDiv.className = 'inline-message';
    document.querySelector('.container').insertBefore(messageDiv, document.querySelector('.section'));
  }
  
  messageDiv.className = `inline-message ${type}`;
  messageDiv.textContent = message;
  messageDiv.style.display = 'block';
  
  inlineMessageTimeout = setTimeout(() => {
    messageDiv.style.display = 'none';
    inlineMessageTimeout = null;
  }, 3000);
}

// Show confirm dialog
function showConfirmDialog(title, message) {
  return new Promise((resolve) => {
    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    
    // Create modal
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-labelledby', 'modal-title');
    
    // Create title
    const titleEl = document.createElement('h3');
    titleEl.id = 'modal-title';
    titleEl.className = 'modal-title';
    titleEl.textContent = title;
    
    // Create message
    const messageEl = document.createElement('p');
    messageEl.className = 'modal-message';
    messageEl.textContent = message;
    
    // Create buttons container
    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'modal-buttons';
    
    // Cleanup function to remove modal and event listener
    const cleanup = (result) => {
      document.removeEventListener('keydown', handleEscape);
      overlay.remove();
      resolve(result);
    };
    
    // Create cancel button
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'cancel-btn';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.addEventListener('click', () => cleanup(false));
    
    // Create confirm button
    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'confirm-btn';
    confirmBtn.textContent = 'Confirm';
    confirmBtn.addEventListener('click', () => cleanup(true));
    
    // Handle Escape key
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        cleanup(false);
      }
    };
    document.addEventListener('keydown', handleEscape);
    
    buttonsDiv.appendChild(cancelBtn);
    buttonsDiv.appendChild(confirmBtn);
    
    modal.appendChild(titleEl);
    modal.appendChild(messageEl);
    modal.appendChild(buttonsDiv);
    overlay.appendChild(modal);
    
    document.body.appendChild(overlay);
    
    // Focus confirm button
    confirmBtn.focus();
  });
}

// Refresh page
async function refreshPage() {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  
  if (tabs[0]) {
    await browser.tabs.reload(tabs[0].id);
  }
}

// Listen for storage changes
browser.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.groups) {
      loadGroups();
    }
    if (changes.selectedAthlete) {
      loadSelectedAthlete();
    }
    // Follow Tracker: react to completed scan or network capture
    if (changes.ftScanStatus || changes.followTracker) {
      ftHandleStorageChange(changes);
    }
  }
});

// ── Tab switching ────────────────────────────────────────────────────────────

function setupTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.tab === tabId);
        b.setAttribute('aria-selected', b.dataset.tab === tabId ? 'true' : 'false');
      });
      document.querySelectorAll('.tab-panel').forEach(panel => {
        const isActive = panel.id === `tab-${tabId}`;
        panel.style.display = isActive ? 'block' : 'none';
        panel.classList.toggle('active', isActive);
      });
      if (tabId === 'follow-tracker') {
        ftInitTab();
      }
    });
  });

  // Activate the default tab (groups) on load
  const defaultTab = document.querySelector('.tab-btn.active');
  if (defaultTab) {
    const tabId = defaultTab.dataset.tab;
    document.querySelectorAll('.tab-panel').forEach(panel => {
      const isActive = panel.id === `tab-${tabId}`;
      panel.style.display = isActive ? 'block' : 'none';
      panel.classList.toggle('active', isActive);
    });
  }
}

// ── Follow Tracker tab ───────────────────────────────────────────────────────

const EVENT_HISTORY_LIMIT = 50; // default visible events in popup

const FT_EVENT_META = {
  follower_gained: { icon: '👤', label: 'followed you',       badge: '+', cls: 'gain' },
  follower_lost:   { icon: '👤', label: 'unfollowed you',     badge: '−', cls: 'loss' },
  followed:        { icon: '🔵', label: 'you followed',       badge: '+', cls: 'gain' },
  unfollowed:      { icon: '🔵', label: 'you unfollowed',     badge: '−', cls: 'loss' },
  name_changed:    { icon: '✏️', label: 'name changed',       badge: 'i', cls: 'info' },
};

async function ftInitTab() {
  const data = await ftGetData();
  ftRenderStats(data);
  ftRenderChanges(data);
  ftRenderHistory(data);

  // Show clear button only when there's data
  const clearBtn = document.getElementById('ft-clear-btn');
  if (clearBtn) clearBtn.style.display = data.latestSnapshot ? 'block' : 'none';

  // Reflect any in-progress scan
  const status = await browser.storage.local.get(['ftScanStatus']);
  if (status.ftScanStatus?.status === 'scanning') {
    ftShowProgress(status.ftScanStatus);
  }
}

function ftRenderStats(data) {
  const snap = data.latestSnapshot;
  const followerEl = document.getElementById('ft-follower-count');
  const followingEl = document.getElementById('ft-following-count');
  const mutualEl   = document.getElementById('ft-mutual-count');
  const lastScanEl = document.getElementById('ft-last-scan-time');

  if (snap) {
    const followerCount = Object.keys(snap.followers || {}).length;
    const followingCount = Object.keys(snap.following || {}).length;
    const rel = ftGetRelationships(snap);
    const mutualCount = Object.keys(rel.mutual).length;

    if (followerEl) followerEl.textContent = followerCount.toLocaleString();
    if (followingEl) followingEl.textContent = followingCount.toLocaleString();
    if (mutualEl) mutualEl.textContent = mutualCount.toLocaleString();
    if (lastScanEl) lastScanEl.textContent = ftFormatDate(data.lastScanDate);
  } else {
    ['ft-follower-count','ft-following-count','ft-mutual-count'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = '—';
    });
    if (lastScanEl) lastScanEl.textContent = 'Never';
  }
}

function ftRenderChanges(data) {
  const container = document.getElementById('ft-changes');
  if (!container) return;

  // Find events from the most recent scan date
  const events = data.events || [];
  if (events.length === 0 || !data.latestSnapshot) {
    container.innerHTML = '';
    container.className = 'ft-changes-empty';
    container.textContent = data.latestSnapshot
      ? 'No changes detected in last scan.'
      : 'Run a scan to compare with your previous snapshot.';
    return;
  }

  // Group events by last scan date
  const lastDate = events[events.length - 1].date;
  const recentEvents = events.filter(e => e.date === lastDate);

  if (recentEvents.length === 0) {
    container.innerHTML = '';
    container.className = 'ft-changes-empty';
    container.textContent = 'No changes detected in last scan.';
    return;
  }

  container.className = '';
  const summary = ftSummariseEvents(recentEvents);
  const rows = [
    { key: 'follower_gained', label: 'new followers',  cls: 'gain' },
    { key: 'follower_lost',   label: 'lost followers', cls: 'loss' },
    { key: 'followed',        label: 'new following',  cls: 'gain' },
    { key: 'unfollowed',      label: 'unfollowed',     cls: 'loss' },
    { key: 'name_changed',    label: 'name changes',   cls: 'info' },
  ].filter(r => summary[r.key] > 0);

  container.innerHTML = rows.map(r => `
    <div class="ft-change-row">
      <span class="ft-change-badge ${r.cls}">${r.cls === 'gain' ? '+' : r.cls === 'loss' ? '−' : 'i'}</span>
      <span class="ft-change-label">${r.label}</span>
      <span class="ft-change-count ${r.cls}">${summary[r.key]}</span>
    </div>`).join('');
}

function ftRenderHistory(data) {
  const container = document.getElementById('ft-history');
  const countEl   = document.getElementById('ft-event-count');
  if (!container) return;

  const events = [...(data.events || [])].reverse(); // newest first

  if (countEl) countEl.textContent = events.length > 0 ? `${events.length} total` : '';

  if (events.length === 0) {
    container.className = 'ft-history-empty';
    container.textContent = 'No events recorded yet.';
    return;
  }

  container.className = '';
  const visible = events.slice(0, EVENT_HISTORY_LIMIT);
  container.innerHTML = visible.map(e => {
    const meta = FT_EVENT_META[e.type] || { icon: '•', label: e.type, badge: '•', cls: 'info' };
    const nameText = e.type === 'name_changed'
      ? `<strong>${e.name}</strong> (was ${e.oldName || '?'})`
      : `<strong>${e.name}</strong>`;
    const verb = meta.label;
    return `
      <div class="ft-event-item">
        <span class="ft-event-date">${e.date}</span>
        <span class="ft-event-icon">${meta.icon}</span>
        <span class="ft-event-text">${nameText} ${verb}</span>
      </div>`;
  }).join('');

  if (events.length > EVENT_HISTORY_LIMIT) {
    container.innerHTML += `<p class="ft-changes-empty" style="margin-top:8px;">
      Showing ${EVENT_HISTORY_LIMIT} of ${events.length} events. Export CSV for full history.
    </p>`;
  }
}

function ftShowProgress(status) {
  const progressDiv = document.getElementById('ft-scan-progress');
  const bar         = document.getElementById('ft-progress-bar');
  const msg         = document.getElementById('ft-progress-msg');
  const errDiv      = document.getElementById('ft-scan-error');
  const scanBtn     = document.getElementById('ft-scan-btn');

  if (progressDiv) progressDiv.style.display = 'block';
  if (errDiv) errDiv.style.display = 'none';
  if (scanBtn) { scanBtn.disabled = true; scanBtn.textContent = 'Scanning…'; }

  if (bar && status.step && status.totalSteps) {
    bar.style.width = `${Math.round((status.step / status.totalSteps) * 100)}%`;
  }
  if (msg) msg.textContent = status.message || 'Scanning…';
}

function ftHideProgress() {
  const progressDiv = document.getElementById('ft-scan-progress');
  const scanBtn = document.getElementById('ft-scan-btn');
  if (progressDiv) progressDiv.style.display = 'none';
  if (scanBtn) { scanBtn.disabled = false; scanBtn.textContent = '⟳ Scan Now'; }
}

function ftShowError(msg) {
  ftHideProgress();
  const errDiv = document.getElementById('ft-scan-error');
  if (errDiv) { errDiv.textContent = msg; errDiv.style.display = 'block'; }
}

async function ftHandleStorageChange(changes) {
  const isFollowTrackerTab = document.querySelector('#tab-follow-tracker.active') ||
    document.getElementById('tab-follow-tracker')?.style.display !== 'none';
  if (!isFollowTrackerTab) return;

  if (changes.ftScanStatus) {
    const status = changes.ftScanStatus.newValue || {};
    if (status.status === 'scanning') {
      ftShowProgress(status);
    } else if (status.status === 'complete') {
      ftHideProgress();
      const data = await ftGetData();
      ftRenderStats(data);
      ftRenderChanges(data);
      ftRenderHistory(data);
      const clearBtn = document.getElementById('ft-clear-btn');
      if (clearBtn) clearBtn.style.display = 'block';
    } else if (status.status === 'error') {
      ftShowError(status.error || 'Scan failed. Please try again.');
    }
  }

  if (changes.followTracker) {
    const data = await ftGetData();
    ftRenderStats(data);
    ftRenderChanges(data);
    ftRenderHistory(data);
  }
}

function ftSetupEventListeners() {
  const scanBtn = document.getElementById('ft-scan-btn');
  if (scanBtn) {
    scanBtn.addEventListener('click', async () => {
      document.getElementById('ft-scan-error')?.style && (document.getElementById('ft-scan-error').style.display = 'none');
      const bar = document.getElementById('ft-progress-bar');
      if (bar) bar.style.width = '0%';
      ftShowProgress({ step: 0, totalSteps: 4, message: 'Starting scan…' });

      try {
        const response = await browser.runtime.sendMessage({ action: 'ftStartScan' });
        if (!response.success) {
          ftShowError(response.error || 'Scan failed.');
        }
        // UI updates come via storage.onChanged
      } catch (e) {
        ftShowError('Could not start scan: ' + e.message);
      }
    });
  }

  const exportBtn = document.getElementById('ft-export-btn');
  if (exportBtn) {
    exportBtn.addEventListener('click', async () => {
      const data = await ftGetData();
      const csv = ftExportCSV(data.events || []);
      const blob = new Blob([csv], { type: 'text/csv' });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url;
      a.download = `strava-follow-tracker-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      // Defer revoking the object URL to avoid cancelling/truncating downloads in some browsers
      setTimeout(() => URL.revokeObjectURL(url), 100);
    });
  }

  const clearBtn = document.getElementById('ft-clear-btn');
  if (clearBtn) {
    clearBtn.addEventListener('click', async () => {
      const confirmed = await showConfirmDialog(
        'Clear Follow Tracker',
        'This will delete all snapshots and event history. This cannot be undone.'
      );
      if (!confirmed) return;
      await ftClearData();
      await browser.storage.local.remove(['ftScanStatus', 'ftNetworkPending']);
      ftInitTab();
    });
  }
}
