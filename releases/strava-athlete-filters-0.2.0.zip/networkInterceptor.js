// Follow Tracker: Network Interceptor
// Injected as a content script on Strava follower/following pages.
// Wraps window.fetch and XMLHttpRequest to capture Strava's internal paginated
// API calls and forward the follow data to the background for storage.
//
// This provides passive capture whenever the user naturally browses their
// followers/following pages, without requiring any active scan.

(function () {
  'use strict';

  const FT_FOLLOWS_PATTERN = /\/athletes\/\d+\/follows/;
  const capturedUrls = new Set();

  // ── Athlete extraction from JSON (legacy — Strava used to return JSON) ────────

  function extractAthletesFromJson(data) {
    if (!Array.isArray(data) || data.length === 0) return null;
    const athletes = {};
    for (const rawItem of data) {
      if (!rawItem) continue;
      let item = rawItem;
      if (Array.isArray(item)) item = item[1] || item[0];
      if (!item || typeof item !== 'object') continue;
      const entry = (item.athlete && typeof item.athlete === 'object') ? item.athlete : item;
      const id = String(entry.id || entry.athlete_id || item.athlete_id || '').trim();
      if (!id || id === '0') continue;
      const name = (
        entry.name ||
        [entry.firstname, entry.lastname].filter(Boolean).join(' ') ||
        `Athlete ${id}`
      ).trim();
      athletes[id] = name;
    }
    return Object.keys(athletes).length > 0 ? athletes : null;
  }

  // ── Athlete extraction from HTML (current Strava behaviour) ───────────────────

  function extractAthletesFromHtml(html) {
    const athletes = {};
    const liRe = /<li[^>]+data-athlete-id="(\d+)"[^>]*>([\s\S]*?)<\/li>/g;
    let m;
    while ((m = liRe.exec(html)) !== null) {
      const id = m[1];
      const body = m[2];
      const nameMatch = body.match(/<a[^>]+href="\/athletes\/\d+"[^>]*>([\s\S]*?)<\/a>/);
      const name = nameMatch
        ? nameMatch[1].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()
        : `Athlete ${id}`;
      athletes[id] = name;
    }
    return athletes;
  }

  // ── Scrape athletes directly from the current page DOM ───────────────────────

  function scrapePageAthletes() {
    const athletes = {};
    document.querySelectorAll('li[data-athlete-id]').forEach(li => {
      const id = li.getAttribute('data-athlete-id');
      if (!id) return;
      const a = li.querySelector('a[href^="/athletes/"]');
      const name = a ? a.textContent.replace(/\s+/g, ' ').trim() : `Athlete ${id}`;
      athletes[id] = name;
    });
    return athletes;
  }

  // ── Forward athletes dict to background ──────────────────────────────────────

  function sendToBackground(athletes, type, url) {
    if (!athletes || Object.keys(athletes).length === 0) return;
    browser.runtime.sendMessage({
      action: 'ftNetworkCapture',
      type,
      athletes,
      url,
      pageUrl: window.location.href,
    }).catch(() => {});
  }

  // ── DOM scraping on page load (SSR content — captures page 1 instantly) ──────

  const urlParams = new URLSearchParams(window.location.search);
  const pageType = urlParams.get('type') || 'following';
  const scanId   = urlParams.get('ft_scan_id')  || null;
  const scanPage = parseInt(urlParams.get('ft_scan_page') || '1', 10);

  document.addEventListener('DOMContentLoaded', () => {
    const athletes = scrapePageAthletes();

    if (scanId) {
      // ── Scan-tab mode ──────────────────────────────────────────────────────
      // background.js opened this tab specifically to collect follows data.
      // Extract total page count from pagination, report back, then background
      // will close this tab.
      let totalPages = scanPage;
      document.querySelectorAll('.pagination li a[href*="page="]').forEach(a => {
        try {
          const p = parseInt(new URL(a.href, location.origin).searchParams.get('page'), 10);
          if (!isNaN(p) && p > totalPages) totalPages = p;
        } catch (_) {}
      });

      browser.runtime.sendMessage({
        action: 'ftScanPageData',
        scanId,
        page: scanPage,
        totalPages,
        type: pageType,
        athletes,
      }).catch(() => {});
      return; // Skip passive capture in scan-tab mode
    }

    // ── Normal passive capture ─────────────────────────────────────────────
    sendToBackground(athletes, pageType, window.location.href);
  });

  // ── fetch + XHR wrappers (passive capture for normal browsing only) ──────────
  // Skip entirely in scan-tab mode — background.js controls tab lifecycle there.

  if (!scanId) {
    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
      const response = await originalFetch.apply(this, args);
      try {
        const url = (typeof args[0] === 'string' ? args[0] : args[0]?.url) || '';
        if (FT_FOLLOWS_PATTERN.test(url) && !capturedUrls.has(url)) {
          capturedUrls.add(url);
          const urlObj = new URL(url, window.location.origin);
          const type = urlObj.searchParams.get('type') || pageType;
          response.clone().text().then(text => {
            let athletes = null;
            try {
              const data = JSON.parse(text);
              athletes = extractAthletesFromJson(data);
            } catch (_) {}
            if (!athletes || Object.keys(athletes).length === 0) {
              athletes = extractAthletesFromHtml(text);
            }
            sendToBackground(athletes, type, url);
          }).catch(() => {});
        }
      } catch (_) {}
      return response;
    };

    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      this._ftUrl = String(url || '');
      return origOpen.apply(this, [method, url, ...rest]);
    };

    XMLHttpRequest.prototype.send = function (...args) {
      const url = this._ftUrl || '';
      if (FT_FOLLOWS_PATTERN.test(url) && !capturedUrls.has(url)) {
        capturedUrls.add(url);
        const urlObj = new URL(url, window.location.origin);
        const type = urlObj.searchParams.get('type') || pageType;
        this.addEventListener('load', () => {
          let athletes = null;
          try {
            const data = JSON.parse(this.responseText);
            athletes = extractAthletesFromJson(data);
          } catch (_) {}
          if (!athletes || Object.keys(athletes).length === 0) {
            athletes = extractAthletesFromHtml(this.responseText);
          }
          sendToBackground(athletes, type, url);
        });
      }
      return origSend.apply(this, args);
    };
  }
})();
