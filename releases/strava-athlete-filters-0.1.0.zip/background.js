// Background script for the extension
// In Firefox this runs as background.scripts, in Chrome as service_worker
// Note: The source manifest.json uses scripts for Firefox development.
// At build time, build.sh generates browser-specific manifests:
// - Firefox: background.scripts
// - Chrome: background.service_worker

// In Chrome MV3 the background is a service worker; we must explicitly import
// shared modules here. In Firefox, manifest.json background.scripts loads them
// in order before this file runs, so we skip the importScripts call.
if (typeof ServiceWorkerGlobalScope !== 'undefined' &&
    self instanceof ServiceWorkerGlobalScope) {
  importScripts('browser-polyfill.js', 'snapshotManager.js', 'diffEngine.js', 'scanner.js');
}

// Debug mode (set to true for development)
const DEBUG = false;
const log = DEBUG ? console.log.bind(console) : () => {};
const error = console.error.bind(console);

// For Chrome compatibility, check if browser is undefined and create alias
if (typeof browser === 'undefined' && typeof chrome !== 'undefined') {
  globalThis.browser = chrome;
}

log('[feed-groups] Background script loaded');

// Initialize extension on install
browser.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    log('[feed-groups] Extension installed');

    // Initialize storage keys if they don't exist
    const result = await browser.storage.local.get(['groups', 'selectedAthlete']);
    const updates = {};

    if (typeof result.groups === 'undefined') {
      updates.groups = {};
    }

    if (typeof result.selectedAthlete === 'undefined') {
      updates.selectedAthlete = null;
    }

    if (Object.keys(updates).length > 0) {
      await browser.storage.local.set(updates);
    }
  } else if (details.reason === 'update') {
    log('[feed-groups] Extension updated from', details.previousVersion);
    const manifest = browser.runtime.getManifest();
    await browser.storage.local.set({
      whatsNew: { version: manifest.version, previousVersion: details.previousVersion }
    });
  }
});

// ── Follow Tracker: message handler ──────────────────────────────────────────

let ftScanInProgress = false;

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ftStartScan') {
    handleFollowScan(sendResponse);
    return true; // Keep message channel open for async response
  }

  if (message.action === 'ftNetworkCapture') {
    // Passive capture from networkInterceptor content script
    handleNetworkCapture(message).catch(e =>
      error('[follow-tracker] Network capture error:', e)
    );
    return false;
  }

  if (message.action === 'ftGetStatus') {
    ftGetScanStatus().then(sendResponse).catch(() => sendResponse({ status: 'idle' }));
    return true;
  }
});

async function handleFollowScan(sendResponse) {
  if (ftScanInProgress) {
    sendResponse({ success: false, error: 'A scan is already in progress.' });
    return;
  }

  ftScanInProgress = true;

  try {
    // Resolve athlete ID from storage (set by content.js on page load)
    const stored = await browser.storage.local.get(['loggedInAthleteId']);
    let athleteId = stored.loggedInAthleteId || null;

    // Fallback: query the active Strava tab
    if (!athleteId) {
      athleteId = await getAthleteIdFromActiveTab();
    }

    if (!athleteId) {
      await ftSetScanStatus({ status: 'error', error: 'Could not determine your athlete ID. Please open Strava in a tab and try again.' });
      sendResponse({ success: false, error: 'Could not determine your athlete ID.' });
      return;
    }

    // Echo the resolved ID into storage so UI can confirm which athlete is being scanned
    await browser.storage.local.set({ loggedInAthleteId: athleteId });

    const result = await ftRunScan(athleteId);
    sendResponse({ success: true, ...result });
  } catch (e) {
    error('[follow-tracker] Scan failed:', e);
    const msg = e.message || 'Scan failed. Please try again.';
    await ftSetScanStatus({ status: 'error', error: msg });
    sendResponse({ success: false, error: msg });
  } finally {
    ftScanInProgress = false;
  }
}

// Query the active browser tab for the logged-in athlete ID via content script message
async function getAthleteIdFromActiveTab() {
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0]) return null;
    const response = await browser.tabs.sendMessage(tabs[0].id, { action: 'getAthleteId' });
    return response?.athleteId || null;
  } catch (_) {
    return null;
  }
}

// Handle passively intercepted follow data from networkInterceptor.js
async function handleNetworkCapture(message) {
  // Build a partial snapshot update — we accumulate pages into a pending object
  // stored under 'ftNetworkPending' until the page is fully loaded.
  const result = await browser.storage.local.get(['ftNetworkPending']);
  const pending = result.ftNetworkPending || { followers: {}, following: {} };

  const type = message.type; // 'followers' or 'following'
  if (type === 'followers' || type === 'following') {
    Object.assign(pending[type], message.athletes);
  }

  await browser.storage.local.set({ ftNetworkPending: pending });
  log(`[follow-tracker] Network capture: ${Object.keys(message.athletes).length} ${type}`);
}
