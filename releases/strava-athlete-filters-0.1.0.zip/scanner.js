// Follow Tracker: Scanner
// Orchestrates paginated Strava API calls to fetch follower/following data.
// Runs inside the background service worker (Chrome) or background page (Firefox).
//
// Strava's internal follows endpoint:
//   GET /athletes/{athlete_id}/follows?type=followers|following&page=N&per_page=200
//
// Authentication: relies on the user's active Strava session cookies, which the
// background/service-worker context inherits automatically (credentials: 'include').
//
// Progress is written to browser.storage.local under the key 'ftScanStatus' so that
// the popup can react via storage.onChanged even if message ports have closed.

// Default scan settings — overridable via browser.storage.local key 'ftScanSettings'.
// Strava ignores per_page and always returns 25 items per page regardless of
// what value is requested. PAGE_SIZE reflects that observed behaviour.
const FT_DEFAULT_PAGE_SIZE = 25;
const FT_DEFAULT_MAX_PAGES = 400; // 400 × 25 = 10 000 athletes safety cap
const FT_SETTINGS_KEY = 'ftScanSettings';

const FT_REQUEST_DELAY_MS = 400; // polite delay between paginated requests
// Gate verbose scan-path logging and raw API responses behind this flag.
// Intended only for debugging — can log large volumes of user data.
const FT_DEBUG_LOGGING = false;

// When set to a tab ID, ftFetchPage routes HTTP calls through a content-script proxy
// so that the request carries the page's Referer and session cookies automatically.
// Chrome MV3 service workers cannot set the Referer header (forbidden header name),
// so without this Strava returns an HTML page-shell instead of JSON.
let ftProxyTabId = null;
function ftSetProxyTabId(id) { ftProxyTabId = id; }

// Read scan settings from storage, falling back to defaults.
async function ftGetScanSettings() {
  const result = await browser.storage.local.get([FT_SETTINGS_KEY]);
  const s = result[FT_SETTINGS_KEY] || {};
  return {
    pageSize: (Number(s.pageSize) > 0 ? Number(s.pageSize) : FT_DEFAULT_PAGE_SIZE),
    maxPages: (Number(s.maxPages) > 0 ? Number(s.maxPages) : FT_DEFAULT_MAX_PAGES),
  };
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function ftSleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Attempt to extract { id, name } from any Strava API response shape
function ftExtractEntry(item) {
  if (!item || typeof item !== 'object') return null;

  // Strava returns each follow as a 2-element tuple array:
  //   [ {follower_id, followee_id, follow_status, ...}, {athlete: {id, firstname, lastname, ...}} ]
  // Flatten: find the element that carries athlete data.
  let obj = item;
  if (Array.isArray(item)) {
    obj = item.find(el => el && typeof el === 'object' && !Array.isArray(el) &&
      (el.id || el.athlete_id || el.athlete?.id)) || null;
    if (!obj) return null;
  }

  // Unwrap one more level if the object is { athlete: {...} }
  const inner = obj.athlete && typeof obj.athlete === 'object' ? obj.athlete : obj;

  const id = String(
    inner.id || inner.athlete_id || obj.id || obj.athlete_id || ''
  ).trim();
  if (!id || id === '0') return null;

  const name = (
    inner.name ||
    [inner.firstname, inner.lastname].filter(Boolean).join(' ') ||
    obj.name ||
    [obj.firstname, obj.lastname].filter(Boolean).join(' ') ||
    `Athlete ${id}`
  ).trim();

  return { id, name };
}

// ── HTML page parsers ─────────────────────────────────────────────────────────

/**
 * Parse athlete entries from Strava's HTML follows page.
 * Returns [{id: string, name: string}]
 *
 * Expected Strava HTML structure (as of 2026):
 *   <li data-athlete-id="12345" ...>
 *     ...
 *     <div class="text-callout ...">
 *       <a href="/athletes/12345">Athlete Name</a>
 *     </div>
 *   </li>
 */
function ftParseHtmlFollows(html) {
  const athletes = [];
  const liRe = /<li[^>]+data-athlete-id="(\d+)"[^>]*>([\s\S]*?)<\/li>/g;
  let m;
  while ((m = liRe.exec(html)) !== null) {
    const athleteId = m[1];
    const liBody = m[2];
    // Extract name from <a href="/athletes/{id}">Name</a>
    const nameMatch = liBody.match(/<a[^>]+href="\/athletes\/\d+"[^>]*>([\s\S]*?)<\/a>/);
    const rawName = nameMatch ? nameMatch[1] : '';
    // Strip nested tags and normalise whitespace
    const name = rawName.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim() ||
      `Athlete ${athleteId}`;
    athletes.push({ id: athleteId, name });
  }
  return athletes;
}

/**
 * Return true if the Strava follows HTML page pagination has a next-page link.
 * Last page has:   <li class="next_page disabled"><span>→</span></li>
 * More pages have: <li class="next_page"><a rel="next" href="...">→</a></li>
 */
function ftHtmlHasNextPage(html) {
  const m = html.match(/<li[^>]+class="[^"]*next_page[^"]*"[^>]*>([\s\S]*?)<\/li>/);
  return !!m && /<a\b/i.test(m[1]);
}

// ── Scan status helpers (written to storage so popup can observe) ─────────────

async function ftSetScanStatus(status) {
  await browser.storage.local.set({ ftScanStatus: status });
}

async function ftGetScanStatus() {
  const result = await browser.storage.local.get(['ftScanStatus']);
  return result.ftScanStatus || { status: 'idle' };
}

// ── Single page fetch ─────────────────────────────────────────────────────────
//
// Returns { items: [{id, name}], hasNextPage: boolean }
// Strava now serves HTML for the follows endpoint (as of early 2026); JSON is
// retained as a fallback in case they ever revert.

async function ftFetchPage(athleteId, type, page) {
  const url = new URL(`https://www.strava.com/athletes/${athleteId}/follows`);
  url.searchParams.set('type', type);
  url.searchParams.set('page', String(page));
  // This parameter tells Strava's server to return the partial HTML content
  // (just the follows list div) rather than the full SPA application shell.
  // Strava uses it in its own client-side pagination links.
  url.searchParams.set('page_uses_modern_javascript', 'true');

  // Fetch via the content-script proxy when available (Chrome MV3: SW cannot set Referer).
  // The content script runs inside the Strava page so the browser sets Referer automatically.
  let rd; // response data: { ok, status, statusText, contentType, url, text }
  if (ftProxyTabId !== null) {
    try {
      rd = await browser.tabs.sendMessage(ftProxyTabId, {
        action: 'ftProxyFetch',
        url: url.toString(),
      });
    } catch (err) {
      throw new Error('Could not reach the Strava tab to proxy the request. ' +
        'Please ensure Strava is open in a tab and try again.');
    }
    if (!rd || rd.proxyError) {
      throw new Error(rd?.proxyError || 'Proxy fetch failed with no details.');
    }
  } else {
    // Direct fetch (Firefox, or Chrome if no Strava tab found).
    const response = await fetch(url.toString(), {
      credentials: 'include',
      headers: { 'Accept': 'text/html, */*' },
    });
    rd = {
      ok: response.ok,
      status: response.status,
      statusText: response.statusText,
      contentType: response.headers.get('content-type') || '',
      url: response.url,
      text: await response.text(),
    };
  }

  if (!rd.ok) {
    throw new Error(`Strava returned HTTP ${rd.status} for ${type} page ${page}. ` +
      'You may need to visit Strava and log in again.');
  }

  const contentType = rd.contentType || '';
  const bodyText = rd.text;

  // JSON path — legacy fallback in case Strava ever reverts to JSON responses.
  if (contentType.includes('json') || contentType.includes('javascript')) {
    let raw;
    try { raw = JSON.parse(bodyText); } catch (_) { /* fall through to HTML */ }
    if (raw !== undefined) {
      let jsonItems = [];
      if (Array.isArray(raw)) {
        jsonItems = raw;
      } else {
        for (const key of ['follows', 'athletes', 'data', 'entries', 'followers', 'following', 'results', 'items']) {
          if (Array.isArray(raw[key])) { jsonItems = raw[key]; break; }
        }
        if (!jsonItems.length) {
          const arrayProps = Object.values(raw).filter(Array.isArray);
          if (arrayProps.length === 1) jsonItems = arrayProps[0];
        }
      }
      const normalized = jsonItems.map(ftExtractEntry).filter(Boolean);
      if (FT_DEBUG_LOGGING) {
        console.log(`[follow-tracker] ${type} page ${page}: ${normalized.length} items from JSON`);
      }
      return { items: normalized, hasNextPage: normalized.length > 0 };
    }
  }

  // HTML path — current Strava behavior (early 2026).
  const athletes = ftParseHtmlFollows(bodyText);
  const hasNextPage = ftHtmlHasNextPage(bodyText);

  if (FT_DEBUG_LOGGING) {
    console.log(`[follow-tracker] ${type} page ${page}: ${athletes.length} athletes from HTML, hasNextPage=${hasNextPage}`);
  }

  // Detect a login redirect or unexpected response (no athletes, no pagination).
  if (athletes.length === 0 && page === 1) {
    const debugInfo = {
      reason: 'html-zero-athletes',
      status: rd.status,
      contentType,
      url: rd.url,
      bodyPreview: bodyText.slice(0, 500),
      timestamp: new Date().toISOString(),
    };
    try { await browser.storage.local.set({ ftLastParseError: debugInfo }); } catch (_) {}
    const isLoginPage = /sign.?in|log.?in|create.?account/i.test(bodyText.slice(0, 2000));
    if (isLoginPage) {
      throw new Error('Strava requires you to be logged in. Please visit www.strava.com and sign in, then try again.');
    }
  }

  return { items: athletes, hasNextPage };
}

// ── Full paginated fetch for one follows type ──────────────────────────────────

async function ftFetchAllFollows(athleteId, type, onPageDone) {
  const { maxPages } = await ftGetScanSettings();
  const result = {};
  let page = 1;

  while (page <= maxPages) {
    if (page > 1) await ftSleep(FT_REQUEST_DELAY_MS);

    let pageResult;
    try {
      pageResult = await ftFetchPage(athleteId, type, page);
    } catch (e) {
      if (page === 1) throw e;
      break;
    }

    const { items, hasNextPage } = pageResult;

    if (!items || items.length === 0) {
      if (FT_DEBUG_LOGGING) {
        console.log(`[follow-tracker] ${type} page ${page}: 0 items — stopping pagination`);
      }
      break;
    }

    for (const entry of items) {
      result[entry.id] = entry.name;
    }

    if (FT_DEBUG_LOGGING) {
      console.log(`[follow-tracker] ${type} page ${page}: ${items.length} items (total so far: ${Object.keys(result).length})`);
    }

    const totalSoFar = Object.keys(result).length;
    if (onPageDone) {
      try {
        await onPageDone(totalSoFar, page);
      } catch (e) {
        console.warn('[follow-tracker] onPageDone callback failed:', e);
      }
    }

    if (!hasNextPage) break;
    page++;
  }

  return result;
}

// ── Main scan entry point ──────────────────────────────────────────────────────
//
// athleteId: string — the logged-in user's Strava athlete ID
// Returns: { snapshot, events, followerCount, followingCount, isFirstScan }

async function ftRunScan(athleteId) {
  await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps: 4,
    message: `Fetching followers for athlete ${athleteId}…`, count: 0 });

  const followers = await ftFetchAllFollows(athleteId, 'followers', async (count, page) => {
    await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps: 4,
      message: `Fetching followers… ${count} found (page ${page})`, count });
  });

  await ftSetScanStatus({ status: 'scanning', step: 2, totalSteps: 4,
    message: `Followers done: ${Object.keys(followers).length}. Fetching following…`, count: Object.keys(followers).length });

  const following = await ftFetchAllFollows(athleteId, 'following', async (count, page) => {
    await ftSetScanStatus({ status: 'scanning', step: 2, totalSteps: 4,
      message: `Fetching following… ${count} found (page ${page})`, count });
  });

  await ftSetScanStatus({ status: 'scanning', step: 3, totalSteps: 4,
    message: 'Computing changes…', count: 0 });

  const snapshot = {
    date: Math.floor(Date.now() / 1000),
    followers,
    following
  };

  // Compute diff against stored snapshot
  const stored = await ftGetData();
  const events = ftComputeDiff(stored.latestSnapshot, snapshot);

  await ftSetScanStatus({ status: 'scanning', step: 4, totalSteps: 4,
    message: 'Saving results…', count: events.length });

  await ftSaveSnapshot(snapshot, events);

  const result = {
    snapshot,
    events,
    followerCount: Object.keys(followers).length,
    followingCount: Object.keys(following).length,
    isFirstScan: !stored.latestSnapshot
  };

  await ftSetScanStatus({
    status: 'complete',
    completedAt: Math.floor(Date.now() / 1000),
    followerCount: result.followerCount,
    followingCount: result.followingCount,
    newEvents: events.length,
    isFirstScan: result.isFirstScan
  });

  return result;
}
