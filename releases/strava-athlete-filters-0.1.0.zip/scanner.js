// Follow Tracker: Scanner
// Orchestrates paginated Strava API calls to fetch follower/following data.
// Runs inside the background service worker (Chrome) or background page (Firefox).
//
// Strava's internal follows endpoint:
//   GET /athletes/{athlete_id}/follows?type=followers|following&page=N&per_page=200
//
// Authentication: relies on the user's active Strava session cookies, which the
// background/service-worker context inherits automatically (credentials: 'include').
//
// Progress is written to browser.storage.local under the key 'ftScanStatus' so that
// the popup can react via storage.onChanged even if message ports have closed.

// Default scan settings — overridable via browser.storage.local key 'ftScanSettings'.
// Strava ignores per_page and always returns 25 items per page regardless of
// what value is requested. PAGE_SIZE reflects that observed behaviour.
const FT_DEFAULT_PAGE_SIZE = 25;
const FT_DEFAULT_MAX_PAGES = 400; // 400 × 25 = 10 000 athletes safety cap
const FT_SETTINGS_KEY = 'ftScanSettings';

const FT_REQUEST_DELAY_MS = 400; // polite delay between paginated requests
const FT_DEBUG_LOGGING = false; // gate verbose scan-path logging behind this flag

// Enable to log raw API responses and unexpected shapes to the background console.
// This is intended only for debugging, as it can log large volumes of user data.
const FT_DEBUG_LOGGING = false;

// Read scan settings from storage, falling back to defaults.
async function ftGetScanSettings() {
  const result = await browser.storage.local.get([FT_SETTINGS_KEY]);
  const s = result[FT_SETTINGS_KEY] || {};
  return {
    pageSize: (Number(s.pageSize) > 0 ? Number(s.pageSize) : FT_DEFAULT_PAGE_SIZE),
    maxPages: (Number(s.maxPages) > 0 ? Number(s.maxPages) : FT_DEFAULT_MAX_PAGES),
  };
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function ftSleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Attempt to extract { id, name } from any Strava API response shape
function ftExtractEntry(item) {
  if (!item || typeof item !== 'object') return null;

  // Strava returns each follow as a 2-element tuple array:
  //   [ {follower_id, followee_id, follow_status, ...}, {athlete: {id, firstname, lastname, ...}} ]
  // Flatten: find the element that carries athlete data.
  let obj = item;
  if (Array.isArray(item)) {
    obj = item.find(el => el && typeof el === 'object' && !Array.isArray(el) &&
      (el.id || el.athlete_id || el.athlete?.id)) || null;
    if (!obj) return null;
  }

  // Unwrap one more level if the object is { athlete: {...} }
  const inner = obj.athlete && typeof obj.athlete === 'object' ? obj.athlete : obj;

  const id = String(
    inner.id || inner.athlete_id || obj.id || obj.athlete_id || ''
  ).trim();
  if (!id || id === '0') return null;

  const name = (
    inner.name ||
    [inner.firstname, inner.lastname].filter(Boolean).join(' ') ||
    obj.name ||
    [obj.firstname, obj.lastname].filter(Boolean).join(' ') ||
    `Athlete ${id}`
  ).trim();

  return { id, name };
}

// ── Scan status helpers (written to storage so popup can observe) ─────────────

async function ftSetScanStatus(status) {
  await browser.storage.local.set({ ftScanStatus: status });
}

async function ftGetScanStatus() {
  const result = await browser.storage.local.get(['ftScanStatus']);
  return result.ftScanStatus || { status: 'idle' };
}

// ── Single page fetch ─────────────────────────────────────────────────────────

async function ftFetchPage(athleteId, type, page, pageSize) {
  const url = new URL(`https://www.strava.com/athletes/${athleteId}/follows`);
  url.searchParams.set('type', type);
  url.searchParams.set('page', String(page));
  url.searchParams.set('per_page', String(pageSize)); // Strava ignores this but we send it anyway

  const response = await fetch(url.toString(), {
    credentials: 'include',
    headers: {
      'Accept': 'application/json, text/javascript, */*; q=0.01',
      'X-Requested-With': 'XMLHttpRequest'
    }
  });

  if (!response.ok) {
    throw new Error(`Strava returned HTTP ${response.status} for ${type} page ${page}. ` +
      'You may need to visit Strava and log in again.');
  }

  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('json') && !contentType.includes('javascript')) {
    throw new Error(
      'Strava returned an HTML page instead of JSON. ' +
      'Please visit www.strava.com to ensure you are logged in, then try again.'
    );
  }

  const raw = await response.json();

  // Log raw shape to background console so it can be inspected in about:debugging
  if (FT_DEBUG_LOGGING) {
    console.log(
      `[follow-tracker] ${type} page ${page} raw response (first 500 chars):`,
      JSON.stringify(raw).slice(0, 500)
    );
  }

  // Normalise: Strava may return a bare array or a wrapped object.
  // Try the most common envelope shapes before falling back.
  if (Array.isArray(raw)) return raw;
  for (const key of ['follows', 'athletes', 'data', 'entries', 'followers', 'following', 'results', 'items']) {
    if (Array.isArray(raw[key])) return raw[key];
  }
  // Last resort: if the object has exactly one array-valued property, use it
  const arrayProps = Object.values(raw).filter(Array.isArray);
  if (arrayProps.length === 1) return arrayProps[0];

  // Unknown shape — optionally log and return empty so the loop terminates cleanly
  if (FT_DEBUG_LOGGING) {
    console.warn(
      '[follow-tracker] Unexpected API response shape:',
      JSON.stringify(raw).slice(0, 200)
    );
  }
  return [];
}

// ── Full paginated fetch for one follows type ──────────────────────────────────

async function ftFetchAllFollows(athleteId, type, onPageDone) {
  const { pageSize, maxPages } = await ftGetScanSettings();
  const result = {};
  let page = 1;

  while (page <= maxPages) {
    if (page > 1) await ftSleep(FT_REQUEST_DELAY_MS);

    let pageItems;
    try {
      pageItems = await ftFetchPage(athleteId, type, page, pageSize);
    } catch (e) {
      if (page === 1) throw e;
      break;
    }

    if (!Array.isArray(pageItems) || pageItems.length === 0) {
      if (FT_DEBUG_LOGGING) {
        console.log(`[follow-tracker] ${type} page ${page}: received ${Array.isArray(pageItems) ? 0 : 'non-array'} items — stopping pagination`);
      }
      break; // Empty = done
    }

    if (FT_DEBUG_LOGGING) {
      console.log(`[follow-tracker] ${type} page ${page}: ${pageItems.length} raw items`);
    }
    let extracted = 0;
    let failedExtractions = 0;
    for (const item of pageItems) {
      const entry = ftExtractEntry(item);
      if (entry) {
        result[entry.id] = entry.name;
        extracted++;
      } else {
        failedExtractions++;
        if (FT_DEBUG_LOGGING) {
          console.log('[follow-tracker] item failed extraction');
        }
      }
    }
    if (FT_DEBUG_LOGGING) {
      console.log(
        `[follow-tracker] ${type} page ${page}: extracted ${extracted} / ${pageItems.length}` +
        (failedExtractions > 0 ? ` (failed extractions: ${failedExtractions})` : '')
      );
    }

    const totalSoFar = Object.keys(result).length;
    if (onPageDone) {
      try {
        await onPageDone(totalSoFar, page);
      } catch (e) {
        console.warn('[follow-tracker] onPageDone callback failed:', e);
      }
    }
    // Strava ignores per_page and returns its own fixed page size (~25).
    // Continue until an empty page — checked at the top of the loop.
    page++;
  }

  return result;
}

// ── Main scan entry point ──────────────────────────────────────────────────────
//
// athleteId: string — the logged-in user's Strava athlete ID
// Returns: { snapshot, events, followerCount, followingCount, isFirstScan }

async function ftRunScan(athleteId) {
  await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps: 4,
    message: `Fetching followers for athlete ${athleteId}…`, count: 0 });

  const followers = await ftFetchAllFollows(athleteId, 'followers', async (count, page) => {
    await ftSetScanStatus({ status: 'scanning', step: 1, totalSteps: 4,
      message: `Fetching followers… ${count} found (page ${page})`, count });
  });

  await ftSetScanStatus({ status: 'scanning', step: 2, totalSteps: 4,
    message: `Followers done: ${Object.keys(followers).length}. Fetching following…`, count: Object.keys(followers).length });

  const following = await ftFetchAllFollows(athleteId, 'following', async (count, page) => {
    await ftSetScanStatus({ status: 'scanning', step: 2, totalSteps: 4,
      message: `Fetching following… ${count} found (page ${page})`, count });
  });

  await ftSetScanStatus({ status: 'scanning', step: 3, totalSteps: 4,
    message: 'Computing changes…', count: 0 });

  const snapshot = {
    date: Math.floor(Date.now() / 1000),
    followers,
    following
  };

  // Compute diff against stored snapshot
  const stored = await ftGetData();
  const events = ftComputeDiff(stored.latestSnapshot, snapshot);

  await ftSetScanStatus({ status: 'scanning', step: 4, totalSteps: 4,
    message: 'Saving results…', count: events.length });

  await ftSaveSnapshot(snapshot, events);

  const result = {
    snapshot,
    events,
    followerCount: Object.keys(followers).length,
    followingCount: Object.keys(following).length,
    isFirstScan: !stored.latestSnapshot
  };

  await ftSetScanStatus({
    status: 'complete',
    completedAt: Math.floor(Date.now() / 1000),
    followerCount: result.followerCount,
    followingCount: result.followingCount,
    newEvents: events.length,
    isFirstScan: result.isFirstScan
  });

  return result;
}
