// Follow Tracker: Network Interceptor
// Injected as a content script on Strava follower/following pages.
// Wraps window.fetch and XMLHttpRequest to capture Strava's internal paginated
// API calls and forward the follow data to the background for storage.
//
// This provides passive capture whenever the user naturally browses their
// followers/following pages, without requiring any active scan.

(function () {
  'use strict';

  const FT_FOLLOWS_PATTERN = /\/athletes\/\d+\/follows/;
  const capturedUrls = new Set();

  // ── Entry extraction (mirrors scanner.js logic) ──────────────────────────────

  function extractAthletes(data) {
    if (!Array.isArray(data) || data.length === 0) return null;
    const athletes = {};
    for (const rawItem of data) {
      if (!rawItem) continue;
      // Align with scanner.js: handle tuple form [meta, { athlete: {...} }]
      let item = rawItem;
      if (Array.isArray(item)) {
        // Prefer the second element (data), fall back to first if needed
        item = item[1] || item[0];
      }
      if (!item || typeof item !== 'object') continue;
      // If the athlete data is nested, normalize to that object
      const entry = (item.athlete && typeof item.athlete === 'object') ? item.athlete : item;
      const id = String(
        entry.id ||
        entry.athlete_id ||
        item.athlete_id ||
        ''
      ).trim();
      if (!id || id === '0') continue;
      const name = (
        entry.name ||
        [entry.firstname, entry.lastname].filter(Boolean).join(' ') ||
        `Athlete ${id}`
      ).trim();
      athletes[id] = name;
    }
    return Object.keys(athletes).length > 0 ? athletes : null;
  }

  // ── Forward captured follows page to background ───────────────────────────────

  function forwardToBackground(url, data, type) {
    const athletes = extractAthletes(data);
    if (!athletes) return;
    browser.runtime.sendMessage({
      action: 'ftNetworkCapture',
      type,
      athletes,
      url,
      pageUrl: window.location.href
    }).catch(() => {}); // Suppress errors if background port is gone
  }

  // ── fetch wrapper ─────────────────────────────────────────────────────────────

  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    try {
      const url = (typeof args[0] === 'string' ? args[0] : args[0]?.url) || '';
      if (FT_FOLLOWS_PATTERN.test(url) && !capturedUrls.has(url)) {
        capturedUrls.add(url);
        const urlObj = new URL(url, window.location.origin);
        const type = urlObj.searchParams.get('type') || 'unknown';
        response.clone().json().then(data => {
          forwardToBackground(url, data, type);
        }).catch(() => {});
      }
    } catch (_) { /* never break the original call */ }
    return response;
  };

  // ── XHR wrapper (fallback for older Strava code paths) ───────────────────────

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._ftUrl = String(url || '');
    return origOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    const url = this._ftUrl || '';
    if (FT_FOLLOWS_PATTERN.test(url) && !capturedUrls.has(url)) {
      capturedUrls.add(url);
      const urlObj = new URL(url, window.location.origin);
      const type = urlObj.searchParams.get('type') || 'unknown';
      this.addEventListener('load', () => {
        try {
          const data = JSON.parse(this.responseText);
          forwardToBackground(url, data, type);
        } catch (_) {}
      });
    }
    return origSend.apply(this, args);
  };
})();
