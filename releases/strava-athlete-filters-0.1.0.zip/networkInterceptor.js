// Follow Tracker: Network Interceptor
// Injected as a content script on Strava follower/following pages.
// Wraps window.fetch and XMLHttpRequest to capture Strava's internal paginated
// API calls and forward the follow data to the background for storage.
//
// This provides passive capture whenever the user naturally browses their
// followers/following pages, without requiring any active scan.

(function () {
  'use strict';

  const FT_FOLLOWS_PATTERN = /\/athletes\/\d+\/follows/;
  const capturedUrls = new Set();

  // ── Entry extraction (mirrors scanner.js logic) ──────────────────────────────

  function extractAthletes(data) {
    if (!Array.isArray(data) || data.length === 0) return null;
    const athletes = {};
    for (const item of data) {
      if (!item || typeof item !== 'object') continue;
      const id = String(item.id || item.athlete_id || item.athlete?.id || '').trim();
      if (!id || id === '0') continue;
      const name = (
        item.name ||
        item.athlete?.name ||
        [item.firstname, item.lastname].filter(Boolean).join(' ') ||
        [item.athlete?.firstname, item.athlete?.lastname].filter(Boolean).join(' ') ||
        `Athlete ${id}`
      ).trim();
      athletes[id] = name;
    }
    return Object.keys(athletes).length > 0 ? athletes : null;
  }

  // ── Forward captured follows page to background ───────────────────────────────

  function forwardToBackground(url, data, type) {
    const athletes = extractAthletes(data);
    if (!athletes) return;
    browser.runtime.sendMessage({
      action: 'ftNetworkCapture',
      type,
      athletes,
      url,
      pageUrl: window.location.href
    }).catch(() => {}); // Suppress errors if background port is gone
  }

  // ── fetch wrapper ─────────────────────────────────────────────────────────────

  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    try {
      const url = (typeof args[0] === 'string' ? args[0] : args[0]?.url) || '';
      if (FT_FOLLOWS_PATTERN.test(url) && !capturedUrls.has(url)) {
        capturedUrls.add(url);
        const urlObj = new URL(url, window.location.origin);
        const type = urlObj.searchParams.get('type') || 'unknown';
        response.clone().json().then(data => {
          forwardToBackground(url, data, type);
        }).catch(() => {});
      }
    } catch (_) { /* never break the original call */ }
    return response;
  };

  // ── XHR wrapper (fallback for older Strava code paths) ───────────────────────

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._ftUrl = String(url || '');
    return origOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    const url = this._ftUrl || '';
    if (FT_FOLLOWS_PATTERN.test(url) && !capturedUrls.has(url)) {
      capturedUrls.add(url);
      const urlObj = new URL(url, window.location.origin);
      const type = urlObj.searchParams.get('type') || 'unknown';
      this.addEventListener('load', () => {
        try {
          const data = JSON.parse(this.responseText);
          forwardToBackground(url, data, type);
        } catch (_) {}
      });
    }
    return origSend.apply(this, args);
  };
})();
